# Databricks notebook source
dbutils.fs.mount(
    source = "wasbs://dnadatabricksdemo@datalakestorgen2dna01.blob.core.windows.net",
    mount_point = "/mnt/containershareddna03",
    extra_configs = {"fs.azure.account.key.datalakestorgen2dna01.blob.core.windows.net":dbutils.secrets.get(scope = "scope_adb_2", key = "secretdna03")})