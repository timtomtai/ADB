# Databricks notebook source


# COMMAND ----------

def partfilemover(source_path,file_pattern,target_file, **kwargs):

	import shutil
	import os
	from datetime import datetime
	import glob
	
	target_dateformat=kwargs.get('target_dateformat', 'None')
	source_path=source_path
	file_pattern=file_pattern
	
	filename, file_extension = os.path.splitext(target_file)
	if target_dateformat == "None" :
		target_file=target_file
	else:
		now = datetime.now()
		datetime_str = now.strftime(target_dateformat)
		target_file=filename+'_'+datetime_str+file_extension
	
	files_at_path= [fd for fd in glob.glob(source_path+file_pattern)]
	for items in files_at_path: 
		
		#shutil.copy(items, items+'_processed')
		shutil.move(items, target_file)

# COMMAND ----------

import sys
# We are inserting below sys path so that we can import any python file from this location
sys.path.insert(0,'/dbfs/FileStore/tables/DataEng/RawtoStg/')

import logging
from config.logging_init_file import init_loging
from config.rawToStgAbstract import rawToStgAbstract
from config.data_validator import dataValidator
from config.part_filemover import partfilemover
from pyspark.sql import SparkSession 
from pyspark.sql.functions import to_date,col,unix_timestamp,to_timestamp
from pyspark.sql.types import StringType,TimestampType,DecimalType,IntegerType,FloatType
import glob
import shutil
#import dbutils

class ClaimantAddressLinkRawtoStg(rawToStgAbstract):
    def __init__(self,src,dst):
        self.logger, self.file_name = init_loging(__name__)
        self.logger.info("Started Initializing....")
        self.source_path = [i.replace('/dbfs','') for i in glob.glob('/dbfs'+src+'/*.*')]
        self.ini_source_path = '/dbfs'+src
        self.logger.info(self.source_path)
        self.dest_path = dst  
        self.spark = SparkSession.builder.master("master").appName(__name__).enableHiveSupport().getOrCreate()
        self.logger.info("Initialization is completed")

    def read(self):
        self.logger.info("Started Reading file of input file")
        try:
            source_format = "csv" # This can be "csv", "json", "parquet" depending upon the source file
            source_delimiter = "," # This can be "," or anyother delimiter or None
            source_header = True # This can be True or False or None
            self.source_file = self.spark.read.load(self.source_path,
                     format=source_format, delimiter=source_delimiter, header=source_header)
            self.logger.info("Reading of input file is completed")
        except:
            self.logger.critical("Issue in reading the input file")

    def validate(self):
        self.dq_config_parser_name ="ClaimantAddressLink"
        self.logger.info("Started data validation")
        filtered_df , errordf  = dataValidator ("/dbfs/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt", src_Initials= self.dq_config_parser_name, input_df= self.source_file) 
        errordf.toPandas().to_csv("/dbfs/mnt/containershareddna03/logs/Data_Validation_Logs/claimant_addresslink/"+self.file_name+".csv")
        self.logger.info("Number of bad records: ",errordf.count())
        self.logger.info("Data validation is completed")

    def trans(self):
        self.logger.info("Started Data transformation")
        self.source_file=self.source_file.withColumn("claimcontrol_id",col("claimcontrol_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("claimant_num",col("claimant_num").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("address_id",col("address_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("nameaddresssource_id",col("nameaddresssource_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("added_date",to_date(col("added_date"),"yyyy-MM-dd"))	
        self.source_file=self.source_file.withColumn("pcadded_date",col("pcadded_date").cast(TimestampType()))	
        self.source_file=self.source_file.withColumn("last_modified_date",col("last_modified_date").cast(TimestampType()))	
        self.source_file=self.source_file.withColumn("version_begin_timestamp",col("version_begin_timestamp").cast(TimestampType()))	
        self.source_file=self.source_file.withColumn("version_end_timestamp",col("version_end_timestamp").cast(TimestampType()))	
        self.logger.info("Completed Data transformation")

    def store(self):
        self.logger.info("Started storing the file")
        self.source_file.write.mode("Overwrite").parquet(self.dest_path)
        source_file_pattern = "/*.csv"
        target_file_path = self.ini_source_path+'/processed'
        self.logger.info(target_file_path)
        self.logger.info(self.ini_source_path)
        partfilemover(self.ini_source_path,source_file_pattern,target_file_path)
        self.logger.info("Storing of file is completed")