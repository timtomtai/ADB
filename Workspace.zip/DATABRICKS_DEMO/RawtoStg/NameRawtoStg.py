# Databricks notebook source
import sys
# We are inserting below sys path so that we can import any python file from this location
sys.path.insert(0,'/dbfs/FileStore/tables/DataEng/RawtoStg/')

import logging
from config.logging_init_file import init_loging
from config.rawToStgAbstract import rawToStgAbstract
from config.data_validator import dataValidator
from config.part_filemover import partfilemover
from pyspark.sql import SparkSession 
import glob
import shutil
from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import to_date,col
from pyspark.sql.types import StructType,StringType,TimestampType,DecimalType,IntegerType,StructField

class NameRawtoStg(rawToStgAbstract):
    def __init__(self,src,dst):
        self.logger, self.file_name = init_loging(__name__)
        self.logger.info("Started Initializing....")
        self.source_path = [i.replace('/dbfs','') for i in glob.glob('/dbfs'+src+'/*.*')]
        self.ini_source_path = '/dbfs'+src
        self.logger.info(self.source_path)
        self.dest_path = dst  
        self.spark = SparkSession.builder.master("master").appName(__name__).enableHiveSupport().getOrCreate()
        self.logger.info("Initialization is completed")

    def read(self):
        self.logger.info("Started Reading file of input file")
        try:
            source_format = "parquet" # This can be "csv", "json", "parquet" depending upon the source file
            source_delimiter = None # This can be "," or anyother delimiter or None
            source_header = True # This can be True or False or None
            self.source_file = self.spark.read.load(self.source_path,
                     format=source_format, delimiter=source_delimiter, header=source_header)
            self.logger.info("Reading of input file is completed")
        except:
            self.logger.critical("Issue in reading the input file")

    def validate(self):
        self.dq_config_parser_name ="name"
        self.logger.info("Started data validation")
        filtered_df , errordf  = dataValidator ("/dbfs/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt", src_Initials= self.dq_config_parser_name, input_df= self.source_file) 
        errordf.toPandas().to_csv("/dbfs/mnt/containershareddna03/logs/Data_Validation_Logs/name/"+self.file_name+".csv")
        self.logger.info("Number of bad records: ",errordf.count())
        self.logger.info("Data validation is completed")

    def trans(self):
        self.logger.info("Started Data transformation")
        self.source_file=self.source_file.withColumn("name_id",col("name_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("name_num",col("name_num").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("nametype_id",col("nametype_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("nameaddresssource_id",col("nameaddresssource_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("policy_id",col("policy_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("policyimage_num",col("policyimage_num").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("taxtype_id",col("taxtype_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("sex_id",col("sex_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("dlstate_id",col("dlstate_id").cast(IntegerType()))
        self.source_file = self.source_file.withColumn('dln_date',unix_timestamp(col('dln_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('birth_date',unix_timestamp(col('birth_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file=self.source_file.withColumn("maritalstatus_id",col("maritalstatus_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("detailstatuscode_id",col("detailstatuscode_id").cast(IntegerType()))
        self.source_file = self.source_file.withColumn('added_date',unix_timestamp(col('added_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('pcadded_date',unix_timestamp(col('pcadded_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file=self.source_file.withColumn("thirdparty_entity_id",col("thirdparty_entity_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("thirdparty_group_id",col("thirdparty_group_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("name_display_num",col("name_display_num").cast(IntegerType()))
        self.source_file = self.source_file.withColumn('last_modified_date',unix_timestamp(col('last_modified_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file=self.source_file.withColumn("entitytype_id",col("entitytype_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("contactreasontype_id",col("contactreasontype_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("packagepart_num",col("packagepart_num").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("riskgradelookup_id",col("riskgradelookup_id").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("vendor_taxnum_changed",col("vendor_taxnum_changed").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("vendor_dln_changed",col("vendor_dln_changed").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("vendor_birth_date_changed",col("vendor_birth_date_changed").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("active_military",col("active_military").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("years_experience",col("years_experience").cast(IntegerType()))
        self.source_file = self.source_file.withColumn('date_business_started',unix_timestamp(col('date_business_started'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file=self.source_file.withColumn("okay_to_text",col("okay_to_text").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("okay_to_email",col("okay_to_email").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("okay_to_call",col("okay_to_call").cast(IntegerType()))
        self.source_file=self.source_file.withColumn("has_no_email_address",col("has_no_email_address").cast(IntegerType()))
        self.source_file = self.source_file.withColumn('dl_exp_date',unix_timestamp(col('dl_exp_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('version_begin_timestamp',unix_timestamp(col('version_begin_timestamp'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('version_end_timestamp',unix_timestamp(col('version_end_timestamp'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.logger.info("Completed Data transformation")

    def store(self):
        self.logger.info("Started storing the file")
        self.source_file.write.mode("Overwrite").parquet(self.dest_path)
        source_file_pattern = "/*.parquet"
        target_file_path = self.ini_source_path+'/processed'
        self.logger.info(target_file_path)
        self.logger.info(self.ini_source_path)
        partfilemover(self.ini_source_path,source_file_pattern,target_file_path)
        #shutil.move("/dbfs"+self.source_path,"/dbfs/mnt/containershareddna03/Raw/claim/processed/"+self.file_name+"claim.csv")
        self.logger.info("Storing of file is completed")