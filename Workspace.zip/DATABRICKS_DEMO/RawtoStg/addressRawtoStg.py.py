# Databricks notebook source
def partfilemover(source_path,file_pattern,target_file, **kwargs):

	import shutil
	import os
	from datetime import datetime
	import glob
	
	target_dateformat=kwargs.get('target_dateformat', 'None')
	source_path=source_path
	file_pattern=file_pattern
	
	filename, file_extension = os.path.splitext(target_file)
	if target_dateformat == "None" :
		target_file=target_file
	else:
		now = datetime.now()
		datetime_str = now.strftime(target_dateformat)
		target_file=filename+'_'+datetime_str+file_extension
	
	files_at_path= [fd for fd in glob.glob(source_path+file_pattern)]
	for items in files_at_path: 
		
		#shutil.copy(items, items+'_processed')
		shutil.move(items, target_file)

# COMMAND ----------

import sys
# We are inserting below sys path so that we can import any python file from this location
sys.path.insert(0,'/dbfs/FileStore/tables/DataEng/RawtoStg/')

import logging
from config.logging_init_file import init_loging
from config.rawToStgAbstract import rawToStgAbstract
from config.data_validator import dataValidator
from config.part_filemover import partfilemover
from pyspark.sql import SparkSession 
from pyspark.sql.functions import to_date,col,unix_timestamp,to_timestamp
from pyspark.sql.types import StringType,TimestampType,DecimalType,IntegerType,FloatType
import glob
import shutil
#import dbutils

class AddressRawtoStg(rawToStgAbstract):
    def __init__(self,src,dst):
        self.logger, self.file_name = init_loging(__name__)
        self.logger.info("Started Initializing....")
        self.source_path = [i.replace('/dbfs','') for i in glob.glob('/dbfs'+src+'/*.*')]
        self.ini_source_path = '/dbfs'+src
        self.logger.info(self.source_path)
        self.dest_path = dst  
        self.spark = SparkSession.builder.master("master").appName(__name__).enableHiveSupport().getOrCreate()
        self.logger.info("Initialization is completed")

    def read(self):
        self.logger.info("Started Reading file of input file")
        try:
            source_format = "csv" # This can be "csv", "json", "parquet" depending upon the source file
            source_delimiter = "," # This can be "," or anyother delimiter or None
            source_header = True # This can be True or False or None
            self.source_file = self.spark.read.load(self.source_path,
                     format=source_format, delimiter=source_delimiter, header=source_header)
            self.logger.info("Reading of input file is completed")
        except:
            self.logger.critical("Issue in reading the input file")

    def validate(self):
        self.dq_config_parser_name ="address"
        self.logger.info("Started data validation")
        filtered_df , errordf  = dataValidator ("/dbfs/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt", src_Initials= self.dq_config_parser_name, input_df= self.source_file) 
        errordf.toPandas().to_csv("/dbfs/mnt/containershareddna03/logs/Data_Validation_Logs/address/"+self.file_name+".csv")
        self.logger.info("Number of bad records: ",errordf.count())
        self.logger.info("Data validation is completed")

    def trans(self):
        self.logger.info("Started Data transformation")
        self.source_file=self.source_file.withColumn("address_id",col("address_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("address_num",col("address_num").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("policy_id",col("policy_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("policyimage_num",col("policyimage_num").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("nameaddresssource_id",col("nameaddresssource_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("state_id",col("state_id").cast(IntegerType()))		
        self.source_file=self.source_file.withColumn("detailstatuscode_id",col("detailstatuscode_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("added_date",to_date(col("added_date"),"yyyy-MM-dd"))	
        self.source_file=self.source_file.withColumn("pcadded_date",col("pcadded_date").cast(TimestampType()))		
        self.source_file=self.source_file.withColumn("latitude",col("latitude").cast(FloatType()))	
        self.source_file=self.source_file.withColumn("longitude",col("longitude").cast(FloatType()))	
        self.source_file=self.source_file.withColumn("verified",col("verified").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("attempted_verify",col("attempted_verify").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("changed",col("changed").cast(IntegerType()))		
        self.source_file=self.source_file.withColumn("zip_verified",col("zip_verified").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("thirdparty_entity_id",col("thirdparty_entity_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("thirdparty_group_id",col("thirdparty_group_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("territorycode",col("territorycode").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("territorycode_userentry",col("territorycode_userentry").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("territory_confidence_factor",col("territory_confidence_factor").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("windpool_id",col("windpool_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("windpool_userentry_id",col("windpool_userentry_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("windpool_confidence_factor",col("windpool_confidence_factor").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("mainland_proximitytype_id",col("mainland_proximitytype_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("ocean_distance",col("ocean_distance").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("bay_distance",col("bay_distance").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("waterway_distance",col("waterway_distance").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("river_distance",col("river_distance").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("state_code",col("state_code").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("county_code",col("county_code").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("county_code_user_entry",col("county_code_user_entry").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("municipal_code",col("municipal_code").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("municipal_code_user_entry",col("municipal_code_user_entry").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("city_min_tax_ind",col("city_min_tax_indicator").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("county_min_tax_ind",col("county_min_tax_indicator").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("police_code",col("police_code").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("police_code_user_entry",col("police_code_user_entry").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("fire_code",col("fire_code").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("fire_code_user_entry",col("fire_code_user_entry").cast(IntegerType()))		
        self.source_file=self.source_file.withColumn("sinkhole_proximitytype_id",col("sinkhole_proximitytype_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("mine_proximitytype_id",col("mine_proximitytype_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("stat_territory",col("stat_territory").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("waterbody_distance",col("waterbody_distance").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("last_modified_date",col("last_modified_date").cast(TimestampType()))	
        self.source_file=self.source_file.withColumn("packagepart_num",col("packagepart_num").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("taxcodeaddressmatchtype_id",col("taxcodeaddressmatchtype_id").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("specific_coverage_stat_territory",col("specific_coverage_stat_territory").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("geo_override",col("geo_override").cast(IntegerType()))		
        self.source_file=self.source_file.withColumn("is_retain_address_ppc_lookup",col("is_retain_address_ppc_lookup").cast(IntegerType()))	
        self.source_file=self.source_file.withColumn("version_begin_timestamp",col("version_begin_timestamp").cast(TimestampType()))	
        self.source_file=self.source_file.withColumn("version_end_timestamp",col("version_end_timestamp").cast(TimestampType()))	
        self.source_file=self.source_file.drop("city_min_tax_indicator","county_min_tax_indicator")
        self.logger.info("Completed Data transformation")

    def store(self):
        self.logger.info("Started storing the file")
        self.source_file.write.mode("Overwrite").parquet(self.dest_path)
        source_file_pattern = "/*.csv"
        target_file_path = self.ini_source_path+'/processed'
        self.logger.info(target_file_path)
        self.logger.info(self.ini_source_path)
        partfilemover(self.ini_source_path,source_file_pattern,target_file_path)
        self.logger.info("Storing of file is completed")