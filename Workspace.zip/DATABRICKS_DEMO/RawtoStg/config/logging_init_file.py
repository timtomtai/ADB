# Databricks notebook source
from datetime import datetime
import os
import logging

def init_loging(class_name):

    # Setting logging mechanism
    now = datetime.now()
    datetime_str = now.strftime("%Y%m%d")
    logger = logging.getLogger(class_name)
    logger.setLevel(logging.DEBUG)
    format_logger = logging.Formatter('%(asctime)s - %(levelname)s - %(name)s - %(message)s')
    file_name =  "dbfs/mnt/containershareddna02/DataEngineeringLayer/logs/RawtoStg/" + datetime_str +"Raw_to_stg.log"
    logger_handler = logging.FileHandler(file_name)
    logger_handler.setFormatter(format_logger)
    logger.addHandler(logger_handler)
    return logger