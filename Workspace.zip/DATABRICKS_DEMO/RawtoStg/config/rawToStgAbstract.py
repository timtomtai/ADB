# Databricks notebook source
from abc import ABC, abstractclassmethod

class rawToStgAbstract(ABC):
    @abstractclassmethod
    def read(self):
        pass
    
    @abstractclassmethod
    def trans(self):
        pass

    @abstractclassmethod
    def store(self):
        pass