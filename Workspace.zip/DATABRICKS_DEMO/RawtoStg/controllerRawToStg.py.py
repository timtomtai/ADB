# Databricks notebook source
from config.logging_init_file import init_loging
from customerRawtoStg import customerRawtoStg
from transactionRawtoStg import transactionRawtoStg
import sys

logger=init_loging(__name__)


class ControllerRawToStg:

    def __init__(self,module_name,source_path,dest_path):
        self.module_name = module_name
        self.source_path = source_path
        self.dest_path = dest_path

    def raw_to_stg(self):
        if (self.module_name=="cust"):           
            self.calling_obj = customerRawtoStg(self.source_path,self.dest_path)
        elif(self.module_name=="trans"):
            self.calling_obj = transactionRawtoStg(self.source_path,self.dest_path)
        else:
            logger.critical("Inproper Argument passed to raw_to_stg function")
            raise Exception("Inproper Argument passed to raw_to_stg function")     

        self.calling_obj.read()
        self.calling_obj.trans()
        self.calling_obj.store()
        

if __name__ == "__main__":
    module_name = sys.argv[1]
    source_path = sys.argv[2]
    dest_path = sys.argv[3]
    logger.info("Strated executing the Main Program")
    crts = ControllerRawToStg(module_name,source_path,dest_path)
    crts.raw_to_stg() 
    logger.info("Execution is completed for Main Program")