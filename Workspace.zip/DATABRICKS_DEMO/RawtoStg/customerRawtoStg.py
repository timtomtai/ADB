# Databricks notebook source
import logging
from config.logging_init_file import init_loging
from config.rawToStgAbstract import rawToStgAbstract
from pyspark.sql import SparkSession 
from pyspark.sql.types import StringType, IntegerType
from pyspark.sql.functions import col

class customerRawtoStg(rawToStgAbstract):
    def __init__(self,src,dst):
        self.logger = init_loging(__name__)
        self.logger.info("Started Initializing the object of customer Raw to Stg")
        self.source_path = src
        self.dest_path = dst      
        self.spark = SparkSession.builder.master("master").appName("my app").enableHiveSupport().getOrCreate()
        self.logger.info("Initialization is completed for Customer raw to stg")

    def read(self):
        self.logger.info("Started Reading file of customer")
        try:
            self.customer_file = self.spark.read.option("Header",True).csv(self.source_path)
            self.logger.info("Reading of customer file is completed")
        except:
            self.logger.critical("Issue in reading the customer file")

    def trans(self):

        self.customer_file=self.customer_file.withColumn("customer_id",col("CustId").cast(IntegerType()))
        self.customer_file=self.customer_file.withColumn("customer_name",col("Name").cast(StringType()))
        self.customer_file=self.customer_file.withColumn("customer_address",col("Address").cast(StringType()))
        self.customer_file=self.customer_file.withColumn("customer_phone",col("Phone").cast(StringType()))
        self.customer_file=self.customer_file.drop("CustId","Name","Address","Phone")

    def store(self):
        self.customer_file.write.mode("Overwrite").parquet(self.dest_path)