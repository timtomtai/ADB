# Databricks notebook source
import logging
from pyspark.sql.functions import to_date
from config.logging_init_file import init_loging
from config.rawToStgAbstract import rawToStgAbstract
from pyspark.sql import SparkSession 
from pyspark.sql.types import StringType, IntegerType, DateType
from pyspark.sql.functions import col

class transactionRawtoStg(rawToStgAbstract):
    def __init__(self,src,dst):
        self.logger = init_loging(__name__)
        self.logger.info("Started Initializing the object of transaction Raw to Stg")
        self.source_path = src
        self.dest_path = dst      
        self.spark = SparkSession.builder.master("master").appName("my app").enableHiveSupport().getOrCreate()
        self.logger.info("Initialization is completed for transaction raw to stg")

    def read(self):
        self.logger.info("Started Reading file of transaction")
        try:
            self.transaction_file = self.spark.read.option("Header",True).csv(self.source_path)
            self.logger.info("Reading of transaction file is completed")
        except:
            self.logger.critical("Issue in reading the transaction file")

    def trans(self):
        self.transaction_file=self.transaction_file.withColumn("transaction_id",col("tid").cast(IntegerType()))
        self.transaction_file=self.transaction_file.withColumn("customer_name",col("CustId").cast(StringType()))
        self.transaction_file=self.transaction_file.withColumn("product_id",col("PId").cast(StringType()))
        self.transaction_file=self.transaction_file.withColumn("product_qty",col("Qty").cast(IntegerType()))
        self.transaction_file=self.transaction_file.withColumn("transaction_date",to_date(col("tDate"),"dd-MM-yyyy"))
        self.transaction_file=self.transaction_file.drop("tid","CustId","PId","Qty","tDate")

    def store(self):
        self.transaction_file.write.mode("overwrite").parquet(self.dest_path)