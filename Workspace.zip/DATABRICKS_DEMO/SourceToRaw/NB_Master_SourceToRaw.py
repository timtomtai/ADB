# Databricks notebook source
print('xyz')

# COMMAND ----------

# MAGIC %md
# MAGIC call notebooks for moving data from source to Raw

# COMMAND ----------

#%run /DATABRICKS_DEMO/SourceToRaw/NB_Address_SourceToRaw

# COMMAND ----------

#%run /DATABRICKS_DEMO/SourceToRaw/NB_Claim_SourceToRaw

# COMMAND ----------

#%run /DATABRICKS_DEMO/SourceToRaw/NB_Claimant_SourceToRaw

# COMMAND ----------

#%run /DATABRICKS_DEMO/SourceToRaw/NB_ClaimantAddressLink_SourceToRaw

# COMMAND ----------

#%run /DATABRICKS_DEMO/SourceToRaw/NB_ClaimantNameLink_SourceToRaw

# COMMAND ----------

#%run /DATABRICKS_DEMO/SourceToRaw/NB_ClaimantType_SourceToRaw

# COMMAND ----------

#%run /DATABRICKS_DEMO/SourceToRaw/NB_Name_SourceToRaw

# COMMAND ----------

#%run /DATABRICKS_DEMO/SourceToRaw/NB_Sex_SourceToRaw