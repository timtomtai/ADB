# Databricks notebook source
# MAGIC %md
# MAGIC call notebook to initialize function readDatabaseSourceIni to connect to DB

# COMMAND ----------

# MAGIC %run /DATABRICKS_DEMO/SourceToRaw/NB_ConnectToDB

# COMMAND ----------

# MAGIC %md
# MAGIC call notebook to initialize function partfilemover to move files

# COMMAND ----------

# MAGIC %run /DATABRICKS_DEMO/SourceToRaw/NB_part_file_mover

# COMMAND ----------

# MAGIC %md
# MAGIC call notebook to read and write data from DB to raw layer

# COMMAND ----------

# MAGIC %run /DATABRICKS_DEMO/SourceToRaw/NB_writeDBTOFile

# COMMAND ----------

tablename= "Name"
config_path="/dbfs/FileStore/tables/DataEng/Config_DB_Param.txt"
section= "Diamond" 
target="/mnt/containershareddna01/DemoSourceData/"
newtarget="/mnt/containershareddna03/Raw/name/"
FORMAT="parquet"
compression="none"
dateformat="%Y%m%d%s"
write_db_source_file(config_path,tablename,section,target,newtarget,FORMAT,compression,dateformat)