# Databricks notebook source
# MAGIC %md
# MAGIC call notebook to initialize function partfilemover to move files

# COMMAND ----------

# MAGIC %run /DATABRICKS_DEMO/SourceToRaw/NB_part_file_mover

# COMMAND ----------


dbfs_src_path="/dbfs/mnt/containershareddna01/DemoSourceData/"
dbfs_target_path="/dbfs/mnt/containershareddna03/Raw/sex/sex.json"
source_file_pattern="Sex.json"
compression="none"
target_dateformat="%Y%m%d%s"

partfilemover(dbfs_src_path,source_file_pattern,dbfs_target_path,target_dateformat=target_dateformat)
