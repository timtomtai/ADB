# Databricks notebook source
def partfilemover(source_path,file_pattern,target_file, **kwargs):

	import shutil
	import os
	from datetime import datetime
	import glob
	
	target_dateformat=kwargs.get('target_dateformat', 'None')
	source_path=source_path
	file_pattern=file_pattern
	
	filename, file_extension = os.path.splitext(target_file)
	if target_dateformat == "None" :
		target_file=target_file
	else:
		now = datetime.now()
		datetime_str = now.strftime(target_dateformat)
		target_file=filename+'_'+datetime_str+file_extension
	
	files_at_path= [fd for fd in glob.glob(source_path+file_pattern)]
	for items in files_at_path: 
		
		#shutil.copy(items, items+'_processed')
		shutil.move(items, target_file)