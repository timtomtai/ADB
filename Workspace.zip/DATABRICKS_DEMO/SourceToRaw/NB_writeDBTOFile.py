# Databricks notebook source
# MAGIC %md
# MAGIC call function to read and write data from DB to raw layer
# MAGIC sample input:
# MAGIC 
# MAGIC tablename= "Address"
# MAGIC config_path="/dbfs/FileStore/tables/DataEng/Config_DB_Param.txt"
# MAGIC section= "Diamond" 
# MAGIC target="/mnt/containershareddna01/DemoSourceData/"
# MAGIC newtarget="/mnt/containershareddna02/DataEngineeringLayer/Raw/address/"
# MAGIC FORMAT="csv"
# MAGIC compression="none"
# MAGIC dateformat="%Y%m%d%s"

# COMMAND ----------

def write_db_source_file(config_path,tablename,section,target,newtarget,FORMAT,compression,dateformat):
    from datetime import datetime
    # Setting logging mechanism
    now = datetime.now()
    dateformat=dateformat
    datetime_str = now.strftime(dateformat)
    #read table
    databasetable = readDatabaseSourceIni (config_path, tablename=tablename, section=section )
    #set filename
    compression=compression
    filename=tablename+"_"+datetime_str+"."+FORMAT
    target=target+filename
    backupfile=target+"_processed"
    if compression == "none" :
        filename=tablename+"_"+datetime_str+"."+FORMAT
    else:
        filename=tablename++"_"+datetime_str+"."+compression+"."+FORMAT
    
    newtarget=newtarget+filename
    #write to file
    databasetable.write.option("compression",compression).format(FORMAT).mode("overwrite").save(target,header="true")
    #copy file to raw layer
    
    dbfs_src_path='/dbfs'+target+'/'
    ends_with='*.'+FORMAT
    dbfs_target_file='/dbfs'+newtarget
    partfilemover(dbfs_src_path,ends_with,dbfs_target_file)
    # backup source file
    dbutils.fs.mv(target,backupfile,recurse=True)