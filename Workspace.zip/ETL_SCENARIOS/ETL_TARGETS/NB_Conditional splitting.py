# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## Overview
# MAGIC 
# MAGIC This notebook will show you how to create and query a table or DataFrame that you uploaded to DBFS. [DBFS](https://docs.databricks.com/user-guide/dbfs-databricks-file-system.html) is a Databricks File System that allows you to store data for querying inside of Databricks. This notebook assumes that you have a file already inside of DBFS that you would like to read from.
# MAGIC 
# MAGIC This not book is written to split the data based on condition and archive the data file with the help of function call.

# COMMAND ----------

file_location = "/FileStore/tables/S_NS/Tab3.txt"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = " "

# The applied options are for CSV files. For other file types, these will be ignored.
df = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df)

# COMMAND ----------

from pyspark.sql.functions import *
df1 = df.where(col("State") == 'OH')
df2 = df.where(col("State") == 'NJ')
df3 = df.where(col("State") == 'NY')
df4 = df.where(col("State") == 'WI')

df1.show()
df2.show()
df3.show()
df4.show()

# COMMAND ----------

df1.write.format("delta").mode("overwrite").saveAsTable("Split_df1")
df2.write.format("delta").mode("overwrite").saveAsTable("Split_df2")
df3.write.format("delta").mode("overwrite").saveAsTable("Split_df3")
df4.write.format("delta").mode("overwrite").saveAsTable("Split_df4")

# COMMAND ----------

# MAGIC %sql 
# MAGIC Select * from Split_df1;
# MAGIC -- Select * from Split_df2;
# MAGIC -- Select * from Split_df3;
# MAGIC -- Select * from Split_df4;

# COMMAND ----------

df2.write.format("delta").mode("append").saveAsTable("Split_df1")

# COMMAND ----------

# MAGIC %sql 
# MAGIC Select * from Split_df1;

# COMMAND ----------

df1.write.format("csv").mode("overwrite").csv("/FileStore/tables/S_NS/Split_df1.csv",header="true")
df2.write.format("csv").mode("overwrite").csv("/FileStore/tables/S_NS/Split_df2.csv",header="true")
df3.write.format("csv").mode("overwrite").csv("/FileStore/tables/S_NS/Split_df3.csv",header="true")
df4.write.format("csv").mode("overwrite").csv("/FileStore/tables/S_NS/Split_df4.csv",header="true")

# COMMAND ----------

file_location = "/FileStore/tables/S_NS/Split_df2.csv"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
df00 = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df00)

# COMMAND ----------

df2.write.format("csv").mode("append").csv("/FileStore/tables/S_NS/Split_df1.csv",header="true")

# COMMAND ----------

file_location = "/FileStore/tables/S_NS/Split_df1.csv"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
df01 = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df01)

# COMMAND ----------

def fileArchive(Source, Destination, file_name) :

#         Source = "/FileStore/tables/S_NS/Source/"
#         Destination = "/FileStore/tables/S_NS/Destination/"
#         file_name  = "Tab3"
        try:

        
        ## loop through the files 
            for file in dbutils.fs.ls(Source):
                if file_name in file.name:

                 # This is the reason we are saving count and file name before this file movement
                    dbutils.fs.mv(f'{Source}/{file.name}', f'{Destination}/{file.name}')
             
                    print("File Moved")
                else:
                    print("No such file available at given path")
        except Exception as e:
            print("Error in Processing files")

# COMMAND ----------

fileArchive("/FileStore/tables/S_NS/Source/", "/FileStore/tables/S_NS/Destination/", "Tab2.txt")

# COMMAND ----------

fileArchive("/FileStore/tables/S_NS/Destination/", "/FileStore/tables/S_NS/Source/", "Tab3.txt")