# Databricks notebook source
 df_file_read = spark.read.load("/FileStore/tables/Sales_Records.csv",format="csv", header = "true", delimiter = ",")

# COMMAND ----------

df_file_read.show()

# COMMAND ----------

#df_file_read.show()
df_file_read.filter(df_file_read.Region == "Sub-Saharan Africa").show()
#df_file_read.filter(df_file_read.Region == "Sub-Saharan Africa" & df_file_read.Item Type = "Fruits" ).show()

# COMMAND ----------

import pyspark.sql.functions as f
#df_file_read.filter((f.col("Region")== "Sub-Saharan Africa")).show()

#single column
#df_file_read.filter((f.col("Region")== "Sub-Saharan Africa")  ).show()


# multple columns

df_file_read.filter((f.col("Region")== "Sub-Saharan Africa") & (f.col("Item Type")== "Fruits") ).show()

#like
#df_file_read.filter((f.col("Region").like('Sub-Saharan%') )).show()


#IN condition through LIST
#list = ["Rwanda", "Angola"]
#df_file_read.filter(df_file_read.Country.isin(list)).show()

#IN with OR condition through LIST
#list = ["Rwanda"] 
#list1 = ["Angola"]
#df_file_read.filter(df_file_read.Country.isin(list) | df_file_read.Country.isin(list1)).show()


# Startswith  
#df_file_read.filter(df_file_read.Country.startswith('Rwand')).show()

#Endswith
#df_file_read.filter(df_file_read.Country.endswith('nda')).show()
