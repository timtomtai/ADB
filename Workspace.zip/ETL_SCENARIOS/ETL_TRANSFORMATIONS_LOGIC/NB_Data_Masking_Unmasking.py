# Databricks notebook source
#Data masking unmasking notebook

# COMMAND ----------

df= spark.read.csv("/FileStore/tables/Files/Test/Employees.csv",header = "true", inferSchema ="true")
df.show()

# COMMAND ----------

#email masking

from pyspark.sql.functions import regexp_extract, regexp_replace,concat, expr, lit

df_email_mask = df.withColumn(
    "pattern", 
    regexp_extract("email", r"(?<=.{2})\w+(?=@)", 0)
)
df_email_mask = df_email_mask.withColumn(
    "replacement",
    regexp_replace("pattern", r"\w", "*")
)
df_email_mask = df_email_mask.withColumn(
    "EMAIL",
    expr("regexp_replace(email, concat('(?<=.{2})', pattern, '(?=@)'), replacement)")
)
df_email_mask.drop("pattern","replacement").show()

# COMMAND ----------

#masking using regex

from pyspark.sql.types import *
import pyspark.sql.functions as F

# This is assuming your card number is not a string. If not skip this cast
df_cast = df.withColumn("number_string",F.col('PHONE_NUMBER').cast(StringType()))
df_mask = df_cast.withColumn("PHONE_NUMBER",F.concat(F.lit('******'),F.substring(F.col("number_string"),6,4)))

df_mask.show()

# COMMAND ----------

#masking of data

from pyspark.sql.functions import lit

df.withColumn("FIRST_NAME", lit("*** Masked ***")).withColumn("EMAIL", lit("*** Masked ***")).show()

# COMMAND ----------

#masking using dictionary dataframe created at run time

from pyspark.sql.functions import col
df= spark.read.csv("/FileStore/tables/Files/Test/Employees.csv",header = "true", inferSchema ="true")
df1 = df.select(col("EMPLOYEE_ID").alias("EID"), col("FIRST_NAME").alias("FNAME"))
df1 = df1.toPandas()
df2 = df1.apply(lambda x: x.sample(frac=1).values)
mask_df = spark.createDataFrame(df2)
mask_df = df.join(mask_df, df.EMPLOYEE_ID == mask_df.EID,'left').select("EID","FNAME","FIRST_NAME")
mask_df.show()

# COMMAND ----------

#applying masking
masked_value= df.join(mask_df, df.EMPLOYEE_ID == mask_df.EID,'left').drop("FIRST_NAME","EID").withColumnRenamed("FNAME", "FIRST_NAME")
masked_value.show()

# COMMAND ----------

#applying unmasking
df_unmask=masked_value.withColumnRenamed("FIRST_NAME", "FNAME")
df_unmask.join(mask_df, df_unmask.EMPLOYEE_ID == mask_df.EID,'left').drop("FNAME","EID").show()


# COMMAND ----------

#masking with  predefined dictionary
df_dict= spark.read.csv("/FileStore/tables/Files/Test/Employee_mask_dict.csv",header = "true", inferSchema ="true")
df_dict.show()

# COMMAND ----------

#masking of Email,firstname,lastname with other value

masked_value= df.join(df_dict, df.FIRST_NAME == df_dict.FIRST_NAME,'left').drop("EMAIL","FIRST_NAME","LAST_NAME").withColumnRenamed("MASK_EMAIL", "EMAIL").withColumnRenamed("MASK_FIRSTNAME", "FIRST_NAME").withColumnRenamed("MASK_LAST_NAME", "LAST_NAME")
masked_value.show()

# COMMAND ----------

#Unmasking of columns with actual value
df_unmask=masked_value.withColumnRenamed("EMAIL", "MASK_EMAIL").withColumnRenamed("FIRST_NAME", "MASK_FIRSTNAME").withColumnRenamed("LAST_NAME", "MASK_LAST_NAME")
df_unmask.join(df_dict, df_unmask.MASK_FIRSTNAME == df_dict.MASK_FIRSTNAME,'left').drop("MASK_FIRSTNAME","MASK_LAST_NAME","MASK_EMAIL").show()