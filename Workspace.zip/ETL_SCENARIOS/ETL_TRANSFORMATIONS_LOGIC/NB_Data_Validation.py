# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ### Generic dataValidator function for spark dataframes
# MAGIC 
# MAGIC **It validates the below points-**
# MAGIC 
# MAGIC - Checks Null value for a column
# MAGIC - Checks Length for a column
# MAGIC - Checks Dateformat for a column
# MAGIC - Checks Range for a numeric column
# MAGIC - Checks Permitted values for a column
# MAGIC - Checks Regex for a column
# MAGIC 
# MAGIC 
# MAGIC Functionality Details & Constraints-
# MAGIC 
# MAGIC - It uses ConfigParser to take inputs for above validation
# MAGIC Sample of config file as DF1-
# MAGIC 
# MAGIC ```
# MAGIC [DF1]
# MAGIC Null_Check = ["Name", "EmpID"]
# MAGIC Length_Check = {"Name": 10, "EmpID": 3}
# MAGIC DateFormat_Check = {"Name": "dd/MM/yyyy", "EmpID": "dd/MM/yyyy"}
# MAGIC InList_Check =  {"Name": ["Mohit", "Rohit"]}
# MAGIC InRange_Check = {"EmpID": [102, 103]}
# MAGIC Regex_Check = {"EmpID": "^[0-9]*$"}
# MAGIC [DF4]
# MAGIC Null_Check = ["Name", "EmpID"]
# MAGIC Length_Check = {"Name": 10, "EmpID": 3}
# MAGIC DateFormat_Check = {"Name": "dd/MM/yyyy", "EmpID": "dd/MM/yyyy"}
# MAGIC InList_Check =  {"Name": ["Mohit", "Rohit"]}
# MAGIC InRange_Check = {"EmpID": [102, 103]}
# MAGIC Regex_Check = {}
# MAGIC [DF3]
# MAGIC Null_Check = []
# MAGIC Length_Check = {"Name": 10, "EmpID": 3}
# MAGIC DateFormat_Check = {"Name": "dd/MM/yyyy", "EmpID": "dd/MM/yyyy"}
# MAGIC InList_Check =  {"Name": ["Mohit", "Rohit"]}
# MAGIC InRange_Check = {"EmpID": [102, 103]}
# MAGIC Regex_Check = {"EmpID": "^[0-9]*$"}
# MAGIC 
# MAGIC ```
# MAGIC   
# MAGIC   Details on config -
# MAGIC   
# MAGIC   - It takes input in the format of field/column Names only not on field/column number
# MAGIC   - All the above mentioned check parameter must be there , can be kept empty as in DF3 and DF4
# MAGIC   - Null Check is a list , rest are dictionary parameters
# MAGIC   
# MAGIC   
# MAGIC   
# MAGIC - It uses functools reduce function to iterate and apply validation using lamda function
# MAGIC - Functionality Details 
# MAGIC 
# MAGIC  Details on functionality -
# MAGIC    - It add a new column dynamically named on the validation for the configured fields/column
# MAGIC    - Dynamic filters for bad redords and validrecords
# MAGIC    - Outputs the number of bad records
# MAGIC    - Returns the valid records & bad records dataframes 
# MAGIC  
# MAGIC  Calling the function -
# MAGIC     
# MAGIC     - It takes three inputs - Config File, Dataframe Indicator in config file and Input Dataframe
# MAGIC     - Sample of a call to the function
# MAGIC     
# MAGIC 
# MAGIC ```
# MAGIC     
# MAGIC df2 , errordf  = dataValidator ("/dbfs/FileStore/tables/Df_Valid_Config-11.txt", src_Initials= "DF1", input_df= df)
# MAGIC errordf.show()
# MAGIC df2.show()
# MAGIC 
# MAGIC ```

# COMMAND ----------

# Creating the Dataframe
def dataValidator(configfilePath, **kwargs) :
    
    from configparser import ConfigParser
    import json
    from functools import reduce
    from pyspark.sql.types import IntegerType
    import copy
    from pyspark.sql.functions import col, lit, when, length, to_date
    
    try:
        
        src = kwargs.get ('src_Initials', None)
        
        dfdfdf_xyxyxy_unique_name = kwargs.get ('input_df', None)
        
        parser = ConfigParser()
        parser.read(configfilePath)
        Null_Check = json.loads(parser.get(src, "Null_Check"))
        Length_Check = json.loads(parser.get(src, "Length_Check"))
        DateFormat_Check = json.loads(parser.get(src, "DateFormat_Check"))
        InList_Check =  json.loads(parser.get(src, "InList_Check"))
        InRange_Check = json.loads(parser.get(src, "InRange_Check"))
        Regex_Check = json.loads(parser.get(src, "Regex_Check"))
        
        
        filteror = ' '
        if (len(Null_Check) > 0):
            updated_list = [s + "_CheckNull" + " = 'true' or " for s in Null_Check]
        
            filteror2 =' '.join([str(item) for item in updated_list])
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        if (len(Length_Check) > 0):
            updated_list = {f"{k}_CheckLength = 'true' or " for k in Length_Check}
        
        
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        if (len(DateFormat_Check) > 0):
            updated_list = {f"{k}_CheckDateFormat = 'true' or " for k in DateFormat_Check}
        
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        if (len(Regex_Check) > 0):
            updated_list = {f"{k}_CheckRegex = 'true' or " for k in Regex_Check}
        
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
         
        if (len(InList_Check) > 0):
            updated_list = {k + "_CheckInList" + " = 'true' or " for k in InList_Check}
        
        
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        if (len(InRange_Check) > 0):
            updated_list = {f"{k}_CheckInRange = 'true' or " for k in InRange_Check}
        
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        
        def replace_right(source, target, replacement, replacements=None):
            return replacement.join(source.rsplit(target, replacements))
        
        filteror = replace_right(filteror, " or ", "", 1)
        
        filterand = filteror.replace(" or ", " and ").replace(" = 'true'", " is NULL")
        
        
        
        df_out = reduce(lambda dfdfdf_xyxyxy_unique_name, column: dfdfdf_xyxyxy_unique_name.withColumn(column + "_CheckNull", when(col(column).isNull(), lit("true"))), Null_Check, dfdfdf_xyxyxy_unique_name)
        
        df_out1 = reduce(lambda df_out, key: df_out.withColumn(key + "_CheckLength",when(length(col(key)) > Length_Check[key], lit("true"))), Length_Check, df_out)
        df_out2 = reduce(lambda df_out1, key: df_out1.withColumn(key + "_CheckDateFormat",when(to_date(col(key),DateFormat_Check[key]).isNull(), lit("true"))), DateFormat_Check, df_out1)
        df_out3 = reduce(lambda df_out2, key: df_out2.withColumn(key + "_CheckInList",when(~col(key).isin(InList_Check[key]) |  col(key).isNull(), lit("true"))), InList_Check, df_out2)
        
        df_out4 = reduce(lambda df_out3, key: df_out3.withColumn(key + "_CheckRegex",when(~col(key).rlike(Regex_Check[key]), lit("true"))), Regex_Check, df_out3)
        df_final = reduce(lambda df_out4, key: df_out4.withColumn(key + "_CheckInRange",when((col(key).cast('int') < copy.deepcopy(InRange_Check)[key][0] ) |  (col(key).cast('int') > copy.deepcopy(InRange_Check)[key][1]) , lit("true"))), InRange_Check, df_out4)
        
        
        df_badrecords = df_final.filter(filteror)
        
        df_validated =  df_final.filter(filterand).select(df_final.columns[:len(dfdfdf_xyxyxy_unique_name.columns)])
        
        print("Number of bad records :" ,df_badrecords.count())
                
        return df_validated, df_badrecords 
    except Exception as e:
        print("Error in Reading Source File")

# COMMAND ----------


#example for reading data with a tablename
df2 , errordf  = dataValidator ("/dbfs/FileStore/tables/Df_Valid_Config_18.txt", src_Initials= "DF4", input_df= df)
display(errordf)

display(df2)

# COMMAND ----------

# Creating dataframe

df= spark.read.csv("/FileStore/tables/Data_Validation_File.csv",header = "true", inferSchema ="false")

df.show()

# COMMAND ----------

spark.sql("set spark.sql.legacy.timeParserPolicy=CORRECTED")
source_file = spark.read.csv("/mnt/containershareddna03/Raw/claim/claim.csv",header=True,inferSchema=True)
display(source_file)

# COMMAND ----------

from pyspark.sql.functions import col,to_date
source_file=source_file.withColumn("CLAIM_SETUP_DATETIME",to_date(col("CLAIM_SETUP_DATETIME"),"MM/dd/yyyy"))
display(source_file)

# COMMAND ----------

filtered_df , errordf  = dataValidator ("/dbfs/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt", src_Initials= "claim", input_df= source_file) 
display(errordf)
        