# Databricks notebook source
 df_file_read = spark.read.load("/FileStore/tables/Sales_Records.csv",format="csv", header = "true", delimiter = ",")
  

# COMMAND ----------

df_file_read.show()


# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
from pyspark.sql.functions import when
from pyspark.sql.functions import *

df_file_read=df_file_read.withColumn('id',lit(None))
s=df_file_read.agg({"id": "max"}).collect()[0][0]
if s==None:
    s=0

DF1=df_file_read.filter(df_file_read.id.isNull()).withColumn('id',s+row_number().over(Window.orderBy('Order ID')))


Region_list = DF1.select("Region").collect()

n = 5
for i in range(n):
    print(str((i+1,Region_list[i][0])))



# COMMAND ----------

#collect() method to iterate the records
data_collect = df_file_read.collect()
 
# looping thorough each row of the dataframe
for row in data_collect:
    # while looping through each
    # row printing the data of Id, Name and City
    if row["Region"] == "Asia":
        print(row["Item Type"], row["Country"], row["Sales Channel"])
        

# COMMAND ----------

import itertools
   
# for in loop
for i in itertools.count(0, 10):
    if i == 40:
        break
    else:
        print(i, end =" ")

# COMMAND ----------

import itertools
   
count = 0
   
# for in loop
for i in itertools.cycle('ACC'):
    if count > 9:
        break
    else:
        print(i, end = " ")
        count += 1

# COMMAND ----------

# using repeat() to repeatedly print number 
print ("Printing the numbers repeatedly : ") 
print (list(itertools.repeat(25, 6)))


# COMMAND ----------

# import the product function from itertools module
from itertools import product
   
print("The cartesian product using repeat:")
print(list(product([1, 2], repeat = 2)))
print()
   
print("The cartesian product of the containers:")
print(list(product(['geeks', 'for', 'geeks'], '2')))
print()
   
print("The cartesian product of the containers:")
print(list(product('AB', [3, 4])))

# COMMAND ----------

# Running sum and multiplication
import operator
 
# initializing list 1
li1 = [1, 4, 5, 7]
   
# using accumulate()
# prints the successive summation of elements
print ("The sum after each iteration is : ", end ="")
print (list(itertools.accumulate(li1)))
   
# using accumulate()
# prints the successive multiplication of elements
print ("The product after each iteration is : ", end ="")
print (list(itertools.accumulate(li1, operator.mul)))
   


# COMMAND ----------

#Grouping
from itertools import groupby
pl = [("Meir-Huber", "Mario"), ("Meir-Huber", "Helena"), ("Some", "Other")]
for k,v in groupby(pl, lambda p: p[0]):
    print("Family {}".format(k))
    for p in v:
        print("\tFamily member: {}".format(p[1]))

# COMMAND ----------

vals = range(1,40)
for v in itertools.takewhile(lambda vl: vl<20, vals):
    print(v)
print("######")
for v in itertools.dropwhile(lambda vl: vl<20, vals):
    print(v)