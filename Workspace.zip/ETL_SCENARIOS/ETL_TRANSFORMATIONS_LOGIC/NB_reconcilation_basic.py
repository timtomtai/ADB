# Databricks notebook source
# If we have a file from client in which we got data count, we can compare that count in source file data and can print if it will not match

# COMMAND ----------

    df_cnt= spark.read.csv("/mnt/containershareddna02/cnt_file.csv",header = "true", inferSchema = "true")
    df_cnt = df_cnt.select("rec_count").filter("fileName = 'Covid_Ohio_state_join'")
    cnt_val = df_cnt.select('rec_count').collect()[0].asDict()['rec_count'] # this will store count va


    df_001= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_join.csv",header = "true")
    df_cnt_val = df_001.count() #368

    if cnt_val == df_cnt_val:
        print("Count matched")
    else:
        print("Count not matched")


# COMMAND ----------

def verifyCount(cntFilePath,sourceFilePath,sourceFileName):
    from pyspark.sql.functions import col
    df_cnt= spark.read.csv(cntFilePath,header = "true", inferSchema = "true")
    df_cnt = df_cnt.select("rec_count").filter(col("fileName") == sourceFileName) #can take column names in parameters
    cnt_val = df_cnt.select('rec_count').collect()[0].asDict()['rec_count'] # this will store count value

    df_001= spark.read.csv(sourceFilePath,header = "true")
    df_cnt_val = df_001.count() #368

    if cnt_val == df_cnt_val:
        print("Count matched")
    else:
        print("Count not matched")

# COMMAND ----------

verifyCount("/mnt/containershareddna02/cnt_file.csv","/mnt/containershareddna02/Covid_Ohio_state_f7.csv","Covid_Ohio_state_join")