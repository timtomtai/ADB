# Databricks notebook source
# How to sort data in data frame
# syntax is - sort(*cols, **kwargs)

# COMMAND ----------

df1 = spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_join.csv",header = "true", inferSchema ="true")

# COMMAND ----------

df = spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_join.csv",header = "true", inferSchema ="true").select('date','state','death','deathIncrease','hospitalized').filter('deathIncrease > 0')
df.show()

# COMMAND ----------

# this is sorted by date and hospitalized, By default, it sorts by ascending order.
df.sort("date","hospitalized").show()

# COMMAND ----------

# another way of sorting - using col , orderBy
from pyspark.sql.functions import col, asc,desc
df.orderBy(col("death"),col("hospitalized")).show()

# COMMAND ----------

# another way of sorting - using orderBy
from pyspark.sql.functions import col, asc,desc
df.orderBy(col("death").desc(),col("hospitalized").asc()).show()

# COMMAND ----------

# we can give desc() or asc() for sorting
df.sort(df.death.desc(),df.hospitalized.asc()).show()

# COMMAND ----------

# using spark.sql
df1.createOrReplaceTempView("COVID_DATA")
spark.sql("select date,state,death,deathConfirmed,deathIncrease,deathProbable,hospitalized from COVID_DATA ORDER BY date asc").show()

# COMMAND ----------

