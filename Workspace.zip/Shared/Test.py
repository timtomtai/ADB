# Databricks notebook source
# MAGIC %sql Select test