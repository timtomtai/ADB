# Databricks notebook source

dbutils.fs.mount(
  source = "wasbs://containershareddna02@sashareddna01.blob.core.windows.net",
  mount_point = "/mnt/ady_container_mntpt",
  extra_configs = {"fs.azure.account.key.sashareddna01.blob.core.windows.net":dbutils.secrets.get(scope = "scopedna01", key = "adysecret")})

# COMMAND ----------

df= spark.read.csv("/mnt/containershareddna02/Covid_Ohio*.csv",header = "true", sep = ",")

# COMMAND ----------

df.show(2)

# COMMAND ----------

# dbutils.help()
# dbutils.fs.help()
dbutils.fs.ls('/FileStore/tables/oss')
# dbutils.fs.mv('/FileStore/tables/userdata2.parquet','/FileStore/tables/oss/')
# dbutils.fs.mv('/FileStore/tables/userdata3.parquet','/FileStore/tables/oss/')
# dbutils.fs.mv('/FileStore/tables/userdata4.parquet','/FileStore/tables/oss/')
# dbutils.fs.mv('/FileStore/tables/userdata5.parquet','/FileStore/tables/oss/')

# dbutils.fs.mkdirs('/FileStore/tables/oss');
import os
from datetime import datetime , timedelta
path = '/dbfs/FileStore/tables/oss'
fdpaths = [path+"/"+fd for fd in os.listdir(path)]

qualified_files = []
# print(type(qualified_files), type(fdpaths))
lookback_hour_ago = datetime.now()- timedelta(hours = 16)
# print(lookback_hour_ago)

for fdpath in fdpaths:
    statinfo = os.stat(fdpath)
    modified_date = datetime.fromtimestamp(statinfo.st_mtime)
#     print("Modified date of file of path %s is %s " % (fdpath, modified_date))
    if modified_date>=lookback_hour_ago:
        qualified_files.append(fdpath)

        
print(qualified_files)
    



# COMMAND ----------

