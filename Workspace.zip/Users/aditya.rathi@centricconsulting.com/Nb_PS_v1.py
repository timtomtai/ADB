# Databricks notebook source
import pyspark ;
from pyspark.sql import *;
from pyspark.sql.functions import *;
from pyspark.sql.types import *;
import os;
from datetime import date, datetime, timedelta;
from configparser import ConfigParser;
from glob import *;
import glob;
from pathlib import Path;

spark = SparkSession.builder.appName('TeamC').master('master').getOrCreate()
config_path = '/dbfs/FileStore/tables/oss/pyspark_config_teamc.ini'




# ini_parser = ConfigParser()
# ini_parser.read(config_path)
# path = ini_parser.get('FILE_OSS','path')
# today = date.today()

# files_at_path= [path+"/"+fd for fd in os.listdir(path)]

# csv_qualified_files = [];
# parquet_qualified_files = [];
# csv_current_date_files =[];
# parquet_current_date_files =[];

# for file in files_at_path:
#     get_stats = os.stat(file)
#     get_file_last_modified_date = datetime.fromtimestamp(get_stats.st_mtime)
#     get_file_last_modified_date_short = date.fromtimestamp(get_stats.st_mtime)
#     if get_file_last_modified_date_short == today:
#         if file.endswith('.csv'):
#             csv_current_date_files.append(file)
#         elif file.endswith('.parquet'):
#             parquet_current_date_files.append(file)

# print(csv_current_date_files)





# COMMAND ----------

