# Databricks notebook source
> TASK1_  Reading various file source- csv , json, parquet	C

> TASK2_  Dynamic File Reading > Latest file & Current Date & Current Week & Back period	C


# COMMAND ----------



# COMMAND ----------

config_path = '/dbfs/FileStore/tables/oss/pyspark_config_teamc.ini'
# regex = '.*yellow_trip_taxi_\d{8}\.csv$'
regex = '.*userdata\d+\.parquet$'
p_sep = ','

def get_df_qualified_files_lookback(var_config_path,regex):
    import pyspark ;
    from pyspark.sql import SparkSession;
    import os;
    from datetime import date,datetime, timedelta;
    from configparser import ConfigParser;
    import re;
    spark = SparkSession.builder.appName('TeamC').master('local').getOrCreate()
    ini_parser = ConfigParser()
    ini_parser.read(var_config_path)
    pass_hours =int(ini_parser.get('FILE_OSS','pass_hours'))
    path = ini_parser.get('FILE_OSS','path')
    lookback_period = datetime.now() - timedelta(hours =pass_hours)
    files_at_path= [path+"/"+fd for fd in os.listdir(path)]
    qualified_files =[];
    pattern = re.compile(r''+regex+'')
    for file in files_at_path:
        get_stats = os.stat(file)
        file_last_modified_date = datetime.fromtimestamp(get_stats.st_mtime)
        if (file_last_modified_date >= lookback_period ):
            file = file.replace('/dbfs','')
            qualified_files.append(file)
            qualified_files = [s for s in qualified_files if pattern.match(s)]
            
    extension = os.path.splitext(qualified_files[1])[1][1:]
    out_df_files= spark.read.format(r''+extension+'').option("header","true").load(qualified_files,sep=p_sep);
    return out_df_files;
    
df = get_df_qualified_files_lookback(config_path,regex)

df.show()


# COMMAND ----------


dbutils.fs.rm('/FileStore/tables/oss/pyspark_config_teamc.ini')
# dbutils.fs.help()

# COMMAND ----------

'''
Bug = it appends all csv files irrespective of the schema.. which is bad.

While using the code, do mention the REGEX on the files which are required by business scenario. 
'''


import pyspark ;
from pyspark.sql import *;
from pyspark.sql.functions import *;
from pyspark.sql.types import *;
import os;
from datetime import date, datetime, timedelta;
from configparser import ConfigParser;
from glob import *
import re;
spark = SparkSession.builder.appName('TeamC').master('master').getOrCreate()
config_path = '/dbfs/FileStore/tables/oss/pyspark_config_teamc.ini' 

def get_df_csv_parquet_files(var_config_path):
    ini_parser = ConfigParser()
    ini_parser.read(var_config_path)
    pass_hours =int(ini_parser.get('FILE_OSS','pass_hours'))
    path = ini_parser.get('FILE_OSS','path')
    lookback_period = datetime.now() - timedelta(hours =pass_hours)
    today = date.today()
#     regex_csv = '[\/]*[\w]*[01]*[yellow_trip_taxi_*.csv]'
    
#     print(path, '\n',lookback_period)
    
    
    files_at_path= [path+"/"+fd for fd in os.listdir(path)]
#     print(type(files_at_path), '\n',files_at_path)

    csv_qualified_files = [];
    parquet_qualified_files = [];
    csv_current_date_files =[];
    parquet_current_date_files =[];
    
    for file in files_at_path:
        get_stats = os.stat(file)
        get_file_last_modified_date = datetime.fromtimestamp(get_stats.st_mtime)
        get_file_last_modified_date_short = date.fromtimestamp(get_stats.st_mtime)
        if get_file_last_modified_date >= lookback_period:
            if file.endswith('.csv'):
                csv_qualified_files.append(file)
            elif file.endswith('.parquet'):
                parquet_qualified_files.append(file)
        if get_file_last_modified_date_short == today:
            if file.endswith('.csv'):
                csv_current_date_files.append(file)
            elif file.endswith('.parquet'):
                parquet_current_date_files.append(file)

    mod_parquet_qualified_files =[]
    mod_csv_qualified_files =[]
    mod_csv_current_date_files =[]

    for char in parquet_qualified_files:
        text = char.replace('/dbfs','')
        mod_parquet_qualified_files.append(text)

    for char in csv_qualified_files:
        text = char.replace('/dbfs','')
        mod_csv_qualified_files.append(text)
    
    for char in csv_current_date_files:
        text = char.replace('/dbfs','')
        mod_csv_current_date_files.append(text)
    out_df_csv_current_date_qualified_files= spark.read.format('csv').option("header","true").load(mod_csv_current_date_files,sep=',');
    
#     return out_df_csv_qualified_files, out_df_parquet_qualified_files, out_df_csv_current_date_qualified_files;
    return out_df_csv_current_date_qualified_files;
 

    
    
# df_csv, df_parquet, df_csv_current_date = get_df_csv_parquet_files(config_path)
df_csv_current_date = get_df_csv_parquet_files(config_path)

# df_csv.show(10)
# df_parquet.show(10)
df_csv_current_date.show(10)

# COMMAND ----------

def get_df_regex_csv_parquet_files(var_config_path):
    """
    Get DF as output for CSV, PARQUET file types.  [json to be merged in this]
    Input parameters required = 1. Config path location which contains PATH, LOOKBACKPERIOD.
                                2. Regex of CSV, JSON, PARQUET
    
    Output Df= 1. CSV qualified for Regex and lookback period
               2. PARQUET qualified for Regex and lookback period
               3. JSON qualified for Regex and lookback period
               
               ~~~~~~~~
               
                Limited to CSV functionality
               4. get Current date files
               5. get Current Week files
    
    """
    import pyspark ;
    from pyspark.sql import SparkSession;
    import os;
    from datetime import datetime, timedelta;
    from configparser import ConfigParser;
    from glob import glob, iglob;
    import re;
    spark = SparkSession.builder.appName('TeamC').master('master').getOrCreate()
    config_path = '/dbfs/FileStore/tables/oss/pyspark_config_teamc.ini'
    ini_parser = ConfigParser()
    ini_parser.read(var_config_path)
    pass_hours =int(ini_parser.get('FILE_OSS','pass_hours'))
    path = ini_parser.get('FILE_OSS','path')
    lookback_period = datetime.now() - timedelta(hours =pass_hours)
    regex_csv = '.*yellow_trip_taxi_\d{8}\.csv$'
    regex_parquet = '.*userdata\d+\.parquet$'
#     print(path, '\n',lookback_period)
    
    
    files_at_path= [path+"/"+fd for fd in os.listdir(path)]
#     print(type(files_at_path), '\n',files_at_path)

    csv_qualified_files = [];
    parquet_qualified_files = [];
    csv_qualified_files.clear();
    parquet_qualified_files.clear();

    for file in files_at_path:
        get_stats = os.stat(file)
        get_file_last_modified_date = datetime.fromtimestamp(get_stats.st_mtime)
        if get_file_last_modified_date >= lookback_period:
            if file.endswith('.csv'):
                csv_qualified_files.append(file)
            elif file.endswith('.parquet'):
                parquet_qualified_files.append(file)
                """
                ADD HERE JSON CODE FOR FILTERING
                """

    mod_parquet_qualified_files =[]
    mod_csv_qualified_files =[]

    for char in parquet_qualified_files:
        text = char.replace('/dbfs','')
        mod_parquet_qualified_files.append(text)

    for char in csv_qualified_files:
        text = char.replace('/dbfs','')
        mod_csv_qualified_files.append(text)
     
    """
    ADD HERE JSON CODE FOR REPLACING
    """
        
    print('$$$ CSV \n',mod_csv_qualified_files)
    print('$$$ parq \n',mod_parquet_qualified_files)
    
    pattern_csv = re.compile(r''+regex_csv+'')
    files_at_path_regex_pattern_csv = [s for s in mod_csv_qualified_files if pattern_csv.match(s)]
    print('###CSV REGEX OUT FILES#### \n',files_at_path_regex_pattern_csv)
    
    pattern_parquet = re.compile(r''+regex_parquet+'')
    files_at_path_regex_pattern_parquet = [s for s in mod_parquet_qualified_files if pattern_parquet.match(s)]
    print('###parq REGEX OUT FILES#### \n',files_at_path_regex_pattern_parquet)
    
    """
    ADD HERE JSON CODE FOR REGEX
    """
    

    out_df_csv_qualified_files= spark.read.format('csv').option("header","true").load(files_at_path_regex_pattern_csv,sep=',');
    out_df_parquet_qualified_files= spark.read.format('parquet').option("header","true").load(mod_parquet_qualified_files,sep=',');

    return out_df_csv_qualified_files, out_df_parquet_qualified_files;
    
df_csv, df_parquet = get_df_csv_parquet_files(config_path)

df_csv.show(1)
df_parquet.show(1)

# COMMAND ----------

