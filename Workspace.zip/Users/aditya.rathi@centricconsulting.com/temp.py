# Databricks notebook source
dbutils.fs.ls('/FileStore/tables/oss')


# COMMAND ----------

import pyspark ;
from pyspark.sql import SparkSession;

df= spark.read.format('csv').option("header","true").load('/mnt/containershareddna01/teamC_storage/cars.csv',delimiter=',');
df2= spark.read.format('csv').option("header","true").load('/mnt/containershareddna01/teamC_storage/cars2.csv',delimiter=',', quotechar='"');


df.show(5)


df2.show(5)



# COMMAND ----------



# COMMAND ----------

print(__name__)

# COMMAND ----------

