# Databricks notebook source
import sys
# We are inserting below sys path so that we can import any python file from this location
sys.path.insert(0,'/dbfs/FileStore/tables/DataEng/RawtoStg/')

import logging
from config.logging_init_file import init_loging
from config.rawToStgAbstract import rawToStgAbstract
from config.data_validator import dataValidator
from config.part_filemover import partfilemover
from pyspark.sql import SparkSession 
import glob
import shutil
from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import to_date,col
from pyspark.sql.types import StructType,StringType,TimestampType,DecimalType,IntegerType,StructField

class claimcontrolRawtoStg(rawToStgAbstract):
    def __init__(self,src,dst):
        self.logger, self.file_name = init_loging(__name__)
        self.logger.info("Started Initializing....")
        self.source_path = [i.replace('/dbfs','') for i in glob.glob('/dbfs'+src+'/*.*')]
        self.ini_source_path = '/dbfs'+src
        self.logger.info(self.source_path)
        self.dest_path = dst  
        self.spark = SparkSession.builder.master("master").appName(__name__).enableHiveSupport().getOrCreate()
        self.logger.info("Initialization is completed")

    def read(self):
        self.logger.info("Started Reading file of input file")
        try:
            source_format = "csv" # This can be "csv", "json", "parquet" depending upon the source file
            source_delimiter = "," # This can be "," or anyother delimiter or None
            source_header = True # This can be True or False or None
            self.source_file = self.spark.read.load(self.source_path,
                     format=source_format, delimiter=source_delimiter, header=source_header)
            self.logger.info("Reading of input file is completed")
        except:
            self.logger.critical("Issue in reading the input file")

    def validate(self):
        self.dq_config_parser_name ="claim_control"
        self.logger.info("Started data validation")
        filtered_df , errordf  = dataValidator ("/dbfs/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt", src_Initials= self.dq_config_parser_name, input_df= self.source_file) 
        errordf.toPandas().to_csv("/dbfs/mnt/containershareddna03/logs/Data_Validation_Logs/claim_control/"+self.file_name+".csv")
        self.logger.info("Number of bad records: ",errordf.count())
        self.logger.info("Data validation is completed")

    def trans(self):
        self.logger.info("Started Data transformation")
        self.source_file = self.source_file.withColumn('CLAIMLNMASTER_ID',col('CLAIMLNMASTER_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMLNIMAGE_NUM',col('CLAIMLNIMAGE_NUM').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLIENT_ID',col('CLIENT_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('POLICY_ID',col('POLICY_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('POLICYIMAGE_NUM',col('POLICYIMAGE_NUM').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('LOSS_DATETIME',unix_timestamp(col('LOSS_DATE'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('LOSS_ADDRESS_ID',col('LOSS_ADDRESS_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('REPORTED_DATETIME',unix_timestamp(col('REPORTED_DATE'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIMREPORTEDBY_ID',col('CLAIMREPORTEDBY_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMREPORTEDBYMETHOD_ID',col('CLAIMREPORTEDBYMETHOD_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIM_TYPE_ID',col('CLAIM_TYPE_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMSEVERITY_ID',col('CLAIMSEVERITY_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMADMINISTRATOR_ID',col('CLAIMADMINISTRATOR_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMASSISTANT_ID',col('CLAIMASSISTANT_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('INSIDE_ADJUSTER_ID',col('INSIDE_ADJUSTER_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('OUTSIDE_ADJUSTER_ID',col('OUTSIDE_ADJUSTER_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMOFFICE_ID',col('CLAIMOFFICE_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMCATASTROPHE_ID',col('CLAIMCATASTROPHE_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('ADDED',unix_timestamp(col('ADDED'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('LAST_TRANSACTION_DATETIME',unix_timestamp(col('LAST_TRANSACTION_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIMCONTROLSTATUS_ID',col('CLAIMCONTROLSTATUS_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMFINANCIALS_NUM',col('CLAIMFINANCIALS_NUM').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMLOSSTYPE_ID',col('CLAIMLOSSTYPE_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMFAULT_ID',col('CLAIMFAULT_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('ADDED_DATETIME',unix_timestamp(col('ADDED_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('PCADDED_DATETIME',unix_timestamp(col('PCADDED_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('LOSSTIMEGIVEN',col('LOSSTIMEGIVEN').cast(Bit()))
        self.source_file = self.source_file.withColumn('CLAIMCONTACT_ID',col('CLAIMCONTACT_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('IS_CONVERTED',col('IS_CONVERTED').cast(Bit()))
        self.source_file = self.source_file.withColumn('CLAIMPOLICEDEPT_ID',col('CLAIMPOLICEDEPT_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMPOLICEOFFICER_ID',col('CLAIMPOLICEOFFICER_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMFIREDEPT_ID',col('CLAIMFIREDEPT_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('POLICE_NOTIFIED',col('POLICE_NOTIFIED').cast(Bit()))
        self.source_file = self.source_file.withColumn('CLAIMCLUEDISP_ID',col('CLAIMCLUEDISP_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMCLOSEREASON_ID',col('CLAIMCLOSEREASON_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('LAST_MODIFIED_DATETIME',unix_timestamp(col('LAST_MODIFIED_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('DESTRUCTION_DATETIME',unix_timestamp(col('DESTRUCTION_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('PACKAGEPART_NUM',col('PACKAGEPART_NUM').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('REPORTED_TO_ISO_DATE',unix_timestamp(col('REPORTED_TO_ISO_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('REPORTED_TO_ISO_LAST_SUBMITTED_DATE',unix_timestamp(col('REPORTED_TO_ISO_LAST_SUBMITTED_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('EXTERNAL_POLICY_VERSION_NUMBER',col('EXTERNAL_POLICY_VERSION_NUMBER').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('EXTERNAL_POLICYSYSTEM_IDENTIFIER',col('EXTERNAL_POLICYSYSTEM_IDENTIFIER').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('ORIGINAL_ISO_LOSS_DATE',unix_timestamp(col('ORIGINAL_ISO_LOSS_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIMLIABILITYDECISION_PERCENTAGE',col('CLAIMLIABILITYDECISION_PERCENTAGE').cast(DecimalType()))
        self.source_file = self.source_file.withColumn('CLAIMLIABILITYDECISION_USER_ID',col('CLAIMLIABILITYDECISION_USER_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMLIABILITYDECISION_ADDED_DATE',unix_timestamp(col('CLAIMLIABILITYDECISION_ADDED_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIMLIABILITYDECISIONTYPE_ID',col('CLAIMLIABILITYDECISIONTYPE_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMLOSSDESCRIPTIONTYPE_ID',col('CLAIMLOSSDESCRIPTIONTYPE_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMDENIAL_DATE',unix_timestamp(col('CLAIMDENIAL_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIMDENIALUSERS_ID',col('CLAIMDENIALUSERS_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMDENIALREASON_ID',col('CLAIMDENIALREASON_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('ILLNESS_START_DATE',unix_timestamp(col('ILLNESS_START_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('HOSPITAL_DURATION_DAYS',col('HOSPITAL_DURATION_DAYS').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('HOSPITAL_DISCHARGE_DATE',unix_timestamp(col('HOSPITAL_DISCHARGE_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('HOSPITAL_ADMITTANCE_DATE',unix_timestamp(col('HOSPITAL_ADMITTANCE_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIM_AMOUNT_REQUESTED',col('CLAIM_AMOUNT_REQUESTED').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CCR2_YESNO_ID',col('CCR2_YESNO_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CCR1_YESNO_ID',col('CCR1_YESNO_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('CLAIMCLOSEISSUETYPE_ID',col('CLAIMCLOSEISSUETYPE_ID').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('REPORTED_TO_NCCI_DATE',unix_timestamp(col('REPORTED_TO_NCCI_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('VERSION_BEGIN_TIMESTAMP',unix_timestamp(col('VERSION_BEGIN_TIMESTAMP'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('VERSION_END_TIMESTAMP',unix_timestamp(col('VERSION_END_TIMESTAMP'), 'yyyy-MM-dd').cast(TimestampType()))
        self.logger.info("Completed Data transformation")

    def store(self):
        self.logger.info("Started storing the file")
        self.source_file.write.mode("Overwrite").parquet(self.dest_path)
        source_file_pattern = "/*.csv"
        target_file_path = self.ini_source_path+'/processed'
        self.logger.info(target_file_path)
        self.logger.info(self.ini_source_path)
        partfilemover(self.ini_source_path,source_file_pattern,target_file_path)
        #shutil.move("/dbfs"+self.source_path,"/dbfs/mnt/containershareddna03/Raw/claim_control/processed/"+self.file_name+"claim.csv")
        self.logger.info("Storing of file is completed")