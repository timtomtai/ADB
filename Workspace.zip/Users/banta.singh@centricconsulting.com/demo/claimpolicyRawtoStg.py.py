# Databricks notebook source
import sys
# We are inserting below sys path so that we can import any python file from this location
sys.path.insert(0,'/dbfs/FileStore/tables/DataEng/RawtoStg/')

import logging
from config.logging_init_file import init_loging
from config.rawToStgAbstract import rawToStgAbstract
from config.data_validator import dataValidator
from config.part_filemover import partfilemover
from pyspark.sql import SparkSession 
import glob
import shutil
from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import to_date,col
from pyspark.sql.types import StructType,StringType,TimestampType,DecimalType,IntegerType,StructField,LongType

class claimpolicyRawtoStg(rawToStgAbstract):
    def __init__(self,src,dst):
        self.logger, self.file_name = init_loging(__name__)
        self.logger.info("Started Initializing....")
        self.source_path = [i.replace('/dbfs','') for i in glob.glob('/dbfs'+src+'/*.*')]
        self.ini_source_path = '/dbfs'+src
        self.logger.info(self.source_path)
        self.dest_path = dst  
        self.spark = SparkSession.builder.master("master").appName(__name__).enableHiveSupport().getOrCreate()
        self.logger.info("Initialization is completed")

    def read(self):
        self.logger.info("Started Reading file of input file")
        try:
            source_format = "csv" # This can be "csv", "json", "parquet" depending upon the source file
            source_delimiter = "," # This can be "," or anyother delimiter or None
            source_header = True # This can be True or False or None
            self.source_file = self.spark.read.load(self.source_path,
                     format=source_format, delimiter=source_delimiter, header=source_header)
            self.logger.info("Reading of input file is completed")
        except:
            self.logger.critical("Issue in reading the input file")

    def validate(self):
        self.dq_config_parser_name ="claim_policy"
        self.logger.info("Started data validation")
        filtered_df , errordf  = dataValidator ("/dbfs/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt", src_Initials= self.dq_config_parser_name, input_df= self.source_file) 
        errordf.toPandas().to_csv("/dbfs/mnt/containershareddna03/logs/Data_Validation_Logs/claim_policy/"+self.file_name+".csv")
        self.logger.info("Number of bad records: ",errordf.count())
        self.logger.info("Data validation is completed")

    def trans(self):
        self.logger.info("Started Data transformation")
        self.source_file = self.source_file.withColumn('POLICY_ID',col('POLICY_ID').cast(LongType()))
        self.source_file = self.source_file.withColumn('POLICY_EFFECTIVE_DATE',unix_timestamp(col('POLICY_EFFECTIVE_DATE'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('BUSINESS_EFFECTIVE_BEGIN_DATETIME',unix_timestamp(col('BUSINESS_EFFECTIVE_BEGIN_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('BUSINESS_EFFECTIVE_END_DATETIME',unix_timestamp(col('BUSINESS_EFFECTIVE_END_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('LASTMODIFIED',unix_timestamp(col('LASTMODIFIED'), 'yyyy-MM-dd').cast(TimestampType()))
        self.logger.info("Completed Data transformation")

    def store(self):
        self.logger.info("Started storing the file")
        self.source_file.write.mode("Overwrite").parquet(self.dest_path)
        source_file_pattern = "/*.csv"
        target_file_path = self.ini_source_path+'/processed'
        self.logger.info(target_file_path)
        self.logger.info(self.ini_source_path)
        partfilemover(self.ini_source_path,source_file_pattern,target_file_path)
        #shutil.move("/dbfs"+self.source_path,"/dbfs/mnt/containershareddna03/Raw/claim/processed/"+self.file_name+"claim.csv")
        self.logger.info("Storing of file is completed")