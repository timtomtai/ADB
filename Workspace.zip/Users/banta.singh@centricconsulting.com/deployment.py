# Databricks notebook source


# COMMAND ----------

File uploaded to /FileStore/tables/DataEng/RawtoStg/config/controllerRawToStg.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/config/data_quality_config-1.txt
File uploaded to /FileStore/tables/DataEng/RawtoStg/addressRawtoStg-1.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/claimactivitycodeRawtoStg.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/ClaimantAddressLinkRawtoStg_py.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/claimantRawtoStg.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/claimanttypeRawToStg.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/claimcontrolactivityRawToStg-1.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/claimfeatureRawtoStg-1.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/claimcontrolRawtoStg.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/claimpolicyRawtoStg.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/claimRawtoStg-1.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/claimtransRawToStg-1.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/controllerRawToStg-1.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/NameRawtoStg.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/sexRawtoStg.py

# COMMAND ----------

dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/config/data_quality_config-1.txt", "/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt")

dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/addressRawtoStg-1.py", "/FileStore/tables/DataEng/RawtoStg/addressRawtoStg.py")

dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/ClaimantAddressLinkRawtoStg_py.py", "/FileStore/tables/DataEng/RawtoStg/ClaimantAddressLinkRawtoStg.py")

dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/claimcontrolactivityRawToStg-1.py", "/FileStore/tables/DataEng/RawtoStg/claimcontrolactivityRawToStg.py")

dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/claimfeatureRawtoStg-1.py", "/FileStore/tables/DataEng/RawtoStg/claimfeatureRawtoStg.py")

dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/claimRawtoStg-1.py", "/FileStore/tables/DataEng/RawtoStg/claimRawtoStg.py")

dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/claimtransRawToStg-1.py", "/FileStore/tables/DataEng/RawtoStg/claimtransRawToStg.py")

dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/controllerRawToStg-1.py", "/FileStore/tables/DataEng/RawtoStg/controllerRawToStg.py")




# COMMAND ----------

File uploaded to /FileStore/tables/DataEng/RawtoStg/claimanttypeRawtoStg.py
File uploaded to /FileStore/tables/DataEng/RawtoStg/controllerRawToStg-1.py

# COMMAND ----------

#dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/controllerRawToStg__2_.py", "/FileStore/tables/DataEng/RawtoStg/controllerRawToStg.py")

# COMMAND ----------

dbutils.fs.mv("/FileStore/tables/DataEng/StgtoInt/controllerStgToInt-1.py", "/FileStore/tables/DataEng/StgtoInt/controllerStgToInt.py")

# COMMAND ----------

#dbutils.fs.rm("/FileStore/tables/DataEng/RawtoStg/controllerRawToStg.py")

# COMMAND ----------

#dbutils.fs.rm("/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt")

# COMMAND ----------

#dbutils.fs.rm("/FileStore/tables/DataEng/StgtoInt/controllerStgToInt.py")
dbutils.fs.rm("/FileStore/tables/DataEng/StgtoInt/ClaimTransactionStgToInt.py")

# COMMAND ----------


df_001= spark.read.csv("/mnt/containershareddna03/Raw/claim_policy/claim_policy.csv",header = "true")
df_001.show(10)

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import StructType,StringType,TimestampType,DecimalType,IntegerType,StructField,LongType
df_001 = df_001.withColumn("POLICY_EFFECTIVE_DATE",col("POLICY_EFFECTIVE_DATE").cast(TimestampType()))
df_001 = df_001.withColumn("BUSINESS_EFFECTIVE_BEGIN_DATETIME",col("BUSINESS_EFFECTIVE_BEGIN_DATETIME").cast(TimestampType()))
df_001 = df_001.withColumn("BUSINESS_EFFECTIVE_END_DATETIME",col("BUSINESS_EFFECTIVE_END_DATETIME").cast(TimestampType()))

df_001.show(10)