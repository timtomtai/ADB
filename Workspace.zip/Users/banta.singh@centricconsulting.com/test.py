# Databricks notebook source


# COMMAND ----------

df_claim= spark.read.csv('/mnt/containershareddna03/Raw/claim/claim_202203141647250662.csv',header="true",inferSchema ="false")
df = df_claim
display(df_claim)

# COMMAND ----------

