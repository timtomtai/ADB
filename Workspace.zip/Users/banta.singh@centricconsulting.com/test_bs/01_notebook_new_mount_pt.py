# Databricks notebook source
dbutils.fs.mount(
  source = "wasbs://containershareddna02@sashareddna01.blob.core.windows.net",
  mount_point = "/mnt/containershareddna03",
  extra_configs = {"fs.azure.account.key.sashareddna01.blob.core.windows.net":dbutils.secrets.get(scope = "scopedna01", key = "secret03")})


# COMMAND ----------

df= spark.read.csv("/mnt/containershareddna02/Covid_Ohio*.csv",header = "true", sep = "|")
df.show()

# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

dbutils.fs.unmount("/mnt/containershareddna03")

# COMMAND ----------

# MAGIC %fs ls /mnt/containershareddna02

# COMMAND ----------

df= spark.read.csv("/mnt/containershareddna02/Covid_Ohio*.csv",header = "true", sep = "|")
df.show()

# COMMAND ----------

