# Databricks notebook source


# COMMAND ----------

config_path = '/dbfs/FileStore/tables/oss/pyspark_config_teamc.ini'

def configFile(configPath):
    import pyspark ;
    from pyspark.sql import SparkSession;
    import os;
    from configparser import ConfigParser;
    import re;
    ## Assign values
    iniParser = ConfigParser()
    iniParser.read(configPath)
    path = ini_parser.get('FILE_OSS','path')
    
    for file in files_at_path:
        get_stats = os.stat(file)
        file_last_modified_date = datetime.fromtimestamp(get_stats.st_mtime)
        get_file_last_modified_date_short = date.fromtimestamp(get_stats.st_mtime)
        
        if date_format=='period':
            if (file_last_modified_date >= lookback_period ):
                file = file.replace('/dbfs','')
                qualified_files.append(file)
                qualified_files = [s for s in qualified_files if pattern.match(s)]
        elif date_format=='current_date':
            if (get_file_last_modified_date_short == today):
                file = file.replace('/dbfs','')
                qualified_files.append(file)
                qualified_files = [s for s in qualified_files if pattern.match(s)]
        elif date_format=='current_week':
            if (file_last_modified_date >= now_day_1):
                file = file.replace('/dbfs','')
                qualified_files.append(file)
                qualified_files = [s for s in qualified_files if pattern.match(s)]
    ##check for file extension and read the files   
    if qualified_files!=[]:
        extension = os.path.splitext(qualified_files[1])[1][1:]
        print(extension)
        out_df_files= spark.read.format(r''+extension+'').option("header","true").load(qualified_files);
    else:
        out_df_files= spark.sparkContext.emptyRDD();
        print('No files present');
        
    return out_df_files;

## call function
df = get_df_qualified_files(config_path,regex,date_format)

df.show()