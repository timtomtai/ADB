# Databricks notebook source


# COMMAND ----------

mount_var = "/mnt/containershareddna01/DATA_SOU*.csv"
df_001= spark.read.csv(mount_var,header = "true").select("Name").filter("Name = 'Rohit'")
df_001.show()

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

        dateTimeObj = datetime.now()
        data2 = [(1,'dummy','Done',dateTimeObj)
                ]
        schema = StructType([ \
                 StructField("Cnt",StringType(),True), \
                 StructField("fileName",StringType(),True), \
                 StructField("Status",StringType(),True), \
                 StructField("timestamp",TimestampType(),True), \
                            ])
 
        df = spark.createDataFrame(data=data2,schema=schema)
        df.write.format("delta").mode("append").saveAsTable("log_file_bs")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from log_file_bs ;
# MAGIC --delete from log_file_bs;

# COMMAND ----------

## import lit from sql functions - useful to add withcolumn a constant value
# from pyspark.sql.functions import lit
from datetime import datetime
from pyspark.sql.types import StructType,StructField, StringType, IntegerType
from pyspark.sql.functions import *
from pyspark.sql.types import TimestampType
## Provide mount with directory where the files exists
mount_path = "/mnt/containershareddna02"
file_Tpath = "/mnt/containershareddna02/Target_dir/"
file_name  = "Covid_Ohio_state_f"
## loop through the files 
for file in dbutils.fs.ls(mount_path):
    if file_name in file.name:
        df_001= spark.read.csv(f'{mount_path}/{file.name}',header = "true",inferSchema ="true")
        df_cnt = df_001.count()
        df_fine_name = file.name
        # This will move the file into Target dir and after this datafrave will be invalid and will not be able to read file at source dir. This is the reason we are saving count and file name before this file movement
        dbutils.fs.mv(f'{mount_path}/{file.name}', f'{file_Tpath}/{file.name}')

        dateTimeObj = datetime.now()
        data2 = [(df_cnt,df_fine_name,'Done',dateTimeObj)
                ]

        schema = StructType([ \
                 StructField("Cnt",StringType(),True), \
                 StructField("fileName",StringType(),True), \
                 StructField("Status",StringType(),True), \
                 StructField("current_time",TimestampType(),True), \
                            ])
 
        df = spark.createDataFrame(data=data2,schema=schema)
        df.write.format("delta").mode("append").saveAsTable("log_file_bs")
    

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from log_file_bs ;
# MAGIC --delete from log_file_bs;
# MAGIC --drop table log_file_bs;

# COMMAND ----------

def fileArchiveAndLogging(mount_path, file_Tpath, file_name) :
        ## import lit from sql functions - useful to add withcolumn a constant value
        # from pyspark.sql.functions import lit
        from datetime import datetime
        from pyspark.sql.types import StructType,StructField, StringType, IntegerType
        # from pyspark.sql.functions import *
        from pyspark.sql.types import TimestampType
        try:

        ## Provide mount with directory where the files exists
    
        # mount_path = "/mnt/containershareddna02"
        # file_Tpath = "/mnt/containershareddna02/Target_dir/"
        # file_name  = "Covid_Ohio_state_f"
        
        ## loop through the files 
            for file in dbutils.fs.ls(mount_path):
                if file_name in file.name:
                    df_001= spark.read.csv(f'{mount_path}/{file.name}',header = "true",inferSchema ="true")
                    df_cnt = df_001.count()
                    df_fine_name = file.name
                # This will move the file into Target dir and after this datafrave will be invalid and will not be able to read file at source dir. 
                # This is the reason we are saving count and file name before this file movement
                    dbutils.fs.mv(f'{mount_path}/{file.name}', f'{file_Tpath}/{file.name}')

                    dateTimeObj = datetime.now()
                    # this is list
                    data2 = [(df_fine_name,'Done',df_cnt,dateTimeObj)
                            ]

                    schema = StructType([ \
                             StructField("fileName",StringType(),True), \
                             StructField("Status",StringType(),True), \
                             StructField("Cnt",StringType(),True), \
                             StructField("current_time",TimestampType(),True), \
                                        ])
                    # we are creating dataframe and then we will append/insert log data into delta table log_file_bs
                    df = spark.createDataFrame(data=data2,schema=schema)
                    df.write.format("delta").mode("append").saveAsTable("log_file_bs")
#                 else:
#                     print("No such file available at given path")
            
        except Exception as e:
            print("Error in Processing files")
        
    
    
    

# COMMAND ----------

fileArchiveAndLogging("/mnt/containershareddna02", "/mnt/containershareddna02/Target_dir/", "Covid_Ohio_state_f")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from log_file_bs ;
# MAGIC --delete from log_file_bs;
# MAGIC --drop table log_file_bs;