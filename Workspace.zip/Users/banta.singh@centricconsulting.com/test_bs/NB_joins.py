# Databricks notebook source
# We can join 2 dataframes (or files) and can store data into new one.
# there are few type of join - inner, full, left, right

# COMMAND ----------

# df_01 is first dataframe which has state column common with another dataframe df_02's column States
df_01= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_join.csv",header = "true", inferSchema ="true")
df_01.show()
# df_01.count() # 368

# COMMAND ----------

df_02= spark.read.csv("/mnt/containershareddna02/lookupfile_States.csv",header = "true", inferSchema ="true")
df_02.show()
# df_02.count() # 51

# COMMAND ----------

df_01.join(df_02, df_01.state == df_02.States,'inner').show()
# df_01.join(df_02, df_01.state == df_02.States,'inner').count() #368

# COMMAND ----------

df_01.join(df_02,df_01.state == df_02.States,'left').show()
# df_01.join(df_02,df_01.state == df_02.States,'left').count() #368

# COMMAND ----------

df_01.join(df_02,df_01.state == df_02.States,'right').show()
# df_01.join(df_02,df_01.state == df_02.States,'right').count() #418

# COMMAND ----------

df_01.join(df_02,df_01.state == df_02.States,'right').filter(df_01.state == 'OH').show()

# COMMAND ----------

df_01.join(df_02,df_01.state == df_02.States,'full').show()
# df_01.join(df_02,df_01.state == df_02.States,'full').count() # 418