# Databricks notebook source
!pip install cryptography

# import required module
from cryptography.fernet import Fernet


# COMMAND ----------


# key generation
key = Fernet.generate_key()
  

# COMMAND ----------


# string the key in a file
with open('filekey.key', 'wb') as filekey:
   filekey.write(key)


# COMMAND ----------

import os
directory = os.getcwd()
print(directory)

# COMMAND ----------


os.path.realpath('filekey.key') 

spark.read.key('/databricks/driver/filekey.key')

# COMMAND ----------


# opening the key
with open('filekey.key', 'rb') as filekey:
    key = filekey.read()
 

# COMMAND ----------

 
# using the generated key
fernet = Fernet(key)
  
# opening the original file to encrypt
with open("/dbfs/mnt/containershareddna01/DATA_SOURCE.csv", 'rb') as file:
    original = file.read()
      
# encrypting the file
encrypted = fernet.encrypt(original)

# opening the file in write mode and 
# writing the encrypted data
with open("/dbfs/mnt/containershareddna01/DATA_SOURCE.csv", 'wb') as encrypted_file:
    encrypted_file.write(encrypted)

# COMMAND ----------

# using the key
fernet = Fernet(key)
  
# opening the encrypted file
with open("/dbfs/mnt/containershareddna01/DATA_SOURCE.csv", 'rb') as enc_file:
    encrypted = enc_file.read()
  
# decrypting the file
decrypted = fernet.decrypt(encrypted)
  
    

# COMMAND ----------

# opening the file in write mode and
# writing the decrypted data
with open("/dbfs/mnt/containershareddna01/DATA_SOURCE.csv", 'wb') as dec_file:
    dec_file.write(decrypted)

# COMMAND ----------

# Description : function[encryptfile] is responsible to encrypt data from a file present in blob storage.
# InPut Parameters : (filePath,keyFileName,encryptedFilePath)
#       filePath: Path for reading the file which needs to be encrypt. 
#       keyFileName: file name in which key will be stored.
#       encryptedFilePath: Path and file name in which encrypted data will be stored.

# function is developed to accept above mentioned 3 parameters for now.
#

# Description : function[decryptfile] is responsible to decrypt data from encrypted file present in blob storage.
# InPut Parameters : (filePath,keyFileName,decryptedFilePath)
#       filePath: Path for reading the file which needs to be decrypt. 
#       keyFileName: file name from which key will be fetched to decrypt data.
#       decryptedFilePath: Path and file name in which decrypted data will be stored.

# function is developed to accept above mentioned 3 parameters for now.
#

# COMMAND ----------

def encryptfile(filePath,keyFileName,encryptedFilePath) :
    
    try:
        !pip install cryptography
        
        # import required module
        from cryptography.fernet import Fernet
        # key generation
        key = Fernet.generate_key()
        
        # string the key in a file
        with open(keyFileName, 'wb') as filekey:
         filekey.write(key)
        
        # opening the key
        with open(keyFileName, 'rb') as filekey:
         key = filekey.read()
        
         
        # using the generated key
        fernet = Fernet(key)
  
        # opening the original file to encrypt
        with open(filePath, 'rb') as file:
         original = file.read()
      
        # encrypting the file
        encrypted = fernet.encrypt(original)

        # opening the file in write mode and 
        # writing the encrypted data
        with open(encryptedFilePath, 'wb') as encrypted_file:
         encrypted_file.write(encrypted)
        
    except Exception as e:
         print("Error while encrypting file")
        


# COMMAND ----------

def decryptfile(filePath,keyFileName,decryptedFilePath) :
    
    try:
        !pip install cryptography
        
        # import required module
        from cryptography.fernet import Fernet

        # opening the key
        with open(keyFileName, 'rb') as filekey:
         key = filekey.read()
  
        # using the generated key
        fernet = Fernet(key)
  
        # opening the encrypted file
        with open(filePath, 'rb') as enc_file:
         encrypted = enc_file.read()
  
        # decrypting the file
        decrypted = fernet.decrypt(encrypted)
        
        # opening the file in write mode and
        # writing the decrypted data
        with open(decryptedFilePath, 'wb') as dec_file:
         dec_file.write(decrypted)
        
    except Exception as e:
         print("Error while decrypt file")
        


# COMMAND ----------

encryptfile("/dbfs/mnt/containershareddna01/Covid_Ohio_state_2.csv",'keyfile.key',"/dbfs/mnt/containershareddna01/Covid_Ohio_state_2_encrypted.csv")

# COMMAND ----------

decryptfile("/dbfs/mnt/containershareddna01/Covid_Ohio_state_2_encrypted.csv",'keyfile.key',"/dbfs/mnt/containershareddna01/Covid_Ohio_state_2_decryptede.csv")

# COMMAND ----------

encryptfile("/dbfs/mnt/containershareddna01/Covid_Ohio_state_2.csv",'keyfile1.key',"/dbfs/mnt/containershareddna01/Covid_Ohio_state_2.csv")

# COMMAND ----------

decryptfile("/dbfs/mnt/containershareddna01/Covid_Ohio_state_2.csv",'keyfile.key',"/dbfs/mnt/containershareddna01/Covid_Ohio_state_2.csv")