# Databricks notebook source


# COMMAND ----------

def useConfigFile(configFilePath):
    import pyspark ;
    from pyspark.sql import SparkSession;
    import os;
    from datetime import date,datetime, timedelta;
    from configparser import ConfigParser;
    import re;
    # spark = SparkSession.builder.appName('TeamB').master('master').getOrCreate()
    ini_ConfigParser = ConfigParser()
    ini_ConfigParser.read(configFilePath)
    pass_hours =int(ini_ConfigParser.get('FILE_OSS','pass_hours'))
    path = ini_ConfigParser.get('FILE_OSS','path')
    
    print(pass_hours)
    print("path from FILE_OSS is - "+path)


# COMMAND ----------

# useConfigFile('/dbfs/FileStore/tables/oss/pyspark_config_teamc.ini')
useConfigFile(Var2)