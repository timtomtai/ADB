# Databricks notebook source


# COMMAND ----------

# MAGIC %run /Users/banta.singh@centricconsulting.com/test_bs/NB_test $Var2="'/dbfs/FileStore/tables/oss/pyspark_config_teamc.ini'"

# COMMAND ----------

