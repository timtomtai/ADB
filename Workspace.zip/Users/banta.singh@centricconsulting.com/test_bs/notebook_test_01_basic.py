# Databricks notebook source
examp = ["Alpha","Beta","Gamma"]
for x in examp:
 if x == "Beta":
  print (x)
 else:
  print ("not Beta");

