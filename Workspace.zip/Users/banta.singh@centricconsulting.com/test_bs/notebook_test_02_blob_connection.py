# Databricks notebook source
df_001= spark.read.csv("/mnt/containershareddna01/DATA_SOURC*.csv",header = "true").select("Name").filter("Name = 'Rohit'")
df_001.show()

# COMMAND ----------

df_001.write.format("delta").mode("overwrite").saveAsTable("test_delta_table_bs")



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from test_csv_table_bs ;

# COMMAND ----------

# MAGIC %sql
# MAGIC insert into test_delta_table_bs values('Banta', 'IN','M',100);
# MAGIC update test_delta_table_bs set Address = 'HR' where Name = 'Banta';
# MAGIC select * from test_delta_table_bs where Name = 'Banta';

# COMMAND ----------

dbfs= spark.read.csv("/FileStore/tables/Data_f*.csv",header = "true")

dbfs.show()


# COMMAND ----------

dbfs.write.format("csv").mode("overwrite").csv("/FileStore/tables/dbfs_06.csv",header="true")
dbfs.write.format("delta").mode("overwrite").csv("/mnt/containershareddna02/dbfs_005.csv",header="true")


# COMMAND ----------

dbfs_fetched_from_DBFS= spark.read.csv("/FileStore/tables/dbfs_02.csv/part*.csv",header = "true")
dbfs_fetched_from_DBFS.show()

# COMMAND ----------

df_fetching_from_blob= spark.read.csv("/mnt/containershareddna02/dbfs_001.csv/part*.csv",header = "true")
df_fetching_from_blob.show()

# COMMAND ----------

# will create surrogate Key on this dataframe
df_fetching_from_blob.show()



# COMMAND ----------

# Need to create this function for creation of Surrogate Key in existing dataframe

from pyspark.sql.types import LongType, StructField, StructType
def dfZipWithIndex (df, offset = 1, colName = "rowId" ):
    # df - source dataframe
    # offset - Adjust to ZipWithIndex's Index
    # colName - name of the index column
    
    new_schema = StructType(
        [StructField(colName, LongType(),True)]  #new added field
        + df.schema.fields)                      #table fields
    
    zipped_rdd = df.rdd.zipWithIndex()
    
    new_rdd = zipped_rdd.map(lambda row: ([row[1]+offset] + list(row[0])))
    
    return spark.createDataFrame(new_rdd, new_schema)

# COMMAND ----------

# MAGIC %sql
# MAGIC delete from new_table_with_surrKey_delta;
# MAGIC select * from new_table_with_surrKey_delta;
# MAGIC 
# MAGIC --create table new_table_with_surrKey_delta (Surrogate_key BIGINT, Cust_id int, Policy_number int, chain_id int, status varchar(20))
# MAGIC --using delta
# MAGIC --Location '/FileStore/tables/delta_tab/';

# COMMAND ----------

df_with_surrKey = dfZipWithIndex(df_fetching_from_blob, offset = 1, colName = "Surrogate_key" )
df_with_surrKey.createOrReplaceTempView("DataFrame_View")
spark.sql("""insert into new_table_with_surrKey_delta select * from  DataFrame_View""")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from new_table_with_surrKey_delta;

# COMMAND ----------

# Second run
N = spark.sql("select max(Surrogate_key) from new_table_with_surrKey_delta").collect()[0][0]
spark.conf.set("test.max_sk",N) #set context variable for use in next insert batch
print(spark.conf.get("test.max_sk"))

df_with_surrKey = dfZipWithIndex(df_fetching_from_blob, offset = N+1, colName = "Surrogate_key" )
df_with_surrKey.createOrReplaceTempView("DataFrame_View")
spark.sql("""insert into new_table_with_surrKey_delta select * from  DataFrame_View""")

# creating dataframe from table
df_final_surrKey = spark.sql("select * from new_table_with_surrKey_delta")
df_final_surrKey.show()


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from new_table_with_surrKey_delta;

# COMMAND ----------

df.show()

# COMMAND ----------

df.createOrReplaceTempView("View_using_sql")
df_SurrKey = sqlContext.sql("select row_number() over(order by Name) as Surrogate_key, Name, Address, MS, Salary from View_using_sql")
df_SurrKey.show()

# COMMAND ----------

df_SurrKey.write.format("delta").mode("overwrite").csv("/FileStore/tables/bs_surrogateKey.csv",header="true")
df_SurrKey.write.format("delta").mode("overwrite").csv("/mnt/containershareddna02/bs_surrogateKey.csv",header="true")

df_final_surrKey.write.format("delta").mode("overwrite").csv("/FileStore/tables/bs_surrogateKey_2.csv",header="true")
df_final_surrKey.write.format("delta").mode("overwrite").csv("/mnt/containershareddna02/bs_surrogateKey_2.csv",header="true")

# COMMAND ----------

df_fetching_from_blob_surrKey= spark.read.csv("/mnt/containershareddna01/bs_surrogateKey.csv/part*.csv",header = "true")
df_fetching_from_blob_surrKey.show()


# COMMAND ----------

df_fetching_from_blob_SurrKey_2= spark.read.csv("/mnt/containershareddna01/bs_surrogateKey_2.csv/part*.csv",header = "true")
df_fetching_from_blob_SurrKey_2.show(50)

# COMMAND ----------

dbfs_fetched_from_DBFS_SurrKey= spark.read.csv("/FileStore/tables/bs_surrogateKey.csv/part*.csv",header = "true")
dbfs_fetched_from_DBFS_SurrKey.show()

# COMMAND ----------

dbfs_fetched_from_DBFS_SurrKey_2 = spark.read.csv("/FileStore/tables/bs_surrogateKey_2.csv/part*.csv",header = "true")
dbfs_fetched_from_DBFS_SurrKey_2.show(50)