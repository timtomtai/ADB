# Databricks notebook source
jdbcHostname = "dbserverdna01.database.windows.net"
jdbcDatabase = "dbdna01"
jdbcPort = 1433
username = 'admindna01'
password = 'admindna@01'
connectionProperties = {
  "user" : username,
  "password" : password,
  "driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"
  }
jdbcUrl = "jdbc:sqlserver://{0}:{1};database={2};user={3};password={4}".format(jdbcHostname, jdbcPort, jdbcDatabase, username, password)
Url = "jdbc:sqlserver://{0}:{1};database={2}".format(jdbcHostname, jdbcPort, jdbcDatabase)

# COMMAND ----------

df_from_container= spark.read.csv("/mnt/containershareddna01/DATA*.csv",header = "true")
df_from_container.show()


# COMMAND ----------

from pyspark.sql import *
import pandas as pd
df_table_creation_from_file = DataFrameWriter(df_from_container)
df_table_creation_from_file.jdbc(url=Url, table= "test_bs_1", mode ="overwrite", properties = connectionProperties)


# COMMAND ----------

df_from_table = spark.read.jdbc(url=Url, table="(select Name, Salary from test_bs_1 where Name = 'Rohit') test_data", properties=connectionProperties)
display(df_from_table)

# COMMAND ----------

pushdown_query = "(select * from test_bs_1) test_data"
df_from_table = spark.read.jdbc(url=Url, table=pushdown_query, properties=connectionProperties)
display(df_from_table)

# COMMAND ----------

# MAGIC %sql
# MAGIC --Creating table/file in databricks - data > default > 
# MAGIC 
# MAGIC --create table test_bs_2 (id int, name varchar(100), status char(1));
# MAGIC 
# MAGIC 
# MAGIC insert into test_bs_2 values(1,'Banta','1');
# MAGIC insert into test_bs_2 values(2,'Mohit','1');
# MAGIC insert into test_bs_2 values(3,'Rishi','0');
# MAGIC insert into test_bs_2 values(4,'Rajan','1');
# MAGIC 
# MAGIC select * from test_bs_2 where id between 1 and 4;