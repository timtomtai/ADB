# Databricks notebook source
# MAGIC %run /Users/banta.singh@centricconsulting.com/test_bs/notebook_test_01_basic

# COMMAND ----------

# MAGIC %run /Users/banta.singh@centricconsulting.com/test_bs/notebook_test_02_blob_connection