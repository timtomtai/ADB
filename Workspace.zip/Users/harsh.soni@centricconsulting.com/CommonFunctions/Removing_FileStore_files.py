# Databricks notebook source
#dbutils.fs.rm("/FileStore/tables/DataEng/RawtoStg/customerRawtoStg.py")
#dbutils.fs.rm("/FileStore/tables/DataEng/RawtoStg/transactionRawtoStg.py")
#dbutils.fs.rm("/FileStore/tables/DataEng/RawtoStg/controllerRawToStg.py")
#dbutils.fs.rm("/FileStore/tables/DataEng/RawtoStg/config/logging_init_file.py")
#dbutils.fs.rm("/FileStore/tables/DataEng/RawtoStg/config/rawToStgAbstract.py")
#dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/config/data_quality_config_txt.txt","/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt")
#dbutils.fs.rm("/FileStore/tables/DataEng/RawtoStg/claimtransRawToStg.py")

# COMMAND ----------

dbutils.fs.mv("/FileStore/tables/DataEng/StgtoInt/claimClaimant-1.py","/FileStore/tables/DataEng/StgtoInt/claimClaimant.py")

# COMMAND ----------

a = spark.read.format("delta").load("/mnt/containershareddna03/Int/edw_claimant")

# COMMAND ----------

display(a)

# COMMAND ----------

print("Hi")

# COMMAND ----------

#a = spark.read.parquet("/mnt/containershareddna03/Stg/claim_transaction/claim_transaction/")

# COMMAND ----------

#display(a)

# COMMAND ----------

