# Databricks notebook source
from delta import DeltaTable
import delta
from pyspark.sql import functions as f
from pyspark.sql.utils import AnalysisException

class createUpsert:
    STATUS = "status"
    START_DATE = "start_date" 
    END_DATE = "end_date"

    def __init__(self, spark, deltalake_path, todays_data_df, primary_key_list, process_date):
        self.spark = spark
        self.deltalake_path = deltalake_path
        self.todays_data_df = todays_data_df
        self.primary_key_list = primary_key_list
        self.process_date = process_date

        # To enable the schema drift in delta table
        self.spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")

    def read_delta_table(self,spark,deltalake_path):
        delta_table = DeltaTable.forPath(spark, deltalake_path)
        return delta_table

    def get_delta_table_active_rows(self,delta_table):
        delta_table_df = delta_table.toDF().filter(f.col(self.STATUS) == 'Y') \
            .drop(self.STATUS,self.END_DATE,self.START_DATE)
        return delta_table_df

    def synch_columns_in_two_dataframe(self,df1,df2):
        schema1 = set(df1.schema)
        schema2 = set(df2.schema)

        # Adding missing column in DF1
        for i in schema2.difference(schema1):
            df1 = df1.withColumn(i.name,f.lit(None).cast(i.dataType))

        # Adding missing clumn in DF2
        for i in schema1.difference(schema2):
            df2 = df2.withColumn(i.name,f.lit(None).cast(i.dataType))

        df2 = df2.select(df1.columns)

        return df1, df2

    def get_rows_to_be_made_inactive(self, delta_table_df, todays_df, process_date):

        rows_to_be_made_inactive_df = delta_table_df.subtract(todays_df)
        rows_to_be_made_inactive_df = rows_to_be_made_inactive_df \
            .withColumn(self.START_DATE,f.lit(None)) \
            .withColumn(self.END_DATE,f.to_timestamp(f.lit(process_date),"yyyy-MM-dd")) \
            .withColumn(self.STATUS,f.lit('N'))

        return rows_to_be_made_inactive_df

    def get_rows_to_be_made_active(self, delta_table_df, todays_df, process_date):
        rows_to_be_made_active_df = todays_df.subtract(delta_table_df)
        rows_to_be_made_active_df = rows_to_be_made_active_df \
            .withColumn(self.START_DATE,f.to_timestamp(f.lit(process_date),"yyyy-MM-dd")) \
            .withColumn(self.END_DATE,f.lit(None)) \
            .withColumn(self.STATUS,f.lit('Y'))
        
        return rows_to_be_made_active_df

    def build_condition_string(self, primary_key_list):
        condition_list = [f'target.{_} = updates.{_}' for _ in primary_key_list]
        condition_list.append(f'target.{self.STATUS} = "Y"')
        condition_list.append(f'updates.{self.STATUS} ="N"')
        print(' and '.join(condition_list))
        return ' and '.join(condition_list)

    def update_delta_table_with_changes(self, delta_table, updates_df, primary_key_list):
        condition = self.build_condition_string(primary_key_list)
        delta_table.alias('target').merge(source=updates_df.alias('updates'), condition=condition) \
            .whenMatchedUpdate(set={self.STATUS:f'updates.{self.STATUS}',
                                    self.END_DATE: f'updates.{self.END_DATE}'}) \
            .whenNotMatchedInsertAll().execute()

    def write_dataframe_as_delta_table(self, df, deltalake_path, process_date):
        todays_data_df = df.withColumn(self.START_DATE,f.to_timestamp(f.lit(process_date),'yyyy-MM-dd')) \
            .withColumn(self.END_DATE, f.lit(None).cast('Timestamp')) \
            .withColumn(self.STATUS,f.lit('Y')) 
        todays_data_df.write.format('delta').save(deltalake_path)

    def execute(self):
        try:
            delta_table = self.read_delta_table(self.spark, self.deltalake_path)
        except AnalysisException:
            self.write_dataframe_as_delta_table(self.todays_data_df,self.deltalake_path,self.process_date)
        else:
            # No exception
            delta_table_df = self.get_delta_table_active_rows(delta_table)
            
            delta_table_df, self.todays_data_df = self.synch_columns_in_two_dataframe(delta_table_df, self.todays_data_df)

            to_be_made_inactive_df = self.get_rows_to_be_made_inactive(delta_table_df,self.todays_data_df,self.process_date)

            to_be_made_active_df = self.get_rows_to_be_made_active(delta_table_df, self.todays_data_df,self.process_date)

            updates_df = to_be_made_inactive_df.union(to_be_made_active_df)

            self.update_delta_table_with_changes(delta_table,updates_df,self.primary_key_list)

# COMMAND ----------

delta_lake_path = "/mnt/containershareddna03/dldemo/tables/table1"
current_df = spark.read.option("Header",True).csv("/mnt/containershareddna03/dldemo/input/emp1.csv")
primary_key_list = ["id"]
process_date = "2022-03-14"
A = createUpsert(spark,delta_lake_path,current_df,primary_key_list,process_date)
A.execute()

# COMMAND ----------

delta_lake_path = "/mnt/containershareddna03/dldemo/tables/table1"
current_df = spark.read.option("Header",True).csv("/mnt/containershareddna03/dldemo/input/emp2.csv")
primary_key_list = ["id"]
process_date = "2022-03-15"
A = createUpsert(spark,delta_lake_path,current_df,primary_key_list,process_date)
A.execute()

# COMMAND ----------

display(DeltaTable.forPath(spark, "/mnt/containershareddna03/dldemo/tables/table1").toDF())

# COMMAND ----------

display(DeltaTable.forPath(spark, "/mnt/containershareddna03/dldemo/tables/table1").toDF())

# COMMAND ----------

current_df = spark.read.option("Header",True).csv("/mnt/containershareddna03/dldemo/input/emp2.csv")
previous_df = spark.read.option("Header",True).csv("/mnt/containershareddna03/dldemo/input/emp1.csv")

# COMMAND ----------

display(previous_df.join(current_df))

# COMMAND ----------

display(previous_df.join(current_df,previous_df.id==current_df.id,"leftouter"))

# COMMAND ----------

