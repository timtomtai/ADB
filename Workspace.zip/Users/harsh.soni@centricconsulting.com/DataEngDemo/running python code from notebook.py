# Databricks notebook source
a = spark.read.option("Header",True).csv("/mnt/containershareddna02/DataEngineeringLayer/customer.csv")

# COMMAND ----------

display(a)

# COMMAND ----------

