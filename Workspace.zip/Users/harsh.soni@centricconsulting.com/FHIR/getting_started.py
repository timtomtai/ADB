# Databricks notebook source
from pyspark.sql import SparkSession

# Enable Hive support for our session so we can save resources as Hive tables
spark = SparkSession.builder \
                    .config('hive.exec.dynamic.partition.mode', 'nonstrict') \
                    .enableHiveSupport() \
                    .getOrCreate()

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

from bunsen.r4.bundles import load_from_directory, extract_entry, write_to_database

# Load and cache the bundles so we don't reload them every time.
bundles1 = load_from_directory(spark, '/mnt/containershareddna01/Bundles').cache()

# Get the observation and encounters
observations = extract_entry(spark, bundles1, 'observation')
encounters = extract_entry(spark, bundles1, 'encounter')

# COMMAND ----------

