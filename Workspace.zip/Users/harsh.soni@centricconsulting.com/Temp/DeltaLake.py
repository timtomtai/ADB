# Databricks notebook source
from delta.tables import *

class Create_Delta:
    def __init__(delta_path,current_path,primary_key_list,column_list):
        self.delta_path = delta_path
        self.current_path = current_path
        self.primary_key_list = primary_key_list
        self.column_list = column_list
        self.current_df_alias = "current"
        self.previous_df_alias = "previous"
        self.primary_key_cond = ""
        self.column_cond =""
    def
    def read_delta_table(self):
        for i in self.primary_key_list:
            self.primary_key_cond += "\'" +current_df_alias+ "."+ i +"="+ previous_df_alias + "." +id
    def read_current_df(self):
        print("method2")

# COMMAND ----------

cd = Create_Delta("a","B",["A","B","C"],["D","E"])
cd.read_delta_table()

# COMMAND ----------

