# Databricks notebook source
source_format = "csv" # This can be "csv", "json", "parquet" depending upon the source file
source_delimiter = "," # This can be "," or anyother delimiter or None
source_header = True # This can be True or False or None
            

a = spark.read.load("/mnt/containershareddna03/Raw/claim_control_activity/claim_control_activity.csv", format=source_format, delimiter=source_delimiter, header=source_header)

# COMMAND ----------

spark.sql("set spark.sql.legacy.timeParserPolicy=CORRECTED")
from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import to_date,col
from pyspark.sql.types import TimestampType,IntegerType,BinaryType, DoubleType, StringType

a = a.withColumn('claimcontrol_id',col('claimcontrol_id').cast(IntegerType()))
a = a.withColumn('num',col('num').cast(IntegerType()))
a = a.withColumn('claimactivitycode_id',col('claimactivitycode_id').cast(IntegerType()))
a = a.withColumn('added',to_timestamp(col('added'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
a = a.withColumn('users_id',col('users_id').cast(IntegerType()))
a = a.withColumn('added_date',to_date(col('added_date'), 'yyyy-MM-dd').cast(TimestampType()))
a = a.withColumn('pcadded_date',to_timestamp(col('pcadded_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
a = a.withColumn('last_modified_date',to_timestamp(col('last_modified_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
a = a.withColumn('claimpersonneltype_id',col('claimpersonneltype_id').cast(IntegerType()))
a = a.withColumn('transfer_from_users_id',col('transfer_from_users_id').cast(IntegerType()))
a = a.withColumn('transfer_to_users_id',col('transfer_to_users_id').cast(IntegerType()))
a = a.withColumn('version_begin_timestamp',to_timestamp(col('version_begin_timestamp'), 'yyyy-MM-dd HH:mm:ss.SSSSSSS').cast(TimestampType()))
a = a.withColumn('version_end_timestamp',to_timestamp(col('version_end_timestamp'), 'yyyy-MM-dd HH:mm:ss.SSSSSSS').cast(TimestampType()))


# COMMAND ----------

a.write.mode("Overwrite").parquet("/mnt/containershareddna03/Stg/claim_control_activity/claim_control_activity")

# COMMAND ----------

source_format = "csv" # This can be "csv", "json", "parquet" depending upon the source file
source_delimiter = "," # This can be "," or anyother delimiter or None
source_header = True # This can be True or False or None
            

a = spark.read.load("/mnt/containershareddna03/Raw/claim_transaction/claim_transaction.csv", format=source_format, delimiter=source_delimiter, header=source_header)

# COMMAND ----------

display(a)

# COMMAND ----------

spark.sql("set spark.sql.legacy.timeParserPolicy=CORRECTED")
from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import to_date,col
from pyspark.sql.types import TimestampType,IntegerType,BinaryType, DoubleType
a = a.withColumn('PAYMENT_AMOUNT',col('PAYMENT_AMOUNT').cast(DoubleType()))
a = a.withColumn('RESERVE_AMOUNT',col('RESERVE_AMOUNT').cast(DoubleType()))
a = a.withColumn('TRANSACTION_STATUS_DATETIME',to_timestamp(col('TRANSACTION_STATUS_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))

# COMMAND ----------

a = a.withColumn('TRANSACTION_DATE_KEY',col('TRANSACTION_DATE_KEY').cast(IntegerType()))
a = a.withColumn('TRANSACTION_DATETIME',to_timestamp(col('TRANSACTION_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
a = a.withColumn('ACCOUNTING_DATE',to_timestamp(col('ACCOUNTING_DATE'), 'yyyy-MM-dd').cast(TimestampType()))
a = a.withColumn('BUSINESS_EFFECTIVE_TRANSACTION_DATETIME',to_timestamp(col('BUSINESS_EFFECTIVE_TRANSACTION_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
a = a.withColumn('RECORD_VALID_BEGIN_DATETIME',to_timestamp(col('RECORD_VALID_BEGIN_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
a = a.withColumn('RECORD_VALID_END_DATETIME',to_timestamp(col('RECORD_VALID_END_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
a = a.withColumn('ENTERED_DATETIME',to_timestamp(col('ENTERED_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
a = a.withColumn('UPDATED_DATETIME',to_timestamp(col('UPDATED_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
a = a.withColumn('PROCESS_BATCH_ID',col('PROCESS_BATCH_ID').cast(IntegerType()))
a = a.withColumn('INTRA_BATCH_LOOP_SEQUENCE',col('INTRA_BATCH_LOOP_SEQUENCE').cast(IntegerType()))
a = a.withColumn('CHANGE_HASH',col('CHANGE_HASH').cast(BinaryType()))

# COMMAND ----------

display(a)

# COMMAND ----------

a.write.mode("Overwrite").parquet("/mnt/containershareddna03/Stg/claim_transaction/claim_transaction")

# COMMAND ----------

a.select('INTRA_BATCH_LOOP_SEQUENCE').distinct().collect()


# COMMAND ----------

from pyspark.sql.functions import col
from pyspark.sql.types import StringType, IntegerType


a.select('PROCESS_BATCH_ID').withColumn("AA",col("PROCESS_BATCH_ID").cast(IntegerType()))



# COMMAND ----------

a.select('INVALIDATED_BATCH_LOOP_SEQUENCE').distinct().collect()


# COMMAND ----------

a.select('RECORD_VALID_END_DATETIME').distinct().collect()


# COMMAND ----------

a.select('Accounting_DATE').distinct().collect()

# COMMAND ----------

a = spark.read.option("Header",True).csv("/mnt/containershareddna03/dldemo/input/emp1.csv")

# COMMAND ----------

b = spark.read.option("Header",True).csv("/mnt/containershareddna03/dldemo/input/emp2.csv")

# COMMAND ----------

display(a.join(b,a.id==b.id,"inner").select(a.id,a.name))

# COMMAND ----------

claiment = spark.read.parquet("/mnt/containershareddna03/Stg/claimant/claimant")
Sex  = spark.read.parquet("/mnt/containershareddna03/Stg/sex/sex")
ClaimControl  = spark.read.parquet("/mnt/containershareddna03/Stg/claim_control/claim_control")
ClaimantType  = spark.read.parquet("/mnt/containershareddna03/Stg/claimant_type/claimant_type")
ClaimantNameLink  = spark.read.parquet("/mnt/containershareddna03/Stg/claimant_namelink/claimant_namelink/")
Name  = spark.read.parquet("/mnt/containershareddna03/Stg/name/name")
ClaimantAddressLink  = spark.read.parquet("/mnt/containershareddna03/Stg/claimant_addresslink/claimant_addresslink")
Address  = spark.read.parquet("/mnt/containershareddna03/Stg/address/address")

# COMMAND ----------

claiment.registerTempTable("CLMNT")
Sex.registerTempTable("SX")
ClaimControl.registerTempTable("CC")
ClaimantType.registerTempTable("CT")
ClaimantNameLink.registerTempTable("CLMNTNL")
Name.registerTempTable("CLMNTN")
ClaimantAddressLink.registerTempTable("CLMNTAL")
Address.registerTempTable("Addr")
a = spark.sql("SELECT  concat(CAST(CLMNT.claimcontrol_id AS VARCHAR(50)), '#', CAST(CLMNT.claimant_num AS VARCHAR(50)) , '#DIA') AS claimant_NK , concat (CAST(CC.claimcontrol_id as varchar(50)), '#DIA') as CLAIM_FNK, CT.code CLAIMANT_TYPE_CODE, UPPER(RTrim(CLMNTN.first_name)) AS CLAIMANT_FIRST_NAME, UPPER(RTrim(CLMNTN.middle_name)) AS CLAIMANT_MIDDLE_NAME ,UPPER(RTrim(CLMNTN.last_name)) AS CLAIMANT_LAST_NAME  ,UPPER(RTrim(CLMNTN.display_name)) AS CLAIMANT_FULL_NAME ,Concat(Addr.house_num , ' ' , Addr.street_name) AS CLAIMANT_ADDRESS_1_ADDRESS ,Addr.apt_num AS CLAIMANT_ADDRESS_2_ADDRESS,Addr.city AS CLAIMANT_CITY_ADDRESS ,Addr.state_code as CLAIMANT_STATE_ADDRESS ,Addr.zip as CLAIMANT_ZIP_ADDRESS ,CLMNT.claimant_num as CLAIMANT_NUMBER_NAME , SX.code as CLAIMANT_GENDER_CODE ,NULL as CLAIMANT_AGE_INT, CASE WHEN CLMNTN.birth_date = '1800-01-01'THEN NULL ELSE CLMNTN.birth_date  END AS CLAIMANT_DATE_OF_BIRTH_DATE ,NULL CLAIMANT_DATE_OF_DEATH_DATE,CASE WHEN CLMNT.date_hired = '1800-01-01'THEN NULL ELSE CLMNT.date_hired  END CLAIMANT_HIRE_DATE ,CLMNT.occupation AS CLAIMANT_OCCUPATION_DESC ,NULL as CLAIMANT_EMAIL_NAME ,'DIA' as SOURCE_SYSTEM_CODE,'BTCH101' as PROCESS_BATCH_ID FROM CLMNT INNER JOIN CC ON CC.claimcontrol_id = CLMNT.claimcontrol_id LEFT JOIN CT ON CLMNT.claimanttype_id = CT.claimanttype_id LEFT OUTER JOIN CLMNTNL ON CLMNT.claimant_num = CLMNTNL.claimant_num AND CLMNT.claimcontrol_id = CLMNTNL.claimcontrol_id AND 21 = CLMNTNL.nameaddresssource_id LEFT OUTER JOIN CLMNTN ON CLMNTNL.name_id = CLMNTN.name_id AND CLMNTNL.nameaddresssource_id = CLMNTN.nameaddresssource_id LEFT OUTER JOIN CLMNTAL INNER JOIN Addr ON CLMNTAL.address_id = Addr.address_id AND CLMNT.claimant_num = CLMNTAL.claimant_num AND CLMNT.claimcontrol_id = CLMNTAL.claimcontrol_id AND 21 = CLMNTAL.nameaddresssource_id  LEFT JOIN SX on CLMNTN.sex_id = SX.sex_id" )


#ClaimantType  = spark.read.parquet("/mnt/containershareddna03/Stg/claimant_type/claimant_type")
#ClaimantNameLink  = spark.read.parquet("/mnt/containershareddna03/Stg/claimant/claimant")
#Name  = spark.read.parquet("/mnt/containershareddna03/Stg/name/name")
#ClaimantAddressLink  = spark.read.parquet("/mnt/containershareddna03/Stg/claimant_addresslink/claimant_addresslink")
#Address  = spark.read.parquet("/mnt/containershareddna03/Stg/address/address")


# COMMAND ----------

display(a)

# COMMAND ----------

display(a)

# COMMAND ----------

joinDf = claiment.join(ClaimControl,ClaimControl.claimcontrol_id==claiment.claimcontrol_id,"inner")
joinDf = joinDf.join()

# COMMAND ----------

display(joinDf)

# COMMAND ----------

