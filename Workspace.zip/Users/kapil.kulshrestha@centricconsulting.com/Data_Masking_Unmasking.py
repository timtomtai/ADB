# Databricks notebook source
#Data masking unmasking notebook

# COMMAND ----------

df= spark.read.csv("/FileStore/tables/Files/Test/Employees.csv",header = "true", inferSchema ="true")
df.show()

# COMMAND ----------

df_dict= spark.read.csv("/FileStore/tables/TABTEST/Files/Employee_mask_dict.csv",header = "true", inferSchema ="true")
df_dict.show()

# COMMAND ----------

#masking of data

from pyspark.sql.functions import lit

df.withColumn("FIRST_NAME", lit("*** Masked ***")).withColumn("EMAIL", lit("*** Masked ***")).show()

# COMMAND ----------

df.join(df_dict, df.EMAIL == df_dict.EMAIL,'left').select("MASK_EMAIL").show()

# COMMAND ----------

#masking of Email,firstname,lastname with other value

masked_value= df.join(df_dict, df.FIRST_NAME == df_dict.FIRST_NAME,'left').drop("EMAIL","FIRST_NAME","LAST_NAME").withColumnRenamed("MASK_EMAIL", "EMAIL").withColumnRenamed("MASK_FIRSTNAME", "FIRST_NAME").withColumnRenamed("MASK_LAST_NAME", "LAST_NAME")
masked_value.show()

# COMMAND ----------

#Unmasking of columns with actual value
df_unmask=masked_value.withColumnRenamed("EMAIL", "MASK_EMAIL").withColumnRenamed("FIRST_NAME", "MASK_FIRSTNAME").withColumnRenamed("LAST_NAME", "MASK_LAST_NAME")
df_unmask.join(df_dict, df_unmask.MASK_FIRSTNAME == df_dict.MASK_FIRSTNAME,'left').drop("MASK_FIRSTNAME","MASK_LAST_NAME","MASK_EMAIL").show()

# COMMAND ----------

#masking using regex

from pyspark.sql.types import *
import pyspark.sql.functions as F

# This is assuming your card number is not a string. If not skip this cast
df_cast = df.withColumn("number_string",F.col('PHONE_NUMBER').cast(StringType()))
df_mask = df_cast.withColumn("PHONE_NUMBER",F.concat(F.lit('******'),F.substring(F.col("number_string"),6,4)))

df_mask.show()

# COMMAND ----------

#email masking

from pyspark.sql.functions import regexp_extract, regexp_replace,concat, expr, lit

df_email_mask = df.withColumn(
    "pattern", 
    regexp_extract("email", r"(?<=.{2})\w+(?=@)", 0)
)
df_email_mask = df_email_mask.withColumn(
    "replacement",
    regexp_replace("pattern", r"\w", "*")
)
df_email_mask = df_email_mask.withColumn(
    "EMAIL",
    expr("regexp_replace(email, concat('(?<=.{2})', pattern, '(?=@)'), replacement)")
)
df_email_mask.drop("pattern","replacement").show()

# COMMAND ----------

d = dict()
f = open("/dbfs/FileStore/tables/Files/Test/Employee_Test.csv") 
next(f)
for line in f:
    line = line.strip('\n')
    (key,val) = line.split(",")
    d[key] = val

print(d)


# COMMAND ----------

import random
# printing original dictionary
print("The original dictionary is : " + str(d))
  
# shuffling values
temp = list(d.values())
random.shuffle(temp)  
# reassigning to keys
res = dict(zip(d, temp))  
# printing result
print("The shuffled dictionary : " + str(res))

# COMMAND ----------

lol= list(map(list, res.items()))
df = spark.createDataFrame(lol, ["col1", "col2"])
df.show()

# COMMAND ----------

df= spark.read.csv("/FileStore/tables/Files/Test/Employees.csv",header = "true", inferSchema ="true")
df.show()

# COMMAND ----------

dictd = {}
  
# Convert PySpark DataFrame to Pandas 
# DataFrame
df= spark.read.csv("/FileStore/tables/Files/Test/Employees.csv",header = "true", inferSchema ="true")
df1 = df.select("EMPLOYEE_ID","FIRST_NAME")
df1 = df1.toPandas()
  
# Traverse through each column
for column in df1.columns:
  
    # Add key as column_name and
    # value as list of column values
    dictd[column] = df1[column].values.tolist()
  
# Print the dictionary
print(dictd)

# COMMAND ----------

import random
# printing original dictionary
print("The original dictionary is : " + str(dictd))
  
# shuffling values
temp = list(dictd.values())
random.shuffle(temp)  
# reassigning to keys
res = dict(zip(dictd, temp))  
# printing result
print("The shuffled dictionary : " + str(res))

# COMMAND ----------

from pyspark.sql.functions import col
df= spark.read.csv("/FileStore/tables/Files/Test/Employees.csv",header = "true", inferSchema ="true")
df1 = df.select(col("EMPLOYEE_ID").alias("EID"), col("FIRST_NAME").alias("FNAME"))
df1 = df1.toPandas()
df2 = df1.apply(lambda x: x.sample(frac=1).values)
mask_df = spark.createDataFrame(df2)
mask_df = df.join(mask_df, df.EMPLOYEE_ID == mask_df.EID,'left').select("EMPLOYEE_ID","FNAME","FIRST_NAME")
mask_df.show()

# COMMAND ----------

masked_value= df.join(mask_df, df.EMPLOYEE_ID == mask_df.EMPLOYEE_ID,'left').drop("FIRST_NAME","EID").withColumnRenamed("FNAME", "FIRST_NAME")
masked_value.show()

# COMMAND ----------

df_data= spark.read.csv("/FileStore/tables/Files/Test/Employees.csv",header = "true", inferSchema ="true")
df_data1 = df_data.select("EMPLOYEE_ID","FIRST_NAME")
df_data1 = df_data1.toPandas()
sparkDF = df_data1.sample(frac=1).values
#df2 = df1.apply(lambda x: x.sample(frac=1).values)
#sparkDF = spark.createDataFrame(df2)
print(sparkDF)
