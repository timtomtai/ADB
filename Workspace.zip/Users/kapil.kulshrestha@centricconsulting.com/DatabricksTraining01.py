# Databricks notebook source
df= spark.read.csv("/mnt/containershareddna01/DATA*.csv", header="true")



df.show()