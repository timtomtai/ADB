# Databricks notebook source
#### Remove duplicates using distinct function####

df= spark.read.csv("/FileStore/tables/TABTEST/Files/covid_variant_file_dup.csv",header = "true", inferSchema ="true")
df_unique = df.distinct()
df_unique.count()

# COMMAND ----------

####Remove complete duplicate using dropDuplicate function####

df_using_dropdupfunc = df.dropDuplicates()
df_using_dropdupfunc.count()

# COMMAND ----------

####Remove duplicates based on selected columns using dropDuplicate function#### 
df_using_dropdupfuncandcolumn = df.dropDuplicates(["location","date","variant"])
df_using_dropdupfuncandcolumn.count()

# COMMAND ----------

#### Remove duplicate using row_number window function ####

from pyspark.sql.functions import row_number  
from pyspark.sql.window import Window
df= spark.read.csv("/FileStore/tables/TABTEST/Files/covid_variant_file_dup.csv",header = "true", inferSchema ="true")
df_unique_with_rownumber = df.withColumn("row_number",row_number().over(Window.partitionBy('location','date','variant').orderBy("date")))
df_unique_with_rownumber.filter(df_unique_with_rownumber.row_number == 1).count()

# COMMAND ----------

####Remove duplicate using group by and count ####

df= spark.read.csv("/FileStore/tables/TABTEST/Files/covid_variant_file_dup.csv",header = "true", inferSchema ="true")
df_uniquevalue= df.groupBy("location","date","variant","num_sequences","perc_sequences","num_sequences_total").count()
df_uniquevalue.count()
