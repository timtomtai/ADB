# Databricks notebook source
#Transpose data using pivot and pandas transpose function

# COMMAND ----------

# reading csv file
df= spark.read.csv("/FileStore/tables/TABTEST/Files/transpose_file1.csv",header = "true", inferSchema ="true")
df.show()

# COMMAND ----------

#transpose using pivot function
df_transpose = df.groupBy(["location","date"]).pivot("variant").max("no_of_cases")
df_transpose.show()

# COMMAND ----------


# transpose using pandas transpose function
import pandas as pd

df= pd.read_csv("/dbfs/FileStore/tables/TABTEST/Files/transpose_file1.csv") #read csv file in panda 
df.set_index('location',inplace=True) #used for removing indexes
df_tx=df.transpose() # for transposing of data 
print(df_tx)
