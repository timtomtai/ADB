# Databricks notebook source
df= spark.read.format('csv').option("header","true").load('/mnt/containershareddna01/DemoSourceData/claimanttype1.txt',delimiter=',', quotechar='"')
df.show()

# COMMAND ----------

df = (spark.read
      .option("multiline", "true")
      .option("quote", '"')
      .option("header", "true")
      .option("escape", "\\")
      .option("escape", '"')
      .csv("/mnt/containershareddna01/DemoSourceData/claim_activity_code.txt")
)
df.show()

# COMMAND ----------

import pandas as pd
df = pd.read_csv('/dbfs/mnt/containershareddna01/DemoSourceData/claimant_type.csv')
df.to_parquet('/dbfs/mnt/containershareddna01/DemoSourceData/claimant_type.parquet')
#write_parquet_file()

# COMMAND ----------

import pandas as pd
pd.read_parquet('/dbfs/mnt/containershareddna01/DemoSourceData/claimant_type.parquet', engine='pyarrow')

# COMMAND ----------

df= spark.read.csv("/FileStore/tables/Files/Test/Employees.csv",header = "true", inferSchema ="true")
df.show()