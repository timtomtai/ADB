# Databricks notebook source
jdbcHostname = "dbserverdna01.database.windows.net"
jdbcPort = "1433"
jdbcDatabase = "dbdna01"
properties = {
 "user" : "admindna01",
 "password" : "admindna@01" }

# COMMAND ----------

#url = "jdbc:sqlserver://{0}:{1};database={2}".format(jdbcHostname,jdbcPort,jdbcDatabase)
mydf = sqlContext.read.csv("/FileStore/tables/DATA_SOURCE-1.csv",header=True)

# COMMAND ----------

from pyspark.sql import *
import pandas as pd
myfinaldf = DataFrameWriter(mydf)
myfinaldf.jdbc(url=url, table= "Test_Table_SQL_MR", mode ="overwrite", properties = properties)


# COMMAND ----------

pushdown_query = "(select * from Test_Table_SQL_MR) emp_alias"
df_read = spark.read.jdbc(url=url, table=pushdown_query, properties=properties)
display(df_read)

# COMMAND ----------

df_read2 = spark.read.jdbc(url=url, table="Test_Table_SQL_MR", properties=properties)
display(df_read2)



# COMMAND ----------

df_read2.write.csv('/FileStore/tables/TABTEST/DATA_TARGET-3.csv')

df_read2.write.format("parquet").saveAsTable("MY_PARQ_TABLE_NAME")

df_read2.write.format("csv").saveAsTable("MY_CSV_TABLE_NAME")

# COMMAND ----------

df_read2.write.csv("/mnt/containershareddna01/DATA_TARGET.csv")