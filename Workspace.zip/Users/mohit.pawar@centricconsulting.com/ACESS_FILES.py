# Databricks notebook source
dbutils.fs.mount(
  source = "wasbs://containershareddna01@sashareddna01.blob.core.windows.net",
  mount_point = "/mnt/containershareddna01",
  extra_configs = {"fs.azure.account.key.sashareddna01.blob.core.windows.net":dbutils.secrets.get(scope = "scopedna01", key = "secretdna01")})


# COMMAND ----------


df= spark.read.csv("/mnt/containershareddna01/DATA*.csv")

dbutils.fs.rm("/FileStore/tables/ADB.txt")

# COMMAND ----------

df.show()

# COMMAND ----------

mydf = sqlContext.read.csv("/FileStore/tables/DATA_SOURCE.csv",header=True)
mydf.show()

# COMMAND ----------

mydf.write.format("delta").mode("overwrite").saveAsTable("test_delta_table_MR")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from test_delta_table_MR

# COMMAND ----------

spark.sql("select * from test_delta_table_MR").show(3)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY test_delta_table_MR

# COMMAND ----------

mydf.write.format("delta").mode("append").saveAsTable("test_delta_table_MR")
mydf.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("test_delta_table_MR")