# Databricks notebook source
# MAGIC %md
# MAGIC # Demo: Spark Streaming with Delta Lake 
# MAGIC 
# MAGIC <img src="https://github.com/billkellett/databricks-demo-delta-streaming/blob/master/images/delta-lake-logo.png?raw=true" width=200/>
# MAGIC 
# MAGIC Delta Lake brings reliability, performance, and lifecycle management to data lakes. In this demo, we'll see the business value of one specific feature of Delta Lake: we'll see how Delta Lake works with **_Spark Structured Streaming_** to make streaming applications simpler and more efficient.
# MAGIC 
# MAGIC We'll be looking at three scenarios today:
# MAGIC - Using Delta Lake to create a __Streaming Sink__.
# MAGIC - Reading that sink as a __Streaming Source__.
# MAGIC - Aggregating a source, then writing it to a new sink to create a __Streaming Pipeline__.
# MAGIC 
# MAGIC As we walk through this demo, ask yourself, "Can my data lake do this?  How would I respond today to the scenarios described in this demo?"
# MAGIC 
# MAGIC ### *Our story so far...*
# MAGIC 
# MAGIC For this demo, we've imagined a company that sells consumer goods.  We have a very simple data feed that represents purchase transactions.  The feed contains the following data:
# MAGIC 
# MAGIC - __User ID:__ a GUID
# MAGIC - __Region:__ one of AMERICAS, APAC, or EMEA
# MAGIC - __Amount:__ the dollar amount of the transaction
# MAGIC - __Source Time:__ timestamp of the transaction

# COMMAND ----------

# MAGIC %md
# MAGIC <img src="https://github.com/billkellett/databricks-demo-delta-streaming/blob/master/images/stop.png?raw=true" width=100/> NOTE: Before running this demo, be sure to do a Run All on the PREP notebook that accompanies this demo. This will prepare all the data needed for this demo.

# COMMAND ----------

# MAGIC %md
# MAGIC ## What is a Stream? <img src="https://github.com/billkellett/databricks-demo-delta-streaming/blob/master/images/spark-streaming-logo.png?raw=true" width=200/>
# MAGIC 
# MAGIC The "traditional" way to process data is in batches.  In a __batch__, a collection of data is complete and "at rest" *before* we access it.
# MAGIC 
# MAGIC In contrast, a data __stream__ is a __continuous flow of data__.  When we access a stream, we expect that new data will appear *after* we open the stream.  The data may arrive in regular or irregular intervals.  Common __examples__ of streams include:
# MAGIC 
# MAGIC - Telemetry from devices
# MAGIC - Log files from applications
# MAGIC - Transactions created by users
# MAGIC 
# MAGIC Common stream __technologies__ include:
# MAGIC 
# MAGIC - Sockets
# MAGIC - Java Message Service (JMS) applications, including RabbitMQ, ActiveMQ, IBM MQ, etc.
# MAGIC - Apache Kafka
# MAGIC 
# MAGIC As we'll see lin this demo, __Delta Lake__ is also a highly effective solution for streaming use cases.  
# MAGIC 
# MAGIC The diagram below outlines the approach Spark takes to deal with streams.  We're using the newer Spark streaming technology, which is known as __Structured Streaming__.
# MAGIC 
# MAGIC <img src="https://github.com/billkellett/databricks-demo-delta-streaming/blob/master/images/spark-streaming-basic-concept.png?raw=true" />
# MAGIC 
# MAGIC As the diagram above illustrates, Spark considers a stream to be an "unbounded" or "infinite" table.  This is a brilliant concept because it allows us to use SQL against a stream.  However, as we shall see, there are some limitations.  
# MAGIC 
# MAGIC Keep in mind that a stream is constantly __*appending*__ data.  In streaming, we never update or delete an existing piece of data.  
# MAGIC 
# MAGIC #### OK, let's get started!

# COMMAND ----------

# Here is a bit of Spark housekeeping.  When we aggregate our stream later in this demo, Spark will need to shuffle data.
# For our small demo data size, we'll get much better performance by reducing the number of shuffle partitions.
# Default is 200.  Most of them won't be used, but each will have to wait for an available core, then start up and shut down.
# Let's run this cell to reduce the number of shuffle partitions.

spark.conf.set("spark.sql.shuffle.partitions", "3")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Create a stream
# MAGIC 
# MAGIC We're going to use a __Delta Lake table__, "DEMO\_DELTA\_STREAMING.purchases", as our __stream source__.  It's just an ordinary Delta Lake table, but when we run "readStream" against it below, it will become a streaming source.
# MAGIC 
# MAGIC The table doesn't contain any data yet.  We'll initiate the stream now, and then later in the demo we'll generate data into the table.

# COMMAND ----------

# Create a stream from the purchases table
purchases_stream = spark \
                   .readStream \
                   .format("delta") \
                   .table("DEMO_DELTA_STREAMING.purchases")

# Register the stream as a temporary view so we can run SQL on it
purchases_stream.createOrReplaceTempView("purchases_streaming")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Initiate 3 stream listeners
# MAGIC 
# MAGIC Execute the three cells below to initiate three stream listeners.  The comments in each cell will explain what each listener does.
# MAGIC 
# MAGIC After we initiate these listeners, we'll be ready to begin generating data into the stream.
# MAGIC 
# MAGIC Take special note of the difference between __full aggregation__ and __windowed aggregation__, which we use in the second and third listeners.  The diagram below shows how windowed aggregation works:
# MAGIC 
# MAGIC <img src="https://github.com/billkellett/databricks-demo-delta-streaming/blob/master/images/windowed_aggregation.png?raw=true" />
# MAGIC 
# MAGIC As the diagram illustrates, windowed aggregation uses only a subset of the data.  This subset is typically chosen based on a timestamp range.  Note that the timestamp is from the data itself, not from the current time of our code in this notebook.  In the diagram above, we are using a timestamp column to select data within 10-minute ranges.
# MAGIC 
# MAGIC In addition, we can __slide__ the window.  In the diagram above, we are sliding the 10-minute window every 5 minutes.  

# COMMAND ----------

# MAGIC %sql
# MAGIC -- full aggregation
# MAGIC 
# MAGIC -- This is a streaming query that reads the purchases_streaming stream.
# MAGIC -- It calculates the average purchase price for each of our company's regions: AMERICAS, APAC, and EMEA
# MAGIC -- Note that this average purchase price is continually calculated for the entire stream, since "the beginning of time."
# MAGIC 
# MAGIC -- Start this query now.  It will initialize, then remain inactive until we start generating data in a cell further down.
# MAGIC 
# MAGIC SELECT 
# MAGIC   region, 
# MAGIC   avg(amount) AS avg_amount 
# MAGIC FROM purchases_streaming 
# MAGIC GROUP BY region 
# MAGIC ORDER BY region ASC
# MAGIC 
# MAGIC -- Before you move on from this cell, make sure the "Stream initializing" message below goes away.
# MAGIC 
# MAGIC -- REMEMBER... you will have to come back to this cell later and CANCEL the streaming query.
# MAGIC -- Otherwise, your cluster will run indefinitely.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- windowed aggregation
# MAGIC 
# MAGIC -- This is also a streaming query that reads the purchases_streaming stream.
# MAGIC -- It also calculates the average purchase price for each of our company's regions: AMERICAS, APAC, and EMEA
# MAGIC -- However, note that this average purchase price is NOT calculated for the entire stream, since "the beginning of time."
# MAGIC -- Instead, this query serves a "dashboard" use case, because it calculates the average spend over a 2-minute window of time.
# MAGIC -- Furthermore, this 2-minute window "slides" by a minute once per minute.
# MAGIC 
# MAGIC -- Start this query now.  It will initialize, then remain inactive until we start generating data in a cell further down.
# MAGIC 
# MAGIC SELECT 
# MAGIC   window, -- this is a reserved word that lets us define windows
# MAGIC   region, 
# MAGIC   avg(amount) AS avg_amount, 
# MAGIC   count(amount) AS count_in_window 
# MAGIC FROM purchases_streaming 
# MAGIC GROUP BY 
# MAGIC   window(source_time, '2 minutes', '1 minute'), -- NOTE that the windows uses a data column in the record.  It is NOT the current time in our code.
# MAGIC   region 
# MAGIC ORDER BY 
# MAGIC   window DESC, 
# MAGIC   region ASC 
# MAGIC LIMIT 6 -- this lets us see the last two window aggregations for each region
# MAGIC 
# MAGIC -- Before you move on from this cell, make sure the "Stream initializing" message below goes away.
# MAGIC 
# MAGIC -- REMEMBER... you will have to come back to this cell later and CANCEL the streaming query.
# MAGIC -- Otherwise, your cluster will run indefinitely.

# COMMAND ----------

# windowed aggregation WITH STREAMING OUTPUT

# This is the same aggregate query we ran above, but here we also WRITE the aggregated stream to a Delta Lake table.
# We could have done all this in the original query, of course, but we wanted to introduce the concepts one at a time.

# This is useful because now another independent application can read the Delta Lake pre-aggregated table at will to 
# easily produce a dashboard or other useful output.

# Start this query now.  It will initialize, then remain inactive until we start generating data in a cell further down.

out_stream = spark.sql("""SELECT 
                            window, 
                            region, 
                            avg(amount) AS avg_amount, 
                            count(amount) AS count_in_window 
                          FROM purchases_streaming 
                          GROUP BY 
                            window(source_time, '2 minutes', '1 minute'), 
                            region 
                          ORDER BY 
                            window DESC, 
                            region ASC""")

# Here we create a new output stream, which is an aggregated version of the data from our original stream.
# Note that we use .outputMode("complete")...
# Spark Structured Streaming has three output modes:
#  - append - this is used when we want to write detail-level records.  You cannot query an entire table of detail records, 
#             you can only see the latest data in the stream.
# - complete - however, if you query a stream with an aggregate query, Spark will retain and update the entire aggregate.
#              In this mode, we will continue to output new versions of the entire aggregation result set.
# - update - this is similar to complete, and is also used for aggregations.  The difference is that "update" will only
#            write the *changed* rows of an aggregate result set.
out_stream.writeStream \
          .outputMode("complete") \
          .option("checkpointLocation", "/demo_streaming_ckpnt") \
          .option("mergeSchema", "true") \
          .format("delta") \
          .table("DEMO_DELTA_STREAMING.purchases_agg")

# Before you move on from this cell, make sure the "Stream initializing" message below goes away.

# REMEMBER... you will have to come back to this cell later and CANCEL the streaming query.
# Otherwise, your cluster will run indefinitely.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Begin generating data
# MAGIC 
# MAGIC Now we're ready to start pumping data into our stream.
# MAGIC 
# MAGIC The cell below generates transaction records into the Delta Lake table.  Our stream queries above will then consume this data.

# COMMAND ----------

# Generate data

# Now we'll run this code to generate records into our stream.

from datetime import datetime
import random
import time
import uuid

while(True):
  
  # AMERICAS row
  time.sleep(1)

  # calculate a new number for purchase amount
  # randint() creates an integer, and random() creates a number between 0 and 1
  # the {0:.2f} expression ensures that trailing zeroes will display 
  purchase_amount = round(random.randint(0, 10000) + random.random(), 2)
  
  now = datetime.now()
  id = uuid.uuid4()

  # Insert
  americas_sql = f"INSERT INTO DEMO_DELTA_STREAMING.purchases VALUES ('{id}', 'AMERICAS', {purchase_amount}, '{now}')"
  spark.sql(americas_sql)
    
  # APAC row
  time.sleep(1)

  # calculate a new number for purchase amount
  purchase_amount = round(random.randint(0, 10000) + random.random(), 2)
  
  now = datetime.now()
  id = uuid.uuid4()

  # Insert
  apac_sql = f"INSERT INTO DEMO_DELTA_STREAMING.purchases VALUES ('{id}', 'APAC', {purchase_amount}, '{now}')"
  spark.sql(apac_sql)
  
  # EMEA row
  time.sleep(1)

  # calculate a new number for purchase amount
  purchase_amount = round(random.randint(0, 10000) + random.random(), 2)
  
  now = datetime.now()
  id = uuid.uuid4()

  # Insert
  emea_sql = f"INSERT INTO DEMO_DELTA_STREAMING.purchases VALUES ('{id}', 'EMEA', {purchase_amount}, '{now}')"
  spark.sql(emea_sql)
  
# REMEMBER... you will have to come back to this cell later and CANCEL it.
# Otherwise, your cluster will run indefinitely.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Examine the 3 streaming queries we started above.  
# MAGIC 
# MAGIC Take a look at the data generated by our three streaming readers.  Notice the difference between the full aggregation and the windowed aggregation.
# MAGIC 
# MAGIC Also click <img src="https://github.com/billkellett/databricks-demo-delta-streaming/blob/master/images/data_icon.png?raw=true" /> in the left sidebar and note that our stream writer has created a new table, purchases_agg.

# COMMAND ----------

# MAGIC %md
# MAGIC <img src="https://github.com/billkellett/databricks-demo-delta-streaming/blob/master/images/stop.png?raw=true" width=100/> NOTE: Before you continue, be sure to cancel the running cells, which include the data generator and the three stream readers.
# MAGIC 
# MAGIC If you do not cancel these cells, your cluster will run indefinitely!

# COMMAND ----------

# MAGIC %md
# MAGIC ### Examine the new sink we created
# MAGIC 
# MAGIC Let's take a look at the new Delta Lake table we created above using writeStream().
# MAGIC 
# MAGIC This would be a great data source for a separate dashboard application.  The application could simply query the table at will, and format the results.  It wouldn't have to worry at all about streaming or aggregation, since the information has already been prepared and formatted.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Now imagine that this is our independent dashboard-building program.
# MAGIC -- It can read the pre-aggregated data on Delta Lake at will, and simply display the data.
# MAGIC 
# MAGIC select 
# MAGIC   window.start AS window_start,
# MAGIC   window.end AS window_end,
# MAGIC   region,
# MAGIC   avg_amount,
# MAGIC   count_in_window AS detail_recs_in_agg 
# MAGIC from demo_delta_streaming.purchases_agg
# MAGIC order by window desc, region asc
# MAGIC LIMIT 6

# COMMAND ----------

# MAGIC %md
# MAGIC ### What just happened?
# MAGIC 
# MAGIC In this demo, we saw how Delta Lake enables Spark Structured Streaming use cases.
# MAGIC 
# MAGIC Specifically, we examined:
# MAGIC 
# MAGIC - Delta Lake tables as both stream sources and sinks
# MAGIC - Stream aggregation of an entire stream
# MAGIC - Windowed stream aggregation

# COMMAND ----------

# MAGIC %md
# MAGIC ### If you want to learn more and go deeper...
# MAGIC 
# MAGIC Spark Structured Streaming has many advanced features, including watermarks, de-duping capabilities, etc.  To learn more, see the Structured Streaming Programming Guide here: https://spark.apache.org/docs/latest/structured-streaming-programming-guide.html 
# MAGIC 
# MAGIC A very important use case for streaming is known as "write-once."  You can learn more about it here: https://databricks.com/blog/2017/05/22/running-streaming-jobs-day-10x-cost-savings.html

# COMMAND ----------

