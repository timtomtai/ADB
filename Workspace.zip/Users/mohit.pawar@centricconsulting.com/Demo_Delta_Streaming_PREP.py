# Databricks notebook source
# MAGIC %md # PREP Notebook for Delta Lake Structured Streaming Demo
# MAGIC 
# MAGIC This notebook prepares the data used by the main demo notebook.
# MAGIC 
# MAGIC Do a Run All on this PREP notebook before running the main demo notebook.
# MAGIC 
# MAGIC NOTE: This PREP notebook is idempotent.  You can run it repeatedly without causing any harm.

# COMMAND ----------

# Delete spark structured streaming checkpoint, if it exists

dbutils.fs.rm("/demo_streaming_ckpnt", True) # True means recurse

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP DATABASE IF EXISTS DEMO_DELTA_STREAMING CASCADE

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE DATABASE IF NOT EXISTS DEMO_DELTA_STREAMING

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Just in case you don't run all the cells above
# MAGIC 
# MAGIC DROP TABLE IF EXISTS DEMO_DELTA_STREAMING.purchases

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS DEMO_DELTA_STREAMING.purchases
# MAGIC   (user_id STRING, 
# MAGIC     region STRING, 
# MAGIC     amount DECIMAL(10,2),
# MAGIC     source_time TIMESTAMP)
# MAGIC   USING DELTA 

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Just in case you don't run all the cells above
# MAGIC 
# MAGIC TRUNCATE TABLE demo_delta_streaming.purchases