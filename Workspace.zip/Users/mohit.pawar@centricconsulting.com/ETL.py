# Databricks notebook source
# MAGIC %md 
# MAGIC # Secure access to disparate data sources with Databricks <img src="https://github.com/billkellett/databricks-demo-etl/blob/master/images/databricks_logo.png?raw=true" />
# MAGIC 
# MAGIC This notebook shows how you can use Databricks notebooks to easily access, join, and save data from many disparate data sources, both within and outside of your cloud provider's platform. 
# MAGIC 
# MAGIC We have imagined that our enterprise is a B2B product provider that sells to large corporate accounts.  Within each customer corporation, there are multiple individuals who can purchase from us.  We want to be able to analyze these purchase transactions.
# MAGIC 
# MAGIC ## Our Demo Use Case: An Extract-Transform-Load (ETL) scenario to gather and prepare data for an analytics effort
# MAGIC 
# MAGIC In this demo, we imagine that a Data Analyst needs to collect and combine data from several different sources.  The combined data can then be used to enable many different Analytics projects.  Some of the data sources already exist on the enterprise's cloud platform, but other data we need is in on-premise databases.  Since we are concentrating on data access in this demo, we won't actually be doing much in terms of transformation... but we'll leave that as an exercise for your imagination!
# MAGIC 
# MAGIC ### Why is this a hard problem for most enterprises?
# MAGIC 
# MAGIC This is a very common problem for large enterprises:
# MAGIC 
# MAGIC - If your firm is just beginning its journey to the cloud, it is very likely that you will need to access important data resources that have not yet been migrated.
# MAGIC - Even if your firm is mature in the cloud, new data sources are always appearing.  Corporate IT ETL teams often have large backlogs of work requests, and may not be able to service your needs in a timely manner.
# MAGIC 
# MAGIC In either of the above situations, you still need to get your work done.  Fortunately, Databricks makes it easy to access external data sources in a secure manner!
# MAGIC 
# MAGIC ### Why is Databricks ETL helpful to your IT team?
# MAGIC 
# MAGIC There are three common scenarios we see in large enterprises.  All are very helpful to corporate IT:
# MAGIC 
# MAGIC - __Scenario 1:__ Your project is __*production-ready*__.  IT may decide that the work you have done is secure and repeatable as a production job. 
# MAGIC - __Scenario 2:__ Your project __*can be made production-ready*__.  IT may decide that with a few enhancements, like additional documentation or logging, your project can be certified.
# MAGIC - __Scenario 3:__ Your project provides a __*high-quality prototype and spec*__ for a production-ready project that IT undertakes.  
# MAGIC 
# MAGIC In all of the above scenarios, your project (1) helps IT, and (2) ensures that you can get your work done while IT considers its next steps
# MAGIC 
# MAGIC ### The Data
# MAGIC 
# MAGIC In this demo, we use four data sources:
# MAGIC 
# MAGIC - __Corporate Accounts:__ this table contains the account numbers and company names of all the corporations we serve.  It resides on a __*Microsoft SQL Server database on-premise*__.
# MAGIC - __Corporate Users:__ these are the individual people who are authorized by their firms to buy from us.  This data resides in a __*CSV file in our cloud storage*__.
# MAGIC - __Purchase Transactions:__ individual purchase transactions reside in a __*Delta Lake table in our cloud storage*__.
# MAGIC - __Product Details:__ descriptive information for each of our products is stored in a __*MySQL database on-premise*__.
# MAGIC 
# MAGIC 
# MAGIC ### What will we see in this demo?
# MAGIC 
# MAGIC In this demo, we'll use the power of Databricks Notebooks to access all these disparate data sources, and treat them as if they reside in a single database!
# MAGIC 
# MAGIC First, we'll show how to access each data source.  Then we'll Join the data, treating it as a single, unified database.  Perhaps most important of all, we'll see how all of this can be done in a __*secure*__ manner with __*Databricks Notebooks*__.

# COMMAND ----------

# MAGIC %md
# MAGIC <img src="https://github.com/billkellett/databricks-demo-etl/blob/master/images/stop.png?raw=true" width=100/>
# MAGIC 
# MAGIC ### Please note the following:
# MAGIC 
# MAGIC - Before running this demo, you must first run the accompanying __PREP notebook__.
# MAGIC 
# MAGIC - To run this demo, you will need access to __two databases__:
# MAGIC   - Microsoft SQL Server
# MAGIC   - MySQL
# MAGIC   
# MAGIC   If you do not have access to these databases, you can still examine the cells below without running them.  Notice that we have saved the results from a previous run in each cell, so you can see what happened.
# MAGIC   
# MAGIC   If you are a Databricks employee, and would like access to the databases used in this demo, please contact Bill Kellett.

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Let's begin by looking at the Transaction data that lives in a Delta Lake table.
# MAGIC 
# MAGIC SELECT * FROM DEMO_ETL.CORP_TRANSACTION

# COMMAND ----------

# Next, let's look at the Corporate User data that resides on a CSV file

csv_file = "/demo-etl/ETL_CORP_USER.csv"

corp_user_df = spark.read \
  .option("header", "true") \
  .option("delimiter", ",") \
  .option("inferSchema", "true") \
  .csv(csv_file)                    

display(corp_user_df)

# COMMAND ----------

# This call enables us to use the Corporate User table just as if it were a database table

corp_user_df.createOrReplaceTempView("CORP_USER")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT * FROM CORP_USER

# COMMAND ----------

csv_file = "/demo-etl/ETL_CORP_ACCOUNT.csv"

corp_account_df = spark.read \
  .option("header", "true") \
  .option("delimiter", ",") \
  .option("inferSchema", "true") \
  .csv(csv_file)                    

display(corp_account_df)

# COMMAND ----------

# I'll create this view, which will let me run SQL against the local Spark copy of the data.

corp_account_df.createOrReplaceTempView("CORP_ACCOUNT")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT * FROM CORP_ACCOUNT

# COMMAND ----------

csv_file = "/demo-etl/ETL_PRODUCT.csv"

product_df = spark.read \
  .option("header", "true") \
  .option("delimiter", ",") \
  .option("inferSchema", "true") \
  .csv(csv_file)                    

display(product_df)

# COMMAND ----------

# Again, I'll create a view, so I can run SQL against the local Spark copy of the data

product_df.createOrReplaceTempView("PRODUCT")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Disparate, Schmisparate! <img src="https://github.com/billkellett/databricks-demo-etl/blob/master/images/e_pluribus_unum.jpg?raw=true" >
# MAGIC 
# MAGIC Now we'll see the real magic of Spark SQL.  Even though our data came from four different places, in four different formats, we can work with it as a single, unified database!

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT 
# MAGIC   CORP_ACCOUNT.account_number,
# MAGIC   CORP_ACCOUNT.company_name,
# MAGIC   CORP_USER.user_id,
# MAGIC   CORP_USER.first_name,
# MAGIC   CORP_USER.last_name,
# MAGIC   CORP_USER.email
# MAGIC   FROM CORP_ACCOUNT
# MAGIC   INNER JOIN CORP_USER
# MAGIC     ON CORP_ACCOUNT.account_number = CORP_USER.account_number

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Join all 4 tables together!
# MAGIC 
# MAGIC SELECT 
# MAGIC   CORP_ACCOUNT.account_number,
# MAGIC   CORP_ACCOUNT.company_name,
# MAGIC   CORP_USER.user_id,
# MAGIC   CORP_USER.first_name,
# MAGIC   CORP_USER.last_name,
# MAGIC   CORP_USER.email,
# MAGIC   DEMO_ETL.CORP_TRANSACTION.transaction_date_time,
# MAGIC   DEMO_ETL.CORP_TRANSACTION.product_id,
# MAGIC   DEMO_ETL.CORP_TRANSACTION.product_quantity,
# MAGIC   DEMO_ETL.CORP_TRANSACTION.product_unit_price,
# MAGIC   PRODUCT.manufacturer,
# MAGIC   PRODUCT.description
# MAGIC 
# MAGIC FROM CORP_ACCOUNT
# MAGIC   INNER JOIN CORP_USER
# MAGIC     ON CORP_ACCOUNT.account_number = CORP_USER.account_number
# MAGIC       INNER JOIN DEMO_ETL.CORP_TRANSACTION
# MAGIC         ON (CORP_USER.account_number = DEMO_ETL.CORP_TRANSACTION.account_number) AND (CORP_USER.user_id = DEMO_ETL.CORP_TRANSACTION.user_id)
# MAGIC           INNER JOIN PRODUCT
# MAGIC             ON DEMO_ETL.CORP_TRANSACTION.product_id = PRODUCT.product_id
# MAGIC             
# MAGIC ORDER BY 
# MAGIC   company_name ASC,
# MAGIC   transaction_date_time DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Even better, we can save our result set in a new Delta Lake table, so we can use it for many different tasks in the future.
# MAGIC 
# MAGIC DROP TABLE IF EXISTS DEMO_ETL.FULL_HISTORY;
# MAGIC 
# MAGIC CREATE TABLE DEMO_ETL.FULL_HISTORY
# MAGIC AS
# MAGIC SELECT 
# MAGIC   CORP_ACCOUNT.account_number,
# MAGIC   CORP_ACCOUNT.company_name,
# MAGIC   CORP_USER.user_id,
# MAGIC   CORP_USER.first_name,
# MAGIC   CORP_USER.last_name,
# MAGIC   CORP_USER.email,
# MAGIC   DEMO_ETL.CORP_TRANSACTION.transaction_date_time,
# MAGIC   DEMO_ETL.CORP_TRANSACTION.product_id,
# MAGIC   DEMO_ETL.CORP_TRANSACTION.product_quantity,
# MAGIC   DEMO_ETL.CORP_TRANSACTION.product_unit_price,
# MAGIC   PRODUCT.manufacturer,
# MAGIC   PRODUCT.description
# MAGIC 
# MAGIC FROM CORP_ACCOUNT
# MAGIC   INNER JOIN CORP_USER
# MAGIC     ON CORP_ACCOUNT.account_number = CORP_USER.account_number
# MAGIC       INNER JOIN DEMO_ETL.CORP_TRANSACTION
# MAGIC         ON (CORP_USER.account_number = DEMO_ETL.CORP_TRANSACTION.account_number) AND (CORP_USER.user_id = DEMO_ETL.CORP_TRANSACTION.user_id)
# MAGIC           INNER JOIN PRODUCT
# MAGIC             ON DEMO_ETL.CORP_TRANSACTION.product_id = PRODUCT.product_id

# COMMAND ----------

# MAGIC %md
# MAGIC In the cell above, we saved our result set to a new Delta Lake table.  Click <img src="https://github.com/billkellett/databricks-demo-etl/blob/master/images/data_icon.png?raw=true" > to see that our new table, FULL_HISTORY, exists in the database named DEMO_ETL:
# MAGIC 
# MAGIC <img src="https://github.com/billkellett/databricks-demo-etl/blob/master/images/delta_tables.png?raw=true" >

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Let's read the table we just created
# MAGIC 
# MAGIC SELECT * FROM DEMO_ETL.FULL_HISTORY
# MAGIC ORDER BY 
# MAGIC   company_name ASC,
# MAGIC   transaction_date_time DESC

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT COMPANY_NAME,PRODUCT_ID,SUM(PRODUCT_QUANTITY) AS QUANTITY,SUM(PRODUCT_UNIT_PRICE*PRODUCT_QUANTITY) AS TOTAL
# MAGIC FROM DEMO_ETL.FULL_HISTORY
# MAGIC GROUP BY COMPANY_NAME,PRODUCT_ID
# MAGIC ORDER BY TOTAL DESC

# COMMAND ----------

# MAGIC %md
# MAGIC ### What just happened?
# MAGIC 
# MAGIC In this demo, we saw the following:
# MAGIC 
# MAGIC - Spark ETL capabilities make it easy to access data from many different sources, in many disparate sources
# MAGIC - Once we access the data, we can deal with it as a single, unified database
# MAGIC - Databricks Notebooks let us easily define these ETL processes
# MAGIC - Databricks Secrets ensure that our notebooks maintain enterprise-worthy security

# COMMAND ----------

# MAGIC %md
# MAGIC ### If you want to learn more and go deeper...
# MAGIC 
# MAGIC Databricks Secrets documentation is here: https://docs.databricks.com/security/secrets/index.html 
# MAGIC 
# MAGIC Spark JDBC documentation is here: https://spark.apache.org/docs/latest/sql-data-sources-jdbc.html 
# MAGIC 
# MAGIC Databricks JDBC documentation is here: https://docs.databricks.com/data/data-sources/sql-databases.html 

# COMMAND ----------

