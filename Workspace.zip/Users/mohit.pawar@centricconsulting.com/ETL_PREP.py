# Databricks notebook source
# MAGIC %md
# MAGIC ## PREP Notebook for demo of Extract-Transform-Load (ETL)
# MAGIC 
# MAGIC Do a Run All on this PREP notebook to do all the "behind-the-scenes preparation" for the accompanying ETL Demo notebook.
# MAGIC 
# MAGIC In this PREP notebook, we do the following:
# MAGIC 
# MAGIC - Download data and move it to DBFS 
# MAGIC - Create database DEMO_ETL
# MAGIC - Create a CORP_TRANSACTION table in the DEMO_ETL database
# MAGIC 
# MAGIC #### NOTE:
# MAGIC This PREP notebook is idempotent. You can run it repeatedly.

# COMMAND ----------

# MAGIC %sh
# MAGIC # Verify the working directory on the local file system
# MAGIC pwd

# COMMAND ----------

# MAGIC %sh 
# MAGIC # Create a local directory to hold the files we are about to download
# MAGIC mkdir -p /databricks/driver/demo/etl

# COMMAND ----------

# MAGIC %sh
# MAGIC # download data into the local file system
# MAGIC curl -o /databricks/driver/demo/etl/ETL_CORP_USER.csv 'https://raw.githubusercontent.com/billkellett/databricks-demo-etl/master/data/ETL_CORP_USER.csv' -L
# MAGIC curl -o /databricks/driver/demo/etl/ETL_TRANSACTION.csv 'https://raw.githubusercontent.com/billkellett/databricks-demo-etl/master/data/ETL_TRANSACTION.csv' -L
# MAGIC curl -o /databricks/driver/demo/etl/ETL_PRODUCT.csv 'https://raw.githubusercontent.com/billkellett/databricks-demo-etl/master/data/ETL_PRODUCT.csv' -L
# MAGIC curl -o /databricks/driver/demo/etl/ETL_CORP_ACCOUNT.csv 'https://raw.githubusercontent.com/billkellett/databricks-demo-etl/master/data/ETL_CORP_ACCOUNT.csv' -L

# COMMAND ----------

# If the demo DBFS directory exists, delete it
dbutils.fs.rm("demo-etl", True) # recurse = True

# COMMAND ----------

# MAGIC %md
# MAGIC Copy files to DBFS

# COMMAND ----------

# MAGIC %fs
# MAGIC cp file:/databricks/driver/demo/etl/ETL_CORP_USER.csv dbfs:/demo-etl/ETL_CORP_USER.csv

# COMMAND ----------

# MAGIC %fs
# MAGIC cp file:/databricks/driver/demo/etl/ETL_TRANSACTION.csv dbfs:/demo-etl/ETL_TRANSACTION.csv

# COMMAND ----------

# MAGIC %fs
# MAGIC cp file:/databricks/driver/demo/etl/ETL_PRODUCT.csv dbfs:/demo-etl/ETL_PRODUCT.csv

# COMMAND ----------

# MAGIC %fs
# MAGIC cp file:/databricks/driver/demo/etl/ETL_CORP_ACCOUNT.csv dbfs:/demo-etl/ETL_CORP_ACCOUNT.csv

# COMMAND ----------

# Load the transaction file in preparation for writing it to a database table
csv_file = "/demo-etl/ETL_TRANSACTION.csv"

transaction_df = spark.read \
  .option("header", "true") \
  .option("delimiter", ",") \
  .option("inferSchema", "true") \
  .csv(csv_file)                    

display(transaction_df)

# COMMAND ----------

# Create a temp view of the transaction file so we can use SQL to write it to a database table
transaction_df.createOrReplaceTempView("transaction_temp")

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Drop the demo database
# MAGIC DROP DATABASE IF EXISTS DEMO_ETL CASCADE

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the demo database
# MAGIC CREATE DATABASE IF NOT EXISTS DEMO_ETL

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Drop the table (in case you skip steps above)
# MAGIC DROP TABLE IF EXISTS DEMO_ETL.CORP_TRANSACTION

# COMMAND ----------

# MAGIC %sql
# MAGIC -- Create the database table and load data from the temp view
# MAGIC CREATE TABLE IF NOT EXISTS DEMO_ETL.CORP_TRANSACTION
# MAGIC   AS (SELECT * FROM transaction_temp)

# COMMAND ----------

