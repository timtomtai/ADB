# Databricks notebook source
# MAGIC %md #Header

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *


# COMMAND ----------

# MAGIC %md ##Read excel

# COMMAND ----------

#sample data file path
sampleDataFilePath = "/mnt/containershareddna01/teamC_storage/Order History.xls"

#flags required for reading the excel
isHeaderOn = 'true'
isInferSchemaOn = 'false'
#sheet address in excel
sample1Address = "'Holdings'!A1"
sample2Address = "'Transactions'!A1"
#read excelfile
sample1DF = spark.read.format("com.crealytics.spark.excel") \
.option("header", isHeaderOn) \
.option("inferSchema", isInferSchemaOn) \
.option("treatEmptyValuesAsNulls", "false") \
.option("dataAddress", sample2Address) \
.load(sampleDataFilePath)
display(sample1DF)

# COMMAND ----------

# MAGIC %md ##Create a dataFrame

# COMMAND ----------


data = [('James','','Smith','1991-04-01','M',3000),
  ('Michael','Rose','','2000-05-19','M',4000),
  ('Robert','','Williams','1978-09-05','M',4000),
  ('Maria','Anne','Jones','1967-12-01','F',4000),
  ('Jen','Mary','Brown','1980-02-17','F',-1)
]

columns = ["firstname","middlename","lastname","dob","gender","salary"]

df = spark.createDataFrame(data=data, schema = columns)
df.show()

# COMMAND ----------

# MAGIC %md ##Read file in dataFrame

# COMMAND ----------

df_01= spark.read.load("/mnt/containershareddna01/DATA_SOURCE.csv", format="csv", header = "true",inferSchema = 'true')
df_01.show()

# COMMAND ----------

# MAGIC %md ###Read only selected columns and data in dataFrame

# COMMAND ----------

df_02= spark.read.load("/mnt/containershareddna01/DATA_SOURCE.csv", format="csv", header = "true",inferSchema = 'true').\
                        select("Name","Salary").filter("Name = 'Rohit'")
df_02.show()

# COMMAND ----------

# MAGIC %md ##Operations on dataFrame

# COMMAND ----------

#df_01.printSchema
# Out[13]: <bound method DataFrame.printSchema of DataFrame[Name: string, Address: string, MS: string, Salary: int]>

#df_01.dtypes
# Out[12]: [('Name', 'string'),
#  ('Address', 'string'),
#  ('MS', 'string'),
#  ('Salary', 'int')]

#df_01.columns
#df_01.head(2)	
#df_01.select('Name','Address').show()
#df_01.drop('MS','Salary').show()

# COMMAND ----------

# MAGIC %md ##PySpark withColumn
# MAGIC is a transformation function of DataFrame which is used to change the value, convert the datatype of an existing column, create a new column, and many more.

# COMMAND ----------

# MAGIC %md ###Change datatype

# COMMAND ----------

df_01.withColumn("salary",col("salary").cast("Integer")).show()  

# COMMAND ----------

# MAGIC %md ###Update value

# COMMAND ----------

df_01.withColumn("salary",col("salary")*100).show() 

# COMMAND ----------

# MAGIC %md ###Add new column

# COMMAND ----------

df_01.withColumn("New Salary",col("salary")* -1).show() 

# COMMAND ----------

# MAGIC %md ###lit function 
# MAGIC to add constant values in new columns

# COMMAND ----------

#add column with cons value
#df_01.withColumn("Country", lit("USA")).show()   	

#add multiple cols
df_01.withColumn("Country", lit("USA")) \
  .withColumn("anotherColumn",lit("anotherValue")) \
  .show()

# COMMAND ----------

# MAGIC %md ###Rename column

# COMMAND ----------

df_01.withColumnRenamed("Address","Country").show()

# COMMAND ----------

# MAGIC %md ###Conditional update

# COMMAND ----------

df_01.withColumn( 'Address', when(col('Address') =='UK','US')\
                 .otherwise(df_01.Address)).show()

# COMMAND ----------

# MAGIC %md ###CASE statement vs WHEN

# COMMAND ----------

variable='Country'

df_01.withColumn(variable, expr("CASE WHEN Address = 'US' THEN 'United States' " + 
               "WHEN Address = 'JK' THEN 'Not Avaialable' " +
               "ELSE Address END")).show()

df_01.withColumn(variable, when(df_01.Address == 'US', "United States")
                                 .when(df_01.Address == 'JK' ,"Not Available")
                                 .otherwise(df_01.Address)).show()



# COMMAND ----------

# MAGIC %md ##Append dataFrame

# COMMAND ----------


columns = ["Name",'Address',"MS",'Salary']
vals = [('Rahul','US','M',200),
    (None,'US',None,None),
     (None,None,None,None),
       ('Banta','UK',None,None)]
df=spark.createDataFrame(vals, columns)

df_01=df_01.union(df)
df_01.show()

# COMMAND ----------

# MAGIC %md ##na Function

# COMMAND ----------

# Both the commands below will drop all the rows in which 1 or more column is NULL.

df_01.na.drop(how='any').show()
df_01.na.drop().show()


df_01.na.drop(how='all').show()
# It will drop only rows where all columns are NULL.

df_01.na.drop(how='any',thresh=2).show()
# Thresh defines the minimum NOT NULL columns required in the result set.

df_01.na.drop(subset="Salary").show()  
# will drop rows where the column in subset is NULL

df_01.na.drop(how='any',subset=['Salary','Address']).show() 
#will drop rows where any of the columns in the subset is NULL


# COMMAND ----------

# MAGIC %md ## fill and fillna 
# MAGIC Both are aliases of each other and returns the same results.

# COMMAND ----------

#Sytax
# fillna(value, subset=None)
# fill(value, subset=None)

df_01.na.fill(value=0,subset=["Salary"]).show()

df_01.na.fill("unknown",["Address"]) \
     .na.fill("",["MS"]).show()

# COMMAND ----------

# MAGIC %md ## Filters

# COMMAND ----------

df_01.filter(df_01.Address == 'JK').show()	

# Not equal to filter
df_01.filter(~(df_01.Address == 'JK')).show()
df_01.filter(df_01.Address != 'JK').show()

#Two ways to handle integer value in filter
df_01.filter('Salary > 100').show()	
df_01.filter(df_01['Salary'] > 100).show()

# COMMAND ----------

# MAGIC %md ##Filter IS IN List values

# COMMAND ----------

li=["JK","US"]

df_01.filter(df_01.Address.isin(li)).show()

df_01.filter(~df_01.Address.isin(li)).show()

df_01.filter(df_01.Address.startswith("U")).show()

df_01.filter(df_01.Address.contains("K")).show()

df_01.filter(df_01.Name.like("%oh%")).show()

# COMMAND ----------

# MAGIC %md ##Distinct function

# COMMAND ----------

df_01.select('Address').distinct().show()

# COMMAND ----------

# MAGIC %md ##Sorting

# COMMAND ----------

#same output for both sort and orderBy

df_01.sort("Name","Address").show()
df_01.orderBy("Name","Address").show()

df_01.sort(df_01.Name.asc(),df_01.Address.desc()).show()

# COMMAND ----------

# Below is an example of how to sort DataFrame using raw SQL syntax.

df_01.createOrReplaceTempView("EMP")

spark.sql("select Name,Address,MS,Salary from EMP ORDER BY Address asc").show(truncate=False)

# COMMAND ----------

# MAGIC %md ##Group BY

# COMMAND ----------

df_01.groupBy('Address').sum().show()
df_01.groupBy('Address').min('Salary').show()
	
# NOTE: pySpark calculates the agg operations(sum,min,max,avg) on all the integer columns if not specified.

df_01.groupBy('Address','Name').sum('salary').show()

df_01.groupBy("Address") \
    .agg(sum("salary").alias("sum_salary"), \
         avg("salary").alias("avg_salary"), \
     ) \
    .show(truncate=False)

# COMMAND ----------

#Filtering the aggregated data : use either where() or filter()

df_01.groupBy("Address") \
    .agg(sum("Salary").alias("sum_salary"), \
      avg("Salary").alias("avg_salary")) \
    .where(col("sum_salary") >= 100) \
    .show(truncate=False)


# COMMAND ----------

# MAGIC %md ##Agg Function

# COMMAND ----------

#To calc different functions(min,max,mean) in 1 line we need to import Functions:

from pyspark.sql import functions as F
df_01.groupBy('Address').agg(F.mean('Salary'),F.min('Salary')).show()

# COMMAND ----------

#To aggregate without using group by :

df_01.agg({'Salary':'sum'}).show()		
df_01.agg({'Salary':'min'}).show()

# COMMAND ----------

# MAGIC %md ##UNION ALL and UNION (DISTINCT)

# COMMAND ----------

df_02 = df_01
df_02.distinct().count() 
#df_02.unionAll(df_01).count()	
#df_02.union(df_01).count()
#df_02.union(df_01).distinct().count()


# COMMAND ----------

df_01.show()

# COMMAND ----------

# MAGIC %md ##Create new DF for Join Operations

# COMMAND ----------

columns = ["Name",'Age',"Gender"]
vals = [('Mohit',30,'M'),
    (None,20,None),
     (None,None,None),
       ('Banta',28,'M'),
       ('Rohit',35,'M'),
       ('Rahul',40,'M')]
df_02=spark.createDataFrame(vals, columns)
df_02.show()

# COMMAND ----------

# MAGIC %md ## JOINS

# COMMAND ----------

df_01.join(df_02, df_01.Name == df_02.Name,'inner').show()

#df_01.join(df_02,df_01.Name == df_02.Name,'left').filter(df_02.Age >= 30).distinct().show()

# COMMAND ----------

# MAGIC %md # SELF JOIN

# COMMAND ----------

empDF=spark.read.option('header','true').csv("/mnt/containershareddna01/teamC_storage/employee.csv")\
        .select('Emp_id','Emp_name','Manager_id')
# Here, we are joining emp dataset with itself to find out superior emp_id and name for all employees.
# emp1=empDF.alias("emp1")
# emp2=empDF.alias('emp2')
empDF.alias('emp1').join(empDF.alias('emp2'), \
    col("emp1.Manager_id") == col("emp2.Emp_id"),"inner") \
    .select(col("emp1.Emp_id"),col("emp1.Emp_name"), \
      col("emp2.Emp_id").alias("Manager_id"), \
      col("emp2.Emp_name").alias("Manager_name")) \
   .show(truncate=False)

# COMMAND ----------

# We can also convert the dataFrames into tempViews and perform the functions like join etc by using spark sql

# empDF.createOrReplaceTempView("EMP")
# deptDF.createOrReplaceTempView("DEPT")

# joinDF = spark.sql("select * from EMP e, DEPT d where e.emp_dept_id == d.dept_id").show(truncate=False)

# joinDF2 = spark.sql("select * from EMP e INNER JOIN DEPT d ON e.emp_dept_id == d.dept_id").show(truncate=False)

# Joining Multiple dataFrames:
# df1.join(df2,df1.id1 == df2.id2,"inner").join(df3,df1.id1 == df3.id3,"inner")