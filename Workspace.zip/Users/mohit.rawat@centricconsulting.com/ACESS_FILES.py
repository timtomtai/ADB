# Databricks notebook source
dbutils.fs.mount(
    source = "wasbs://containershareddna02@sashareddna01.blob.core.windows.net",
    mount_point = "/mnt/containershareddna02",
    extra_configs = {"fs.azure.account.key.sashareddna01.blob.core.windows.net":dbutils.secrets.get(scope = "scope_adb_2", key = "secretdna02")})


# COMMAND ----------

dbutils.fs.mount(
    source = "wasbs://dnadatabricksdemo@datalakestorgen2dna01.blob.core.windows.net",
    mount_point = "/mnt/containershareddna03",
    extra_configs = {"fs.azure.account.key.datalakestorgen2dna01.blob.core.windows.net":dbutils.secrets.get(scope = "scope_adb_2", key = "secretdna03")})

# COMMAND ----------


    
display(dbutils.fs.mounts())


# COMMAND ----------

dbutils.fs.unmount("/mnt/containershareddna01")
    

# COMMAND ----------

dbutils.fs.refreshMounts()

# COMMAND ----------

dbutils.fs.mount(
  source = "wasbs://containershareddna02@sashareddna01.blob.core.windows.net",
  mount_point = "/mnt/containershareddna02",
  extra_configs = {"fs.azure.account.key.sashareddna01.blob.core.windows.net":dbutils.secrets.get(scope = "scope_adb_2", key = "secretdna02")})

# COMMAND ----------

dbutils.fs.mount(
  source = "wasbs://<container-name>@<storage-account-name>.blob.core.windows.net",
  mount_point = "/mnt/<mount-name>",
  extra_configs = {"<conf-key>":dbutils.secrets.get(scope = "<scope-name>", key = "<key-name>")})

# COMMAND ----------

mounts = dbutils.fs.mounts()

for mount in mounts:
  print(mount.mountPoint + " >> " + mount.source)

print("-"*80)

# COMMAND ----------

files = dbutils.fs.ls("/mnt/containershareddna03/Raw/")

for fileInfo in files:
  print(fileInfo.path)

print("-"*80)

display(files)



# COMMAND ----------

display(dbutils.fs.mounts())

# COMMAND ----------

dbutils.widgets.help()

# COMMAND ----------

# MAGIC %fs ls /mnt/containershareddna02

# COMMAND ----------

# MAGIC %fs ls /cluster-logs/1212-185926-ch28b7ag/driver/log4j-active.log

# COMMAND ----------

# MAGIC %fs ls /FileStore/tables/TABTEST/

# COMMAND ----------

df5 = spark.read.csv("/FileStore/tables/TABTEST/DATA_TARGET_TRIGGERED_ADF.csv")

df5.show()

# COMMAND ----------

# MAGIC %fs head /FileStore/tables/TABTEST/DATA_TARGET_TRIGGERED_ADF.csv

# COMMAND ----------


df= spark.read.csv("/mnt/containershareddna01/DATA*.csv")

#dbutils.fs.rm("/FileStore/tables/ADB.txt")

# COMMAND ----------

df.show()

# COMMAND ----------

mydf = sqlContext.read.csv("/FileStore/tables/DATA_SOURCE.csv",header=True)
mydf.show()

# COMMAND ----------

mydf.write.format("delta").mode("overwrite").saveAsTable("test_delta_table_MR")

# COMMAND ----------

df2 = sqlContext.sql("select row_number() over (order by 1) as cntr,Name from test_delta_table_MR")
df2.show()

# COMMAND ----------


from pyspark.sql.types import LongType, StructField, StructType

df3 = df2.rdd.zipWithIndex()
#df_final = df3.toDF()
#df_final.show()
# finally select the columns we need:
#df_final.select('index', 'column1', 'column2').show()
offset = 4
colName = "SURROGATE_KEY"
new_schema = StructType(
        [StructField(colName, LongType(),True)]  #new added field
        + df2.schema.fields) 

new_rdd = df3.map(lambda row: ([row[1]+offset] + list(row[0])))
    
df_final= spark.createDataFrame(new_rdd, new_schema)

df_final.show(1000)

# COMMAND ----------

df_1 = df_final[["_1"]]
#df_1.show()
s = df_final[["_1"]]

print(s)


# COMMAND ----------

print("mohit")

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from test_delta_table_MR

# COMMAND ----------

spark.sql("select * from test_delta_table_MR").show(3)

# COMMAND ----------

# MAGIC %sql
# MAGIC DESCRIBE HISTORY test_delta_table_MR

# COMMAND ----------

mydf.write.format("delta").mode("append").saveAsTable("test_delta_table_MR")
mydf.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable("test_delta_table_MR")