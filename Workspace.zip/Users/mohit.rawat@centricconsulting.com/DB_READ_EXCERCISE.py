# Databricks notebook source
print(spark)
print(sc)
print(sqlContext)

# COMMAND ----------

# MAGIC %sh echo $DB_CLUSTER_ID

# COMMAND ----------

It's worth noting that in Spark 2.0 SparkSession is a replacement for the other entry points:

SparkContext, available in our notebook as sc.
SQLContext, or more specifically it's subclass HiveContext, available in our notebook as sqlContext.


The function we are most interested in is SparkSession.read() which returns a DataFrameReader.

# COMMAND ----------

df1 = range(1,200)

# COMMAND ----------

display(df1)

# COMMAND ----------

csvDF = (spark.read
  .option('header', 'true')
  .option('sep', ",")
  #.schema(csvSchema)
  .csv('/mnt/containershareddna01/DATA_SOURCE.csv')
)
print("Partitions: " + str(csvDF.rdd.getNumPartitions()) )
print (RecordsPerPartition(csvDF))
printRecordsPerPartition
print("-"*80)