# Databricks notebook source
# Creating the Dataframe
def dataValidator(configfilePath, **kwargs) :
    
    from configparser import ConfigParser
    import json;
    from functools import reduce
    from pyspark.sql.types import IntegerType
    import copy
    from pyspark.sql.functions import col, lit
    from pyspark.sql import functions as f
    try:
        
        src = kwargs.get ('src_Initials', None)
        
        df = kwargs.get ('input_df', None)
        
        parser = ConfigParser()
        parser.read(configfilePath)
        Null_Check = json.loads(parser.get(src, "Null_Check"))
        Length_Check = json.loads(parser.get(src, "Length_Check"))
        DateFormat_Check = json.loads(parser.get(src, "DateFormat_Check"))
        InList_Check =  json.loads(parser.get(src, "InList_Check"))
        InRange_Check = json.loads(parser.get(src, "InRange_Check"))
        Regex_Check = json.loads(parser.get(src, "Regex_Check"))
        
        
        filteror = ' '
        if (len(Null_Check) > 0):
            updated_list = [s + "_CheckNull" + " = 'true' or " for s in Null_Check]
        
            filteror2 =' '.join([str(item) for item in updated_list])
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        if (len(Length_Check) > 0):
            updated_list = {f"{k}_CheckLength = 'true' or " for k in Length_Check}
        
        
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        if (len(DateFormat_Check) > 0):
            updated_list = {f"{k}_CheckDateFormat = 'true' or " for k in DateFormat_Check}
        
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        if (len(Regex_Check) > 0):
            updated_list = {f"{k}_CheckRegex = 'true' or " for k in Regex_Check}
        
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
         
        if (len(InList_Check) > 0):
            updated_list = {k + "_CheckInList" + " = 'true' or " for k in InList_Check}
        
        
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        if (len(InRange_Check) > 0):
            updated_list = {f"{k}_CheckInRange = 'true' or " for k in InRange_Check}
        
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        
        def replace_right(source, target, replacement, replacements=None):
            return replacement.join(source.rsplit(target, replacements))
        
        filteror = replace_right(filteror, " or ", "", 1)
        
        filterand = filteror.replace(" or ", " and ").replace(" = 'true'", " is NULL")
        
        
        df.show()
        df_out = reduce(lambda df, column: df.withColumn(column + "_CheckNull", when(col(column).isNull(), lit("true"))), Null_Check, df)
        df_out.show()
        df_out1 = reduce(lambda df_out, key: df_out.withColumn(key + "_CheckLength",when(length(col(key)) > Length_Check[key], lit("true"))), Length_Check, df_out)
        df_out2 = reduce(lambda df_out1, key: df_out1.withColumn(key + "_CheckDateFormat",when(to_date(col(key),DateFormat_Check[key]).isNull(), lit("true"))), DateFormat_Check, df_out1)
        df_out3 = reduce(lambda df_out2, key: df_out2.withColumn(key + "_CheckInList",when(~col(key).isin(InList_Check[key]) |  col(key).isNull(), lit("true"))), InList_Check, df_out2)
        
        df_out4 = reduce(lambda df_out3, key: df_out3.withColumn(key + "_CheckRegex",when(~col(key).rlike(Regex_Check[key]), lit("true"))), Regex_Check, df_out3)
        df_final = reduce(lambda df_out4, key: df_out4.withColumn(key + "_CheckInRange",when((col(key).cast('int') < copy.deepcopy(InRange_Check)[key][0] ) |  (col(key).cast('int') > copy.deepcopy(InRange_Check)[key][1]) , lit("true"))), InRange_Check, df_out4)
        
        
        df_badrecords = df_final.filter(filteror)
        
        df_validated =  df_final.filter(filterand).select(df_final.columns[:len(df.columns)])
        
        print("Number of bad records :" ,df_badrecords.count())
                
        return df_validated, df_badrecords 
    except Exception as e:
        print("Error in Reading Source File")

# COMMAND ----------

def dataValidator(configfilePath, **kwargs) :
    
    from configparser import ConfigParser
    import json;
    from functools import reduce
    from pyspark.sql.types import IntegerType
    import copy
    from pyspark.sql.functions import col, lit
    from pyspark.sql import functions as f
    try:
        
        src = kwargs.get ('src_Initials', None)
        
        df = kwargs.get ('input_df', None)
        
        parser = ConfigParser()
        parser.read("/dbfs/FileStore/tables/Df_Valid_Config-10.txt")
        Null_Check = json.loads(parser.get(src, "Null_Check"))
        Length_Check = json.loads(parser.get(src, "Length_Check"))
        DateFormat_Check = json.loads(parser.get(src, "DateFormat_Check"))
        InList_Check =  json.loads(parser.get(src, "InList_Check"))
        InRange_Check = json.loads(parser.get(src, "InRange_Check"))
        
        updated_list = [s + "_CheckNull" + " = 'true' or " for s in Null_Check]
        
        if (len(updated_list) > 0):
            filteror=' '.join([str(item) for item in updated_list])
        
        updated_list = {f"{k}_CheckLength = 'true' or " for k in Length_Check}
        
        if (len(updated_list) > 0):
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        updated_list = {f"{k}_CheckDateFormat = 'true' or " for k in DateFormat_Check}
        if (len(updated_list) > 0):
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        updated_list = {k + "_CheckInList" + " = 'true' or " for k in InList_Check}
        if (len(updated_list) > 0):
        
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        updated_list = {f"{k}_CheckInRange = 'true' or " for k in InRange_Check}
        if (len(updated_list) > 0):
            filteror2 =' '.join({str(k) for k in updated_list})
            filteror3 = filteror + filteror2
            filteror = filteror3
        
        
        def replace_right(source, target, replacement, replacements=None):
            return replacement.join(source.rsplit(target, replacements))
        
        filteror = replace_right(filteror, " or ", "", 1)
        
        filterand = filteror.replace(" or ", " and ").replace(" = 'true'", " is NULL")
                
        df_out = reduce(lambda df, column: df.withColumn(column + "_CheckNull", when(col(column).isNull(), lit("true"))), Null_Check, df)
        df_out1 = reduce(lambda df_out, key: df_out.withColumn(key + "_CheckLength",when(length(col(key)) > Length_Check[key], lit("true"))), Length_Check, df_out)
        df_out2 = reduce(lambda df_out1, key: df_out1.withColumn(key + "_CheckDateFormat",when(to_date(col(key),DateFormat_Check[key]).isNull(), lit("true"))), DateFormat_Check, df_out1)
        df_out3 = reduce(lambda df_out2, key: df_out2.withColumn(key + "_CheckInList",when(~col(key).isin(InList_Check[key]) |  col(key).isNull(), lit("true"))), InList_Check, df_out2)
        df_final = reduce(lambda df_out3, key: df_out3.withColumn(key + "_CheckInRange",when((col(key).cast('int') < copy.deepcopy(InRange_Check)[key][0] ) |  (col(key).cast('int') > copy.deepcopy(InRange_Check)[key][1]) , lit("true"))), InRange_Check, df_out3)
        
        
        df_badrecords = df_final.filter(filteror)
        
        df_validated =  df_final.filter(filterand).select(df_final.columns[:len(df.columns)])
        
        print("Number of bad records :" ,df_badrecords.count())
                
        return df_validated, df_badrecords 
    except Exception as e:
        print("Error in Reading Source File")

# COMMAND ----------

#example for reading data with a tablename
df2 , errordf  = dataValidator ("/dbfs/FileStore/tables/Df_Valid_Config-19.txt", src_Initials= "DF1", input_df= df)
errordf.show()

df2.show()

# COMMAND ----------

from configparser import ConfigParser
from functools import reduce
from pyspark.sql.functions import col, lit
import ast;
import json
    
        
src = 'DF1'
        
print(src)
ini_parser = ConfigParser()
ini_parser.read("/dbfs/FileStore/tables/Df_Valid_Config-8.txt")
        
databasename =ini_parser.get(src,'databasename',fallback='')
print(databasename)
parser = ConfigParser()
parser.read("/dbfs/FileStore/tables/Df_Valid_Config-10.txt")
Null_Check_list = json.loads(parser.get(src, "Null_Check"))
print(Null_Check_list)
print(type(Null_Check_list))
Length_Check = json.loads(parser.get(src, "Length_Check"))
print(Length_Check)
print(type(Length_Check))

Length_Check = json.loads(parser.get(src, "InRange_Check"))
print(Length_Check)
print(type(Length_Check))

# COMMAND ----------

def dataValidator(configfilePath, **kwargs) :
    
    from configparser import ConfigParser
    from functools import reduce
    from pyspark.sql.functions import col, lit
    import json;
    try:
        
        src = kwargs.get ('src_Initials', None)
        
        print(src)
        ini_parser = ConfigParser()
        ini_parser.read(configfilePath)
        
        databasename =ini_parser.get(src,'databasename',fallback='')
        
        parser = ConfigParser()
        parser.read(configfilePath)

        Null_Check_list = parser.get(src, "Null_Check")
        Null_Check = json.loads(Null_Check_list)

        print(Null_Check)
        Null_Check =ini_parser.get(src,'Null_Check',fallback='')
        #Null_Check = Null_Check.split(',')
        print("Null_Check")
        print(Null_Check)
    
        
        Length_Check =ast.literal_eval(ini_parser.get(src,'Length_Check',fallback=''))
        
        
        
        print(databasename)
        updated_list = [s + "_CheckNull" + " = 'true' or " for s in Null_Check]

        filteror=' '.join([str(item) for item in updated_list])
        
        updated_list = [s[:-3] + "_CheckLength" +  " = 'true' or " for s in Length_Check]
        
        filteror=filteror.join([str(item) for item in updated_list])
        
        print(filteror)
        
        def replace_right(source, target, replacement, replacements=None):
            return replacement.join(source.rsplit(target, replacements))
        
        filteror = replace_right(filteror, " or ", "", 1)
        print("filteror")
        filterand = filteror.replace(" or ", " and ").replace(" = 'true'", " is NULL")
        print(filterand)
        #reduce(lambda df, col: df.withColumn(col, lit('true')), updated_list, df).show()
        df.show()
        df_out = reduce(lambda df, column: df.withColumn(column + "_CheckNull", when(col(column).isNull(), lit("true"))), Null_Check, df)
        
        df_final = reduce(lambda df_out, column: df_out.withColumn(column[:-3] + "_CheckLength",when(length(col(column[:-3])) > column[-2:], lit("true"))), Length_Check, df_out)
        
        #df_final2 = reduce(lambda column, lengt: df_out.withColumn(column[:] + "_CheckLength", lit("true")), Null_Check, Length)
        
        
        print(df_final2)
        df_final.show()
        
        df_badrecords = df_final.filter(filteror)
        
        df_validated =  df_final.filter(filterand).select(df_final.columns[:len(df.columns)])
        
        df_badrecords.show()
        df_validated.show()


        return df_badrecords 
    except Exception as e:
        print("Error in Reading Source File")
  
    

# COMMAND ----------

#example for reading data with a tablename
df , errordf  = dataValidator ("/dbfs/FileStore/tables/Df_Valid_Config-10.txt", src_Initials= "DF1" )
errordf.show()

# COMMAND ----------

        from configparser import ConfigParser
        from functools import reduce
        from pyspark.sql.functions import col, lit
        import ast;
        import json
    
        
        src = 'DF1'
        
        print(src)
        ini_parser = ConfigParser()
        ini_parser.read("/dbfs/FileStore/tables/Df_Valid_Config-7.txt")
        
        databasename =ini_parser.get(src,'databasename',fallback='')
        print(databasename)
        parser = ConfigParser()
        parser.read("/dbfs/FileStore/tables/Df_Valid_Config-7.txt")

        Null_Check_list = parser.get(src, "Null_Check")
        print(type(Null_Check_list))
        list_1 = list(Null_Check_list.strip(","))
        print(list_1)
        Null_Check = json.loads(Null_Check_list)

        print(Null_Check)
        Null_Check =ini_parser.get(src,'Null_Check',fallback='')
        #Null_Check = Null_Check.split(',')
        print("Null_Check")
        print(Null_Check)
    
        
        Length_Check =ast.literal_eval(ini_parser.get(src,'Length_Check',fallback=''))
        
        
        
        print(databasename)
        updated_list = [s + "_CheckNull" + " = 'true' or " for s in Null_Check]

        filteror=' '.join([str(item) for item in updated_list])
        
        updated_list = [s[:-3] + "_CheckLength" +  " = 'true' or " for s in Length_Check]
        
        filteror=filteror.join([str(item) for item in updated_list])
        
        print(filteror)
        
        def replace_right(source, target, replacement, replacements=None):
            return replacement.join(source.rsplit(target, replacements))
        
        filteror = replace_right(filteror, " or ", "", 1)
        print("filteror")
        filterand = filteror.replace(" or ", " and ").replace(" = 'true'", " is NULL")
        print(filterand)
        #reduce(lambda df, col: df.withColumn(col, lit('true')), updated_list, df).show()
        df.show()
        df_out = reduce(lambda df, column: df.withColumn(column + "_CheckNull", when(col(column).isNull(), lit("true"))), Null_Check, df)
        
        df_final = reduce(lambda df_out, column: df_out.withColumn(column[:-3] + "_CheckLength",when(length(col(column[:-3])) > column[-2:], lit("true"))), Length_Check, df_out)
        
        #df_final2 = reduce(lambda column, lengt: df_out.withColumn(column[:] + "_CheckLength", lit("true")), Null_Check, Length)
        
        
        print(df_final2)
        df_final.show()
        
        df_badrecords = df_final.filter(filteror)
        
        df_validated =  df_final.filter(filterand).select(df_final.columns[:len(df.columns)])
        
        df_badrecords.show()
        df_validated.show()

# COMMAND ----------

from pyspark.sql.functions import *

# Creating dataframe
df= spark.read.csv("/FileStore/tables/Data_Validation_File.csv",header = "true", inferSchema ="false")

#Add the death year column

df.show()


df.write.format("orc").save("/FileStore/tables/ORC_File_Test2")
df.write.format("avro").save("/FileStore/tables/AVRO_File_Test2")

df_orc= spark.read.orc("/FileStore/tables/ORC_File_Test2")
#df_avro= spark.read.avro("/FileStore/tables/AVRO_File_Test")
df_avro=spark.read.format("com.databricks.spark.avro").option("header","true").load("/FileStore/tables/AVRO_File_Test2")
df_orc.show()
df_avro.show()

# COMMAND ----------

import copy
from pyspark.sql import functions as f
li=["Mohit","Rohit"]

df.filter(df.Name.isin(li)).show()

checkInList = {'Name': ['Mohit', 'Rohit'], 'Luis': [184, 80], 'Andrea': [168, 57]}
print(copy.deepcopy(checkInList)['Name'][0])
print(copy.deepcopy(checkInList)['Name'][0])
li = checkInList['Name']

print(type(li))
df.withColumn("badRecord", when(~df.Name.isin(li) |  df.Name.isNull(),lit("true"))).show()
# # create a deep copy
# students_weights_2 = copy.deepcopy(students_weights)

# # modify the height of luis in the shallow copy 
# print(copy.deepcopy(students_weights)['Luis'][0])
# print(students_weights_2['Luis'][0])
# print(students_weights['Marco'])

#df.withColumn("CheckNameIsNULL", when(df.Name.isin(li) == False, lit("true"))).show()
#df.withColumn("CheckNameIsNULL", when(~df.Name.isin(li) |  df.Name.isNull(), lit("true"))).show()
#df.withColumn("EMPIDCHECK", when(df.DepID < 20 &  df.DepID > 1, lit("true"))).show()

#df.withColumn("badRecord", when(to_date(df.Name,"dd/MM/yyyy").isNull(),lit("true"))).show()
#df.withColumn("badRecord", f.when(f.to_date(f.col("Name"),"dd/MM/yyyy").isNotNull, False).otherwise(True)).show()

# COMMAND ----------

# Filtering Bad Data from a DF when a field is null or the length of a field exceeds




dfout =df.withColumn("CheckNameIsNULL", when(df.Name.isNull(), lit("true"))).withColumn("CheckNameLengthExceeds",when(length(df.Name) > 10 ,lit("true")))


text = 'df.withColumn("CheckNameIsNULL", when(df.Name.isNull(), lit("true"))).withColumn("CheckNameLengthExceeds",when(length(df.Name) > 10 ,lit("true")))'

#dfout  = df.text

df_badrecords = dfout.filter("CheckNameIsNULL = 'true' or CheckNameLengthExceeds = 'true'")

df_validated =  dfout.filter("CheckNameIsNULL is NULL  and  CheckNameLengthExceeds is NULL").select(dfout.columns[:len(df.columns)])

df.show()
df_badrecords.show()
df_validated.show()

# COMMAND ----------

from functools import reduce
from pyspark.sql.types import IntegerType
import copy
from pyspark.sql.functions import col, lit
from pyspark.sql import functions as f
Null_Check = ['Name', 'EmpID']
Length_Check = {'Name': 10, 'EmpID': 3}
DateFormat_Check = {'Name': 'dd/MM/yyyy', 'EmpID': 'dd/MM/yyyy'}
InList_Check =  {'Name': ['Mohit', 'Rohit']}
InRange_Check = {'EmpID': [102, 103]}

# filterdic=' '.join({f'{k}@d1': v for k, v in DateFormat_Check.items()})
# print(filterdic)
#df.Name.isNull()
updated_list = [s + "_CheckNull" + " = 'true' or " for s in Null_Check]
#print(copy.deepcopy(InRange_Check)['EmpID'][0])
if (len(updated_list) > 0):
    filteror=' '.join([str(item) for item in updated_list])

updated_list = {f"{k}_CheckLength = 'true' or " for k in Length_Check}

if (len(updated_list) > 0):
    filteror2 =' '.join({str(k) for k in updated_list})
    filteror3 = filteror + filteror2
    filteror = filteror3

updated_list = {f"{k}_CheckDateFormat = 'true' or " for k in DateFormat_Check}
if (len(updated_list) > 0):
    filteror2 =' '.join({str(k) for k in updated_list})
    filteror3 = filteror + filteror2
    filteror = filteror3

updated_list = {k + "_CheckInList" + " = 'true' or " for k in InList_Check}
if (len(updated_list) > 0):

    filteror2 =' '.join({str(k) for k in updated_list})
    filteror3 = filteror + filteror2
    filteror = filteror3

updated_list = {f"{k}_CheckInRange = 'true' or " for k in InRange_Check}
if (len(updated_list) > 0):
    filteror2 =' '.join({str(k) for k in updated_list})
    filteror3 = filteror + filteror2
    filteror = filteror3


def replace_right(source, target, replacement, replacements=None):
    return replacement.join(source.rsplit(target, replacements))

filteror = replace_right(filteror, " or ", "", 1)
print(filteror,"bsssssssssss")  
filterand = filteror.replace(" or ", " and ").replace(" = 'true'", " is NULL")
print(filterand,"yssss")
#reduce(lambda df, col: df.withColumn(col, lit('true')), updated_list, df).show()

df_out = reduce(lambda df, column: df.withColumn(column + "_CheckNull", when(col(column).isNull(), lit("true"))), Null_Check, df)

#df_final = reduce(lambda df_out, column: df_out.withColumn(column[:-3] + "_CheckLength",when(length(col(column[:-3])) > column[-2:], lit("true"))), Length_Check, df_out)

df_out1 = reduce(lambda df_out, key: df_out.withColumn(key + "_CheckLength",when(length(col(key)) > Length_Check[key], lit("true"))), Length_Check, df_out)
df_out2 = reduce(lambda df_out1, key: df_out1.withColumn(key + "_CheckDateFormat",when(to_date(col(key),DateFormat_Check[key]).isNull(), lit("true"))), DateFormat_Check, df_out1)
df_out3 = reduce(lambda df_out2, key: df_out2.withColumn(key + "_CheckInList",when(~col(key).isin(InList_Check[key]) |  col(key).isNull(), lit("true"))), InList_Check, df_out2)
df_final = reduce(lambda df_out3, key: df_out3.withColumn(key + "_CheckInRange",when((col(key).cast('int') < copy.deepcopy(InRange_Check)[key][0] ) |  (col(key).cast('int') > copy.deepcopy(InRange_Check)[key][1]) , lit("true"))), InRange_Check, df_out3)

# df_out4 = reduce(lambda df_out3, key: df_out.withColumn(key + "_CheckInRange",when(col(key).cast('int') >= copy.deepcopy(InRange_Check)[key][0] &  col(key).cast('int') <= copy.deepcopy(InRange_Check)[key][1], lit("true"))), InRange_Check, df_out3)
#df_out4.show()

#df.withColumn("CheckNameIsNULL", when(~df.Name.isin(li) |  df.Name.isNull(), lit("true"))).show()
#df.withColumn("EMPIDCHECK", when(df.DepID < 20 &  df.DepID > 1, lit("true"))).show()
df_badrecords = df_final.filter(filteror)

df_validated =  df_final.filter(filterand).select(df_final.columns[:len(df.columns)])

print("Number of bad records :" ,df_badrecords.count())
print("Invalid DF records:")
df_badrecords.show()
print("Validated DF records:")
df_validated.show()

# COMMAND ----------

import copy

# dictionary with students heights and weights
students_weights = {'Marco': (173, 70), 'Luis': [184, 80], 'Andrea': [168, 57]}

# create a deep copy
students_weights_2 = copy.deepcopy(students_weights)

# modify the height of luis in the shallow copy 
print(copy.deepcopy(students_weights)['Luis'][0])
print(students_weights_2['Luis'][0])
print(students_weights['Marco'])
myList=['One_20', 'Two_30', 'Three_40', 'Four_05', 'Five_06']
#print map(lambda i:i[:-2],x)  #for python 2.7
myList=['EmpID', ['1','2','3'], 'Name', ['Mohit','Rohit']]

print(myList[1::2])  # prints from beginning to end index
print(myList[0::2]) 
# print(myList[2:])  # prints from start index to end of list
# print(myList[2:4]) # prints from start index to end index
# print(myList[:])   # prints from beginning to end of list

#list(map(str.upper, myList))

#list(map(lambda i:i[-2:],myList) )



# COMMAND ----------

>>> l = ['One', 'Two', 'Three', 'Four', 'Five'] 
>>> [i[:-2] for i in l]
['O', 'T', 'Thr', 'Fo', 'Fi']

# COMMAND ----------

variable = 'deathIncrease_new'
df.withColumn(variable, when(df.deathIncrease == 0, df.death)
                                 .when(df.deathIncrease.isNull() ,df.death)
                                 .otherwise(df.deathIncrease)).show()

# COMMAND ----------

df_year = df.withColumn("year",df.date.substr(-4,4)).withColumn("Dummy_len_column", lit(1)).withColumn("StateSecondChar",col("state").substr(instr(col("state"),'H'),col("Dummy_len_column")))
df_year.show()

# COMMAND ----------

def readDatabaseSourceIni(configfilePath, **kwargs) :
    
    cfrom configparser import ConfigParser;   
    try:
        src = kwargs.get ('src_Initials', None)
        tablename = kwargs.get ('tablename', None)
        query = kwargs.get ('query', None)
        
        ini_parser = ConfigParser()
        ini_parser.read(configfilePath)
    
        databaseName =ini_parser.get(src,'databasename',fallback='')
        userName =ini_parser.get(src,'user',fallback='')
        password =ini_parser.get(src,'user',fallback='')
        databaseServer =ini_parser.get(src,'databaseserver',fallback='')
        databaseDriver =ini_parser.get(src,'driver',fallback='')
        pass_scope =ini_parser.get(src,'pass_scope',fallback='')
        pass_key =ini_parser.get(src,'pass_key',fallback='')
            
        
        if ((len(pass_key) > 0) and ( len(pass_scope) > 0)):
            
            password = dbutils.secrets.get(scope = pass_scope, key = pass_key)
        
        
        jdbcurl = f"jdbc:sqlserver://{databaseServer}:1433;databaseName={databaseName}"
    
        if tablename is not None:
            jdbcDF = spark.read.format("jdbc") \
                       .option("url", jdbcurl) \
                   .option("dbtable", tablename) \
                   .option("user", userName) \
                   .option("password", password) \
                   .option("driver", databaseDriver) \
                   .load()
            return jdbcDF
        else :
            jdbcDF = spark.read.format("jdbc") \
                   .option("url", jdbcurl) \
                   .option("query", query) \
                   .option("user", userName) \
                   .option("password", password) \
                   .option("driver", databaseDriver) \
                   .load()
            return jdbcDF
    except Exception as e:
         print("Error in Reading Source data")
        


# COMMAND ----------

#example for reading data with a tablename
databaseable = readDatabaseSourceIni ("/dbfs/FileStore/tables/Config_DB_Param.txt", tablename= "Demo_Connectivity", src_Initials= "Src1" )
databaseable.show()

# COMMAND ----------

#example for reading data with a query
databaseable_query = readDatabaseSourceIni ("/dbfs/FileStore/tables/Config_DB_Param.txt",query= "Select d.* from demo_connectivity d inner join demo_connectivity b on d.id = b.id  where d.id=1", src_Initials= "Src1" )
databaseable_query.show()