# Databricks notebook source
# MAGIC %md
# MAGIC Description : function[readDatabaseSourceIni] is responsible to fetch data from SQL database Table/Query.
# MAGIC InPut Parameters :
# MAGIC       configfilePath: Path for reading the configuration/ini file to read variables. 
# MAGIC       **kwargs: config file level parameters : delimiter, header
# MAGIC                 Database Level Parameters : 
# MAGIC                                src_Initials: it will be section (Src1, Src2 etc) of your database level variable names in config/ini file, it will help us in case when we have                                                    multiple sources in a config/ini file.The function will connect the same database automatically. 
# MAGIC                                tablename:     it will accept the database table name rom where you need to populate the data.
# MAGIC                                query    :     in case you need to get data with a SQL query, you can pass the same in this parameter. it will work for joins, fileration also.
# MAGIC                          NOTE : funtion will accept one value out of tablename/query at a time. so in function call wither you can pass tablename or query. 
# MAGIC Sample ini/config file(CSV):        
# MAGIC [Src2]
# MAGIC property = value
# MAGIC databasename = dbdna02
# MAGIC table = Demo_Connectivity
# MAGIC user = admindna01
# MAGIC password = 
# MAGIC databaseserver = dbserverdna01.database.windows.net
# MAGIC driver = com.microsoft.sqlserver.jdbc.SQLServerDriver
# MAGIC pass_scope = scope_adb_2
# MAGIC pass_key = dbdna01-properties
# MAGIC [Src1]
# MAGIC databasename = dbdna01
# MAGIC table = Demo_Connectivity
# MAGIC user = admindna01
# MAGIC password = admindna@01
# MAGIC databaseserver = dbserverdna01.database.windows.net
# MAGIC driver = com.microsoft.sqlserver.jdbc.SQLServerDriver
# MAGIC pass_scope = scope_adb_2
# MAGIC pass_key = dbdna01-properties
# MAGIC 
# MAGIC       function is developed to accept above mentioned property names for now, if any one changes there names in config file then there will be a need to update the function           accordingly.

# COMMAND ----------

def readDatabaseSourceIni(configfilePath, **kwargs) :
    
    from configparser import ConfigParser;   
    try:
        src = kwargs.get ('src_Initials', None)
        tablename = kwargs.get ('tablename', None)
        query = kwargs.get ('query', None)
        
        ini_parser = ConfigParser()
        ini_parser.read(configfilePath)
    
        databaseName =ini_parser.get(src,'databasename',fallback='')
        userName =ini_parser.get(src,'user',fallback='')
        password =ini_parser.get(src,'user',fallback='')
        databaseServer =ini_parser.get(src,'databaseserver',fallback='')
        databaseDriver =ini_parser.get(src,'driver',fallback='')
        pass_scope =ini_parser.get(src,'pass_scope',fallback='')
        pass_key =ini_parser.get(src,'pass_key',fallback='')
            
        
        if ((len(pass_key) > 0) and ( len(pass_scope) > 0)):
            
            password = dbutils.secrets.get(scope = pass_scope, key = pass_key)
        
        
        jdbcurl = f"jdbc:sqlserver://{databaseServer}:1433;databaseName={databaseName}"
    
        if tablename is not None:
            jdbcDF = spark.read.format("jdbc") \
                       .option("url", jdbcurl) \
                   .option("dbtable", tablename) \
                   .option("user", userName) \
                   .option("password", password) \
                   .option("driver", databaseDriver) \
                   .load()
            return jdbcDF
        else :
            jdbcDF = spark.read.format("jdbc") \
                   .option("url", jdbcurl) \
                   .option("query", query) \
                   .option("user", userName) \
                   .option("password", password) \
                   .option("driver", databaseDriver) \
                   .load()
            return jdbcDF
    except Exception as e:
         print("Error in Reading Source data")
        


# COMMAND ----------

#example for reading data with a tablename
databaseable = readDatabaseSourceIni ("/dbfs/FileStore/tables/Config_DB_Param.txt", tablename= "Demo_Connectivity", src_Initials= "Src1" )
databaseable.show()

# COMMAND ----------

#example for reading data with a query
databaseable_query = readDatabaseSourceIni ("/dbfs/FileStore/tables/Config_DB_Param.txt",query= "Select d.* from demo_connectivity d inner join demo_connectivity b on d.id = b.id  where d.id=1", src_Initials= "Src1" )
databaseable_query.show()