# Databricks notebook source
def readSourceFile(filePath,format, **kwargs) :
    
    schema = kwargs.get('schema', None)
    badRecordsPath = kwargs.get ('badRecordsPath', None)
    delimiter = kwargs.get ('delimiter', None)
    pathGlobFilter = kwargs.get ('pathGlobFilter', None)
    header = kwargs.get ('header', None)
    badRecordsPath = kwargs.get ('badRecordsPath', None)
    multiline = kwargs.get ('multiline', None)
    print(multiline)
    try:
        df_file_read = spark.read.load(filePath, format=format, schema=schema, delimiter=delimiter, header=header, badRecordsPath=badRecordsPath )
        return df_file_read
        
    except Exception as e:
        print("Error in Reading Source File")

# COMMAND ----------

   import shutil
    import re;

    with open(outputfile,'wb') as fdst:
        for subdir,dirs,files in os.walk(sourcepath):
            for file in files:
                filename=sourcepath+file
                pattern_txt = re.compile(r''+regex_txt+'')
                if pattern_txt.match(filename):

# COMMAND ----------

def unzip_files(zipFilePath, zipFilePattern, **kwargs) :
    
    try:
        import os
        import shutil
        import zipfile
        import re
        import datetime
        import glob 
        from pyspark.sql.types import StructType
        
        #extract All file or Pattern
        extractFile = kwargs.get ('extractFile', 'All')
        extractDir = kwargs.get ('extractDir', '/dbfs/FileStore/tables/UNZIPFOLDER/')
        #output as DF or unzipped filename list
        dfOutput = kwargs.get ('dfOutput', 'N')
        
        filenameregex = kwargs.get ('filenameregex', '*')
            
        my_dir = zipFilePath
        #my_zip = r"/dbfs/FileStore/tables/ZIP_FILE_TEST3.zip"
        my_zip = zipFilePath+zipFilePattern
        
        files_at_path= [zipFilePath+fd for fd in os.listdir(zipFilePath)]
          
        #print(files_at_path)
                
        #extension = ".zip"
    
        #os.chdir(zipFilePath) 
        cntr = 0
        for item in files_at_path: 
            #if item.endswith(extension):
            items = os.path.basename(item)
            zippattern_file =r''+zipFilePattern+''
            if re.match(zippattern_file, items):
                
                dt = datetime.datetime.now().isoformat()
                xdt = dt.replace(":", "-")
                #print(item)
    
        #filenameregex = 'POP2*.csv'
        
        
        
                
                with zipfile.ZipFile(item) as zip_file:
                
                    for member in zip_file.namelist():
                        
                        #print(member)
                        if extractFile == "All" :
                            zip_file.extractall(extractDir)
                            #print (extractFile)
                            if dfOutput == "Y" :
                                extractDirDBFS = extractDir.replace('/dbfs','')
                                fullfilepath = extractDirDBFS+filenameregex
                                outputDF = spark.read.csv(fullfilepath)
                                return outputDF
                            else :
                                
                                #print (extractDir)
                                fullfilepath = extractDir+filenameregex
                                #print(fullfilepath)
                                outputList = glob.glob(fullfilepath)
                                return outputList
                        else:        
                            #print("here it has reached1")
                            filename = os.path.basename(member)
                            # skip directories
                            if not filename:
                                continue
                        
                            # copy file (taken from zipfile's extract)
                            #pattern_file = re.compile(r''+filenameregex+'')
                            pattern_file =r''+filenameregex+''
                            #subfiles = os.path.basename(member)
                            #print(pattern_file)
                            if re.match(pattern_file,filename):
                                source = zip_file.open(member)
                                
                                uniquefname = member.replace("/", "-").replace(".","-")
                                tfname = "fileoutzipout"+uniquefname+xdt
                                
                                
                                target = open(os.path.join(extractDir, tfname), "wb")
                                
                                with source, target:
                                    shutil.copyfileobj(source, target)
                                    
                                    extractDirDBFS = extractDir.replace('/dbfs','')
                                    filepath = extractDirDBFS+tfname
                                    filepathList = extractDir+tfname
                                tempdf = spark.read.csv(filepath, sep=",")
                                
                                if (cntr == 0 ):
                                    outputDF = tempdf
                                    
                                    outputList = []
                                    outputList.append(filepathList)
                                    #print(outputList)
                                    
                                else :
                                    outputDF = outputDF.union(tempdf)
                                    
                                    outputList.append(filepathList)
                                    print(outputList)
                                    
                                cntr = cntr + 1
                            
                if (cntr == 0 ):
                    if dfOutput == "Y" :
                        outputDF = spark.createDataFrame([], StructType([]))
                        return outputDF
                    else :
                        outputList = []
                        return outputList
                else :
                    if dfOutput == "Y" :
                        
                        return outputDF
                    else :
                        
                        return outputList
                    
                    
                
    except Exception as e:
         print("Error in Unzipping File")

# COMMAND ----------

outlist = unzip_files("/dbfs/FileStore/tables/", "ZIP_FILE_TEST3_\d{1,3}.zip$" , dfOutput = "Y", extractFile="Spcl" , filenameregex= "POP2.*csv", extractDir="/dbfs/FileStore/tables/UNZIPFOLDER/") 

print(outlist)

#print(glob.glob("/dbfs/FileStore/tables/UNZIPFOLDER/*"))

outlist.show()

# COMMAND ----------

df_file_read = spark.read.load("/FileStore/tables/POP2_csv.gz", format="csv" ,delimiter=",")

df_file_read.show()

# COMMAND ----------

# Pushing a csv file 
df1 = readSourceFile ("/FileStore/tables/POP2_csv.gz", format="csv" ,delimiter="," )

df1.show()

# COMMAND ----------

import os
import zipfile
import re
import glob

filenameregex = 'POP2*.csv'

#tempdf.unpersist() 

with zipfile.ZipFile('/dbfs/FileStore/tables/ZIP_FILE_TEST.zip', mode='r') as zipf:
    for subfile in zipf.namelist():
        zipf.extractall('/dbfs/FileStore/tables/')
        print(subfile)
"/home/adam/*.txt"
#tempdf2 = spark.read.csv('/FileStore/tables/POP2.csv')
outlist = glob.glob("/dbfs/FileStore/tables/POP*.csv")
print (outlist)
#tempdf2.show()

# COMMAND ----------

import zipfile
def un_zipFiles(path):
    files=os.listdir(path)
    for file in files:
        if file.endswith('.zip'):
            filePath=path+'/'+file
            zip_file = zipfile.ZipFile(filePath)
            for names in zip_file.namelist():
                zip_file.extract(names,path)
            zip_file.close()

# COMMAND ----------

# MAGIC %fs ls dbfs:/FileStore/tables/ZIP_*

# COMMAND ----------

import os
import zipfile
import re
import datetime

dt = datetime.datetime.now()  
print ("Current date and time is = %s" % dt)  
print ("Date and time in ISO Format = %s" % dt.isoformat())  
filenameregex = 'POP2*.csv'

#tempdf.unpersist() 

with zipfile.ZipFile('/dbfs/FileStore/tables/ZIP_FILE_TEST2.zip', mode='r') as zipf:
    for subfile in zipf.namelist():
        #print(subfile)
        filename = os.path.basename(subfile)
        # skip directories
        if not filename:
            continue
            
        subfiles = os.path.basename(subfile)
        #print("subfiles" ,subfiles)
        #pattern_file = re.compile(r''+filenameregex+'')
        pattern_file =r''+filenameregex+''
        #print(pattern_file)
        if re.match(pattern_file, subfiles):
            #pathzip = '/dbfs/FileStore/tables/ZIP_FILE' + subfiles
            zipf.extract(subfile,'/dbfs/FileStore/tables/ZIP_FILE2221')
            print(subfile)
        tempdf = spark.read.csv('/FileStore/tables/ZIP_FILE2221/', sep=",")
        #df = df.union(tempdf) 

tempdf.show()
#out_df_parquet_qualified_files= spark.sparkContext.emptyRDD();

# COMMAND ----------

import os
import shutil
import zipfile
import re
import datetime
from pyspark.sql.types import StructType

my_dir = r"/dbfs/FileStore/tables"
my_zip = r"/dbfs/FileStore/tables/ZIP_FILE_TEST3.zip"

dt = datetime.datetime.now().isoformat()
xdt = dt.replace(":", "-")

filenameregex = 'POP2*.csv'
#out_df = spark.sparkContext.emptyRDD().toDF();
#out_df = spark.createDataFrame([], StructType([]))
cntr = 0
with zipfile.ZipFile(my_zip) as zip_file:
    for member in zip_file.namelist():
        print(member)
        filename = os.path.basename(member)
        # skip directories
        if not filename:
            continue
    
        # copy file (taken from zipfile's extract)
        pattern_file =r''+filenameregex+''
        #subfiles = os.path.basename(member)
        #print(pattern_file)
        if re.match(pattern_file, filename):
            source = zip_file.open(member)
            uniquefname = member.replace("/", "-").replace(".","-")
            tfname = "fileoutzipout"+uniquefname+xdt
            
            print(tfname)
            print(my_dir)
            target = open(os.path.join(my_dir, tfname), "wb")
            print(filename)
            with source, target:
                shutil.copyfileobj(source, target)
                print((target)) 
                filepath="/FileStore/tables/"+tfname
            tempdf = spark.read.csv(filepath, sep=",")
            print(tempdf)
            if (cntr == 0 ):
                outdf = tempdf
            else :
                outdf = outdf.union(tempdf)
            cntr = cntr + 1

outdf.show()

# COMMAND ----------

# MAGIC %fs ls dbfs:/FileStore/tables/fileout2022-02-02T08-34-25.305448

# COMMAND ----------

import os, zipfile

dir_name = 'C:\\SomeDirectory'
extension = ".zip"

os.chdir(dir_name) # change directory from working dir to dir with files

for item in os.listdir(dir_name): # loop through items in dir
    if item.endswith(extension): # check for ".zip" extension
        file_name = os.path.abspath(item) # get full path of files
        zip_ref = zipfile.ZipFile(file_name) # create zipfile object
        zip_ref.extractall(dir_name) # extract file to dir
        zip_ref.close() # close file
        os.remove(file_name) # delete zipped file

# COMMAND ----------

import os
import re
import time
filepath = '/dbfs/FileStore/tables/TABTEST/Files'
flagext = '.txt'
filenameregex = '.*.csv$'
waittime = 60
retry = '2'
files_at_path= [filepath+"/"+fd for fd in os.listdir(filepath)]
pattern_file = re.compile(r''+filenameregex+'')
print(pattern_file)
files_at_path_regex_pattern = [s for s in files_at_path if pattern_file.match(s)]
print('###CSV REGEX OUT FILES#### \n',files_at_path_regex_pattern)
for file in files_at_path_regex_pattern:
        file_name = os.path.basename(file)
        flag_file_name = os.path.splitext(file)[0] + flagext
        print (flag_file_name)
        print(file_name)
        check_file = os.path.exists(flag_file_name)
        print(check_file)
        
        
        
files_at_path= [filepath+"/"+fd for fd in os.listdir(filepath)]
    pattern_file = re.compile(r''+filenameregex+'')
    #print(pattern_file)
    files_at_path_regex_pattern = [s for s in files_at_path if pattern_file.match(s)]
    print('#CSV FILES# \n',files_at_path_regex_pattern)

# COMMAND ----------

# Pushing a csv file 
df1 = readSourceFile ("/FileStore/tables/TABTEST/DATA_*.csv", "csv" ,delimiter="," )

df1.show()