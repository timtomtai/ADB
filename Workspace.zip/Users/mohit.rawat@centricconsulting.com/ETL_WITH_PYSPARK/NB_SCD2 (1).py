# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC SCD2 - With End Date as the indicator of the active record

# COMMAND ----------

from pyspark.sql.functions import coalesce
from pyspark.sql.types import StructType,StringType,TimestampType,DecimalType,IntegerType,StructField
column_names = "ColA|ColB|ColC"
mySchema = StructType([StructField(c, StringType()) for c in column_names.split("|")])
df = spark.createDataFrame(data=[], schema=mySchema)



df = df.withColumn('ColAB',col('ColA').cast(IntegerType()))

target_offset = df.groupby().max('ColAB').collect()[0][0]

if target_offset is None:
    target_offset = 0


print(offset)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Create the table
# MAGIC DROP TABLE PRODUCTS_SCD2;
# MAGIC CREATE TABLE PRODUCTS_SCD2 (PRODUCT_ID INT,PRODUCT_KEY STRING, PRODUCT_NAME STRING,PRODUCT_PRICE INT,PRODUCT_DESC STRING,ACTIVE_FLAG STRING,BUSINESS_EFFECTIVE_BEGIN_DATETIME TIMESTAMP, BUSINESS_EFFECTIVE_END_DATETIME TIMESTAMP
# MAGIC ,INSERTED_DATE TIMESTAMP, LASTMODIFIED TIMESTAMP ,CHANGE_HASH  STRING, SOURCE_SYSTEM_CODE STRING);

# COMMAND ----------

# MAGIC %sql
# MAGIC select count(*) from default.claim

# COMMAND ----------

# MAGIC %md
# MAGIC SCD2 Operational Scenarios Starts from here

# COMMAND ----------

from pyspark.sql.functions import md5
from pyspark.sql.functions import *
from pyspark.sql import functions as f
from datetime import datetime, timedelta

# COMMAND ----------

# Read the  source file - Start Date is a source effective date
updatesDF = spark.read.csv("/FileStore/tables/scd2/Product-2.csv", header = "true")

updatesDF.show()

# COMMAND ----------

from delta.tables import *
#read the delta Table
delta_table = DeltaTable.forPath(spark, '/user/hive/warehouse/products_scd2')



# COMMAND ----------

delta_table = self.read_delta_table(self.spark, self.deltalake_path)

# COMMAND ----------

target = delta_table.toDF().alias("products").where("ACTIVE_FLAG = 'Y' ")

# COMMAND ----------


odays_df = updatesDF


# COMMAND ----------


colu =['PRODUCT_NAME','PRODUCT_PRICE','PRODUCT_DESC']

srg_col_name = 'PRODUCT_ID'
key_col = ['PRODUCT_KEY']
srg_col = [srg_col_name]
scd_col = ['ACTIVE_FLAG','BUSINESS_EFFECTIVE_BEGIN_DATETIME','BUSINESS_EFFECTIVE_END_DATETIME','INSERTED_DATE','LASTMODIFIED']
add_col = key_col + scd_col

#in_col = ['ABC','PRODUCT_ID']
in_col = updatesDF.columns
print(in_col, add_col)
hsh_col = list(set(in_col) - set(add_col))
chg_col = ['CHANGE_HASH']
diff_col = key_col + chg_col
print(diff_col)
tar_col = key_col + hsh_col
#hsh_col = in_col - add_col
print(hsh_col)

#val newDf = df.selectExpr("concat(nvl(PRODUCT_ID, ''), nvl(PRODUCT_NAME, '')) as NEW_COLUMN")
condition_list = [f"nvl({_}, '')" for _ in hsh_col]
#updated_list = {f"{k}_CheckInRange = 'true' or " for k in InRange_Check}
        
filteror2 =','.join({str(k) for k in condition_list})
filteror2= 'concat('+filteror2+')'

#exptr = "concat(nvl(PRODUCT_ID, ''), nvl(PRODUCT_NAME, '')) "
new_column_1 = expr(filteror2)
    

todays_df = updatesDF.withColumn("CHANGE_HASH",md5(new_column_1))
                                                                                                   
#delta_table_df= target.withColumn("CHANGE_HASH",md5(new_column_1))

#display(delta_table_df)
display(todays_df)

# COMMAND ----------

delta_table_df= target
delta_table=delta_table
display(todays_df)
display(delta_table_df)

# COMMAND ----------

delta_table_df_new = delta_table_df.select(diff_col)
todays_df_new = todays_df.select(diff_col)
rows_to_be_made_active_df_new = todays_df_new.subtract(delta_table_df_new)
rows_to_be_update_df = delta_table_df_new.subtract(rows_to_be_made_active_df_new)
rows_to_be_insert_df= todays_df.subtract(delta_table_df.select(todays_df.columns))


# COMMAND ----------

rows_to_be_insert_df.show()
rows_to_be_update_df.show()
updates_df=rows_to_be_update_df

# COMMAND ----------

rows_to_be_insert_df.show()
df=rows_to_be_insert_df


todays_data_df = df.withColumn("BUSINESS_EFFECTIVE_BEGIN_DATETIME",f.to_timestamp(f.lit('2022-02-02'),'yyyy-MM-dd')) \
    .withColumn("BUSINESS_EFFECTIVE_END_DATETIME", f.lit(None).cast('Timestamp')) \
    .withColumn("INSERTED_DATE", f.to_timestamp(f.lit('2022-02-02'),'yyyy-MM-dd')) \
    .withColumn("LASTMODIFIED", f.to_timestamp(f.lit('2022-02-02'),'yyyy-MM-dd')) \
    .withColumn("ACTIVE_FLAG",f.lit('Y')) \
    .withColumn("PRODUCT_ID",f.lit(1)).select('PRODUCT_ID','PRODUCT_KEY','PRODUCT_NAME','PRODUCT_PRICE','PRODUCT_DESC','ACTIVE_FLAG','BUSINESS_EFFECTIVE_BEGIN_DATETIME','BUSINESS_EFFECTIVE_END_DATETIME','INSERTED_DATE','LASTMODIFIED','CHANGE_HASH','SOURCE_SYSTEM_CODE')

todays_data_df.show()
#'ACTIVE_FLAG','BUSINESS_EFFECTIVE_BEGIN_DATETIME','BUSINESS_EFFECTIVE_END_DATETIME','INSERTED_DATE','LASTMODIFIED'

# COMMAND ----------

def synch_columns_in_two_dataframe(self,df1,df2):
        schema1 = set(df1.schema)
        schema2 = set(df2.schema)
        
        for i in schema2.difference(schema1):
            df1 = df1.withColumn(i.name,f.lit(None).cast(i.dataType))
        for i in schema1.difference(schema2):
            df2 = df2.withColumn(i.name,f.lit(None).cast(i.dataType))

        df2 = df2.select(df1.columns)

        return df1, df2

# COMMAND ----------

def build_condition_string( primary_key_list):
    condition_list = [f'target.{_} = updates.{_}' for _ in primary_key_list]
    condition_list.append(f'target.CHANGE_HASH != updates.CHANGE_HASH')
    condition_list.append(f'target.ACTIVE_FLAG = "Y"')
    print(' and '.join(condition_list))
    return ' and '.join(condition_list)

# COMMAND ----------

END_DATE = "2022-03-16"
print(delta_table.toDF().count())
condition = build_condition_string(key_col)
#print(condition)
delta_table.alias("target").merge(updates_df.alias("updates"),condition = condition).whenMatchedUpdate(set = {"BUSINESS_EFFECTIVE_END_DATETIME": END_DATE, "ACTIVE_FLAG" :lit('N') }).execute()

# COMMAND ----------

df_with_surrKey = dfZipWithIndex(df_fetching_from_blob, offset = 1, colName = "Surrogate_key" )

# COMMAND ----------

delta_table.alias("target").merge(todays_data_df.alias("updates"),condition = "1=1").whenNotMatchedInsertAll().execute()

# COMMAND ----------

delta_table.alias("target").merge(updates_df.alias("updates"),condition = "target.PRODUCT_KEY = updates.PRODUCT_KEY").whenMatchedUpdate(condition ="target.CHANGE_HASH != updates.CHANGE_HASH and target.ACTIVE_FLAG = 'Y'",set = {"BUSINESS_EFFECTIVE_END_DATETIME": "2020-01-01" }).execute()

# COMMAND ----------

from pyspark.sql.types import LongType, StructField, StructType
def dfZipWithIndex (df, offset, colName = "rowId" ):
    # df - source dataframe
    # offset - Adjust to ZipWithIndex's Index
    # colName - name of the index column
    
    new_schema = StructType(
        [StructField(colName, LongType(),True)]  #new added field
        + df.schema.fields)                      #table fields
    
    zipped_rdd = df.rdd.zipWithIndex()
    
    new_rdd = zipped_rdd.map(lambda row: ([row[1]+offset] + list(row[0])))
    
    return spark.createDataFrame(new_rdd, new_schema)

# COMMAND ----------



# COMMAND ----------

delta_table.alias("target").merge(updates_df.alias("updates"),condition = condition).whenMatchedUpdate(set = {"BUSINESS_EFFECTIVE_END_DATETIME": "2020-01-01" }).execute()

# COMMAND ----------



# COMMAND ----------

primary_key_list=key_col
condition = build_condition_string(key_col)

print(condition)

# COMMAND ----------

# FInd the changed/updated records
stagedPart1 = updatesDF.alias("updates").join(PRODUCTS_SCD.toDF().alias("products"), "PRODUCT_ID").where("isnull(products.END_DATE) = true AND (updates.PRODUCT_NAME <> products.PRODUCT_NAME OR updates.PRODUCT_PRICE <> products.PRODUCT_PRICE OR  products.PRODUCT_DESC <> updates.PRODUCT_DESC )").selectExpr("NULL as mergeKey", "updates.*")
stagedPart1.show()

# COMMAND ----------

# FInd the new records
stagedPart2 = updatesDF.selectExpr("PRODUCT_ID as mergeKey", "*")
stagedPart2.show()

# COMMAND ----------

# FInd the deleted records
stagedPartDeleted = PRODUCTS_SCD.toDF().alias("products").join(updatesDF,"PRODUCT_ID","left_anti").selectExpr("'D' as mergeKey", "products.*").distinct()

stagedPartDeleted.show()

# COMMAND ----------

#Union both Chnaged and New Records
stagedUpdates = stagedPart1.union(stagedPart2)
stagedUpdates.show()

# COMMAND ----------

#Using Merge - Updated the existing record and insert new records
PRODUCTS_SCD.alias("products")\
    .merge(
        stagedUpdates.alias("staged_updates"),
        "products.PRODUCT_ID = mergeKey"
    )\
    .whenMatchedUpdate(
        condition = "isnull(products.END_DATE) = true AND (staged_updates.PRODUCT_NAME <> products.PRODUCT_NAME OR staged_updates.PRODUCT_PRICE <> products.PRODUCT_PRICE OR  products.PRODUCT_DESC <> staged_updates.PRODUCT_DESC )"
        ,set = 
            {
       
            "END_DATE" : "staged_updates.START_DATE" 
            }
    
    ).whenNotMatchedInsert(values =
        {
    
        "PRODUCT_ID" : "staged_updates.PRODUCT_ID",
        "PRODUCT_NAME" : "staged_updates.PRODUCT_NAME",
        "PRODUCT_PRICE" : "staged_updates.PRODUCT_PRICE",
        "PRODUCT_DESC" : "staged_updates.PRODUCT_DESC",
        "START_DATE" : "staged_updates.START_DATE",
        "END_DATE" : "null"
        }
    )\
      .execute()

# COMMAND ----------

#Using Merge - Updated the deleted records

from datetime import datetime, timedelta
from pyspark.sql.functions import *
yesterday = (datetime.now() - timedelta(1)).strftime('%Y-%m-%d')


PRODUCTS_SCD.alias("products")\
    .merge(
        stagedPartDeleted.alias("staged_deleted"),
        ("products.PRODUCT_ID = staged_deleted.PRODUCT_ID and staged_deleted.mergeKey = 'D'")
    )\
    .whenMatchedUpdate(
        condition = "isnull(products.END_DATE) = true"
        ,set = 
            {
       
            "END_DATE" : lit(yesterday)
            }
    
    ).execute()



# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC Select * from PRODUCTS_SCD