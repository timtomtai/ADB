# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC SCD2 - With End Date as the indicator of the active record

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Create the table
# MAGIC DROP TABLE PRODUCTS_SCD2;
# MAGIC CREATE TABLE PRODUCTS_SCD2 (PRODUCT_ID INT,PRODUCT_KEY STRING, PRODUCT_NAME STRING,PRODUCT_PRICE INT,PRODUCT_DESC STRING,ACTIVE_FLAG STRING,BUSINESS_EFFECTIVE_BEGIN_DATETIME TIMESTAMP, BUSINESS_EFFECTIVE_END_DATETIME TIMESTAMP
# MAGIC ,INSERTED_DATE TIMESTAMP, LASTMODIFIED TIMESTAMP ,CHANGE_HASH  STRING, SOURCE_SYSTEM_CODE STRING)
# MAGIC --LOCATION '/mnt/containershareddna03/dldemo/tables/table1';

# COMMAND ----------

df1.join(df2, on=[‘Roll_No’], how=’left’)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC Update PRODUCTS_SCD2 set ACTIVE_FLAG='Y'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from PRODUCTS_SCD2

# COMMAND ----------

from datetime import date
from datetime import datetime
dt = date.today()
print(datetime.combine(dt, datetime.min.time()))
yy=(datetime.combine(date.today(), datetime.min.time())-timedelta(minutes=0,seconds=1))
detey = f.lit(datetime.today() - timedelta(days=1,minutes=1))
             
#t = datetime.timedelta(hours=24, minutes=1)

print(yy)

# COMMAND ----------

# MAGIC %md
# MAGIC SCD2 Operational Scenarios Starts from here

# COMMAND ----------

from pyspark.sql.functions import md5,col
from pyspark.sql.functions import concat,expr,lit
from pyspark.sql import functions as f
from datetime import datetime, timedelta, date
from datetime import date
from delta import DeltaTable
import delta
from pyspark.sql.types import LongType, StructField, StructType

# COMMAND ----------

def build_condition_string( primary_key_list):
    condition_list = [f'target.{_} = updates.{_}' for _ in primary_key_list]
    condition_list.append(f'target.CHANGE_HASH = updates.CHANGE_HASH')
    condition_list.append(f'target.ACTIVE_FLAG = "Y"')
    print(' and '.join(condition_list))
    return ' and '.join(condition_list)

# COMMAND ----------

def synch_columns_in_two_dataframe(self,df1,df2):
        schema1 = set(df1.schema)
        schema2 = set(df2.schema)
        
        for i in schema2.difference(schema1):
            df1 = df1.withColumn(i.name,f.lit(None).cast(i.dataType))
        for i in schema1.difference(schema2):
            df2 = df2.withColumn(i.name,f.lit(None).cast(i.dataType))

        df2 = df2.select(df1.columns)

        return df1, df2

# COMMAND ----------

def dfZipWithIndex (df, offset, colName):
    # df - source dataframe
    # offset - Adjust to ZipWithIndex's Index
    # colName - name of the index column
    
    new_schema = StructType(
        [StructField(colName, LongType(),True)]  #new added field
        + df.schema.fields)                      #table fields
    
    zipped_rdd = df.rdd.zipWithIndex()
    
    new_rdd = zipped_rdd.map(lambda row: ([row[1]+offset] + list(row[0])))
    
    return spark.createDataFrame(new_rdd, new_schema)

# COMMAND ----------

# Read the  source file - Start Date is a source effective date
todays_df_in = spark.read.csv("/FileStore/tables/scd2/Product-2.csv", header = "true")

todays_df_in.show()

# COMMAND ----------


#Setting Initial List Varaiable
process_date = '2022-03-01'
srg_col_name = 'PRODUCT_ID'
key_col = ['PRODUCT_KEY']
srg_col = [srg_col_name]
scd_col = ['ACTIVE_FLAG','BUSINESS_EFFECTIVE_BEGIN_DATETIME','BUSINESS_EFFECTIVE_END_DATETIME','INSERTED_DATE','LASTMODIFIED']
add_col = key_col + scd_col
#in_col = ['ABC','PRODUCT_ID']
in_col = todays_df_in.columns
print(in_col, add_col)
hsh_col = list(set(in_col) - set(add_col))
chg_col = ['CHANGE_HASH']
diff_col = key_col + chg_col
print(diff_col)
tar_col = key_col + hsh_col
all_col = srg_col + key_col + chg_col + hsh_col +scd_col
#hsh_col = in_col - add_col
print(hsh_col)
print(all_col)


#Read the delta Table
delta_table = DeltaTable.forPath(spark, '/user/hive/warehouse/products_scd2')
#delta_table = self.read_delta_table(self.spark, self.deltalake_path)

#Take Active Records from delta table
target_active = delta_table.toDF().where("ACTIVE_FLAG = 'Y' ")
#todays_df_in=todays_df_in

#Finding offset
target_offset = target_active.groupby().max(srg_col_name).collect()[0][0]

if target_offset is None:
    target_offset = 1
else:
    target_offset = target_offset + 1
print(target_offset)
#Generate Dynamic Change Hash Colum for Input DF
#val newDf = df.selectExpr("concat(nvl(PRODUCT_ID, ''), nvl(PRODUCT_NAME, '')) as NEW_COLUMN")
changehash_list_in = [f"nvl({_}, '')" for _ in hsh_col]
changehash_list =','.join({str(k) for k in changehash_list_in})
changehash_list= 'concat('+changehash_list+')'

changehash = expr(changehash_list)
    
#Add  Change Hash Colum for Input DF
todays_df = todays_df_in.withColumn("CHANGE_HASH_IN",md5(changehash))

display(todays_df)
display(target_active )

# COMMAND ----------

#Finding the rows to Updated and Inserted
delta_table_df= target_active
all_col = srg_col + key_col + chg_col + hsh_col +scd_col
chg_col_in = ['CHANGE_HASH_IN']
diff_col_in = key_col + chg_col_in
delta_table_df_new = target_active.select(diff_col)
todays_df_new = todays_df.select(diff_col_in)
#rows_to_be_made_active_df_new = todays_df_new.subtract(delta_table_df_new)
#rows_to_be_update_df = delta_table_df_new.subtract(rows_to_be_made_active_df_new)
#rows_to_be_update_df = delta_table_df_new.subtract(todays_df_new)
rows_to_be_update_df= delta_table_df_new.join(todays_df_new, on=key_col, how='inner').select(diff_col_in).withColumnRenamed("CHANGE_HASH_IN","CHANGE_HASH")
todays_df = todays_df.withColumnRenamed("CHANGE_HASH_IN","CHANGE_HASH")
rows_to_be_insert_df= todays_df.subtract(delta_table_df.select(todays_df.columns))


# COMMAND ----------


col_list= ['PRODUCT_KEY','CHANGE_HASH_IN'] 
delta_table_df_new.join(todays_df_new, on=key_col, how='inner').select(col_list).show()

# COMMAND ----------

display(rows_to_be_made_active_df_new)
print(diff_col)
display(rows_to_be_update_df)
display(rows_to_be_insert_df)
display(todays_df_new)

# COMMAND ----------

#Adding New Columns 
#f.to_timestamp(f.lit('2022-02-02'),'yyyy-MM-dd'))
todays_data_df = rows_to_be_insert_df.withColumn("BUSINESS_EFFECTIVE_BEGIN_DATETIME",f.to_timestamp(f.lit(process_date),'yyyy-MM-dd')) \
    .withColumn("BUSINESS_EFFECTIVE_END_DATETIME", f.lit(None).cast('Timestamp')) \
    .withColumn("INSERTED_DATE", f.lit(datetime.now()) )\
    .withColumn("LASTMODIFIED", f.lit(datetime.now()) ) \
    .withColumn("ACTIVE_FLAG",f.lit('Y')) \



#todays_data_df=.select('PRODUCT_ID','PRODUCT_KEY','PRODUCT_NAME','PRODUCT_PRICE','PRODUCT_DESC','ACTIVE_FLAG','BUSINESS_EFFECTIVE_BEGIN_DATETIME','BUSINESS_EFFECTIVE_END_DATETIME','INSERTED_DATE','LASTMODIFIED','CHANGE_HASH','SOURCE_SYSTEM_CODE')

todays_data_df.show()

# COMMAND ----------

todays_data_df = dfZipWithIndex(todays_data_df,  target_offset, colName = srg_col_name ).select(all_col)

# COMMAND ----------

display(todays_data_df)

# COMMAND ----------

#Update Records in Traget table
END_DATE = f.lit(datetime.combine(date.today(), datetime.min.time())-timedelta(minutes=0,seconds=1))
#f.lit(datetime.now() f.lit(datetime.date.today() - datetime.timedelta(seconds=-1))--f.lit(datetime.now()- timedelta(1))
yesterday = (datetime.now() - timedelta(1)).strftime('%Y-%m-%d')
condition = build_condition_string(key_col)
#print(condition)
delta_table.alias("target").merge(rows_to_be_update_df.alias("updates"),condition = condition).whenMatchedUpdate(set = {"BUSINESS_EFFECTIVE_END_DATETIME":END_DATE , "ACTIVE_FLAG" :lit('N'), "LASTMODIFIED": f.lit(datetime.now()) }).execute()

# COMMAND ----------

#Insert Records in Traget table
delta_table.alias("target").merge(todays_data_df.alias("new_records"),condition = "1 != 1").whenNotMatchedInsertAll().execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from PRODUCTS_SCD2

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from PRODUCTS_SCD2

# COMMAND ----------

print(condition)
display(rows_to_be_update_df)
display(rows_to_be_insert_df)

# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------



# COMMAND ----------

