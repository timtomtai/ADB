# Databricks notebook source
df_initial = spark.read.csv("/FileStore/tables/Product-1.csv", header = "true")

df_initial.write.format("delta").mode("overwrite").saveAsTable("Products")


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Products

# COMMAND ----------

from delta.tables import *

deltaTableProducts = DeltaTable.forPath(spark, '/user/hive/warehouse/products')


dfUpdates = spark.read.csv("/FileStore/tables/Product-2.csv", header = "true")

#dfUpdates = deltaTablePeopleUpdates.toDF()

deltaTableProducts.alias('products') \
  .merge(
    dfUpdates.alias('updates'),
    'products.PRODUCT_ID = updates.PRODUCT_ID'
  ) \
  .whenMatchedUpdate(set =
    {
      "PRODUCT_ID": "updates.PRODUCT_ID",
      "PRODUCT_NAME": "updates.PRODUCT_NAME",
      "PRODUCT_PRICE": "updates.PRODUCT_PRICE",
      "PRODUCT_DESC": "updates.PRODUCT_DESC",
    }
  ) \
  .whenNotMatchedInsert(values =
    {
      "PRODUCT_ID": "updates.PRODUCT_ID",
      "PRODUCT_NAME": "updates.PRODUCT_NAME",
      "PRODUCT_PRICE": "updates.PRODUCT_PRICE",
      "PRODUCT_DESC": "updates.PRODUCT_DESC"
    }
  ) \
  .execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE PRODUCTS_SCD (PRODUCT_ID INT,PRODUCT_NAME STRING,PRODUCT_PRICE INT,PRODUCT_DESC STRING,START_DATE DATE, END_DATE DATE);

# COMMAND ----------

# MAGIC %md
# MAGIC SCD2 Scenarios Starts from here

# COMMAND ----------

updatesDF = spark.read.csv("/FileStore/tables/Product-5.csv", header = "true")

updatesDF.show()

# COMMAND ----------

from delta.tables import *

PRODUCTS_SCD = DeltaTable.forPath(spark, '/user/hive/warehouse/products_scd')


stagedPart1 = updatesDF.alias("updates").join(PRODUCTS_SCD.toDF().alias("products"), "PRODUCT_ID").where("isnull(products.END_DATE) = true AND (updates.PRODUCT_NAME <> products.PRODUCT_NAME OR updates.PRODUCT_PRICE <> products.PRODUCT_PRICE OR  products.PRODUCT_DESC <> updates.PRODUCT_DESC )").selectExpr("NULL as mergeKey", "updates.*")
stagedPart1.show()

# COMMAND ----------

stagedPart2 = updatesDF.selectExpr("PRODUCT_ID as mergeKey", "*")
stagedPart2.show()

# COMMAND ----------

stagedPartDeleted = PRODUCTS_SCD.toDF().alias("products").join(updatesDF,"PRODUCT_ID","left_anti").selectExpr("'D' as mergeKey", "products.*").distinct()

stagedPartDeleted.show()

# COMMAND ----------

stagedUpdates = stagedPart1.union(stagedPart2)
stagedUpdates.show()

# COMMAND ----------

PRODUCTS_SCD.alias("products")\
    .merge(
        stagedUpdates.alias("staged_updates"),
        "products.PRODUCT_ID = mergeKey"
    )\
    .whenMatchedUpdate(
        condition = "isnull(products.END_DATE) = true AND (staged_updates.PRODUCT_NAME <> products.PRODUCT_NAME OR staged_updates.PRODUCT_PRICE <> products.PRODUCT_PRICE OR  products.PRODUCT_DESC <> staged_updates.PRODUCT_DESC )"
        ,set = 
            {
       
            "END_DATE" : "staged_updates.START_DATE" 
            }
    
    ).whenNotMatchedInsert(values =
        {
    
        "PRODUCT_ID" : "staged_updates.PRODUCT_ID",
        "PRODUCT_NAME" : "staged_updates.PRODUCT_NAME",
        "PRODUCT_PRICE" : "staged_updates.PRODUCT_PRICE",
        "PRODUCT_DESC" : "staged_updates.PRODUCT_DESC",
        "START_DATE" : "staged_updates.START_DATE",
        "END_DATE" : "null"
        }
    )\
      .execute()

# COMMAND ----------

#from datetime import datetime, timedelta
#from pyspark.sql.functions import col,concat,lit,current_date
#declare the date olddate for mark as a invalid record.

#today = datetime.date.today()

from datetime import datetime, timedelta
from pyspark.sql.functions import *
yesterday = (datetime.now() - timedelta(1)).strftime('%Y-%m-%d')

# print(yesterday)                                                                                                                                                                                    
#datetime.datetime    

#datetime.strftime(yesterday, '%Y-%m-%d')

# yesterday = today - datetime.timedelta(days=1)



print(yesterday)
PRODUCTS_SCD.alias("products")\
    .merge(
        stagedPartDeleted.alias("staged_deleted"),
        ("products.PRODUCT_ID = staged_deleted.PRODUCT_ID and staged_deleted.mergeKey = 'D'")
    )\
    .whenMatchedUpdate(
        condition = "isnull(products.END_DATE) = true"
        ,set = 
            {
       
            "END_DATE" : lit(yesterday)
            }
    
    ).execute()



# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from PRODUCTS_SCD

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC delete from PRODUCTS_SCD

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from PRODUCTS_SCD

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from PRODUCTS_SCD

# COMMAND ----------

