# Databricks notebook source
# dataframe
df= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_join.csv",header = "true", inferSchema ="true")
df.show()

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.functions import col
import pyspark.sql.functions as F
from pyspark.sql.types import IntegerType
#Extract the death year column

df_year = df.withColumn("StateINSTR",col("state").substr(instr(col("state"),'H'),instr(col("state"),'H')))
df_year = df.withColumn("StateINSTR",col("state").substr(instr(col("state"),'H'),(length(col("state"))+1-length(col("state")))))
from pyspark.sql.functions import *
from pyspark.sql.functions import col
import pyspark.sql.functions as F
#Extract the death year column

#df_year = df.withColumn("year",df.date.substr(-4,4)).withColumn("Dummy_len_column", lit(1))withColumn("StateFirstChar",col("state").substr(instr(col("state"),'H'),(length(col("state"))+1-length(col("state")))))
df_year = df.withColumn("year",df.date.substr(-4,4)).withColumn("Dummy_len_column", lit(1)).withColumn("StateFirstChar",col("state").substr(instr(col("state"),'H'),col("Dummy_len_column")))
#df_year = df.withColumn("year",df.date.substr(-4,4))
# df_year = df.withColumn("year",substring('date',-4,4))
# df_year = df.withColumn('year',col('date' ).substr(-4,4))
# df_year = df.withColumn("StateINSTR",instr('state','H'))
# df_year = df.withColumn("StateINSTR",substring(df.state,instr(col("state"),'H'),1))
#df_year = df.withColumn("StateINSTR",df["state".locate('H',1))
#expr("add_months(date,increment)")
df_year.show()
#df.withColumn("Chargemonth", col("chargedate").substr(lit(1), instr(col("chargedate"), '01'))).show()
#F.when(F.col("Pclass").like("3"),"three").otherwise("notthree"))

# COMMAND ----------

with()

# COMMAND ----------

from pyspark.sql import functions as F

#Find the death details grouped per year & state using agg

df_year2 =df_year.groupBy("year","state").agg(F.max(df_year.death), F.max(df_year.deathIncrease))

df_year2.show()

# COMMAND ----------


#Find the max directly over mutliple columns

df_year2 =df_year.groupBy("year").max('death','deathIncrease')

df_year2.show()

# COMMAND ----------

#Pivot columns

df_year.groupBy("state").pivot("year", ["2021", "2020", "2019"]).max("death").show()


# COMMAND ----------

# Apply In Pandas
import pandas as pd  
from pyspark.sql.functions import pandas_udf

def mean_func(key, pdf):
    # key is a tuple of one numpy.int64, which is the value
    # of 'id' for the current group
    return pd.DataFrame([key + (pdf.death.mean(),)])
df.groupby('Year').applyInPandas(
    mean_func, schema="year string, death double").show() 

# COMMAND ----------

#  when(condition).otherwise(default)
from pyspark.sql.functions import when
variable = "deathIncrease_new"
df1 = df.withColumn(variable, when(df.deathIncrease == 0, "zero")
                                 .when(df.deathIncrease.isNull() ,"zero")
                                 .otherwise(df.deathIncrease))
df1.show()

# COMMAND ----------

# using select
from pyspark.sql.functions import col
df2 = df.select(col("*"), when(df.deathIncrease == 0, "zero")
                                 .when(df.deathIncrease.isNull() ,"zero")
                                 .otherwise(df.deathIncrease).alias("new_colum")) 
df2.show()

# COMMAND ----------

# Case When statement

# CASE
#     WHEN condition1 THEN result_value1
#     WHEN condition2 THEN result_value2
#     -----
#     -----
#     ELSE result
# END;

# COMMAND ----------

# using withColumn
from pyspark.sql.functions import col, expr
df3 = df.withColumn(variable, expr("CASE WHEN deathIncrease = 0 THEN 'Zero' " + 
               "WHEN deathIncrease = null THEN 'Zero' " +
               "ELSE deathIncrease END"))
df3.show()


# COMMAND ----------

# using select
from pyspark.sql.functions import col, expr
df4 = df.select(col("*"), expr("CASE WHEN deathIncrease = 0 THEN 'ZerO' " +
           "WHEN deathIncrease = null THEN 'Zero'" +
           "ELSE deathIncrease END").alias(variable))
df4.show()

# COMMAND ----------

 df.show()