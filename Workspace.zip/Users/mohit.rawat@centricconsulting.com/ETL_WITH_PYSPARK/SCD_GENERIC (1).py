# Databricks notebook source
# MAGIC %sql
# MAGIC -- Create the table
# MAGIC DROP TABLE PRODUCTS_SCD2;
# MAGIC CREATE TABLE PRODUCTS_SCD2 (id1 INT,id INT,name STRING,salary INT,ACTIVE_FLAG STRING,BUSINESS_EFFECTIVE_BEGIN_DATETIME TIMESTAMP, BUSINESS_EFFECTIVE_END_DATETIME TIMESTAMP
# MAGIC ,INSERTED_DATE TIMESTAMP, LASTMODIFIED TIMESTAMP ,CHANGE_HASH STRING)
# MAGIC location ''

# COMMAND ----------

from pyspark.sql.functions import md5,col
from pyspark.sql.functions import concat,expr,lit
from pyspark.sql import functions as f
from datetime import datetime, timedelta
from datetime import date
from delta import DeltaTable
import delta
from pyspark.sql.types import LongType, LongType, StructField, StructType

class createUpsert:
    #Setting Initial List Varaiable
   
    
    # COMMAND ----------
    
    def __init__(self, spark, deltalake_path, current_data_df, primary_key_list, process_date, sur_key,table_name):
        self.spark = spark
        self.deltalake_path = deltalake_path
        self.current_data_df = current_data_df
        self.primary_key_list = primary_key_list
        self.process_date = process_date
        
        self.table_name = table_name
        #process_date = '2022-03-01'
        self.srg_col_name = sur_key
        self.key_col = primary_key_list

        # To enable the schema drift in delta table
        self.spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")
    
    def build_condition_string( self,primary_key_list):
        condition_list = [f'target.{_} = updates.{_}' for _ in primary_key_list]
        condition_list.append(f'target.CHANGE_HASH = updates.CHANGE_HASH')
        condition_list.append(f'target.ACTIVE_FLAG = "Y"')
        
        return ' and '.join(condition_list)
    
    # COMMAND ----------
    
    def synch_columns_in_two_dataframe(self,df1,df2):
            schema1 = set(df1.schema)
            schema2 = set(df2.schema)
            
            for i in schema2.difference(schema1):
                df1 = df1.withColumn(i.name,f.lit(None).cast(i.dataType))
            for i in schema1.difference(schema2):
                df2 = df2.withColumn(i.name,f.lit(None).cast(i.dataType))
    
            df2 = df2.select(df1.columns)
    
            return df1, df2
    
    # COMMAND ----------
    
    def dfZipWithIndex (self,df, offset, colName):
        # df - source dataframe
        # offset - Adjust to ZipWithIndex's Index
        # colName - name of the index column
        
        new_schema = StructType(
            [StructField(colName, LongType(),True)]  #new added field
            + df.schema.fields)                      #table fields
        
        zipped_rdd = df.rdd.zipWithIndex()
        
        new_rdd = zipped_rdd.map(lambda row: ([row[1]+offset] + list(row[0])))
        
        return spark.createDataFrame(new_rdd, new_schema)
    
    # COMMAND ----------
    def execute(self):
        try:
            
            # Read the  source file - Start Date is a source effective date
            todays_df_in = self.current_data_df
            
            #Main Execution--------
            
            key_col = self.key_col
            deltalake_path = self.deltalake_path
            srg_col_name = self.srg_col_name
            srg_col=[srg_col_name]
            scd_col = ['ACTIVE_FLAG','BUSINESS_EFFECTIVE_BEGIN_DATETIME','BUSINESS_EFFECTIVE_END_DATETIME','INSERTED_DATE','LASTMODIFIED']
            add_col = self.key_col + scd_col
            #in_col = ['ABC','PRODUCT_ID']
            in_col = todays_df_in.columns
            hsh_col = list(set(in_col) - set(add_col))
            chg_col = ['CHANGE_HASH']
            diff_col = key_col + chg_col
            tar_col = key_col + hsh_col
            all_col = srg_col + key_col + chg_col + hsh_col +scd_col
            
            
            
            #Read the delta Table
            
            delta_table = DeltaTable.forPath(spark, deltalake_path)
            #delta_table = self.read_delta_table(self.spark, self.deltalake_path)
            #Take Active Records from delta table
            target_active = delta_table.toDF().where("ACTIVE_FLAG = 'Y' ")
                       
            #Finding offset
            target_offset = target_active.groupby().max(srg_col_name).collect()[0][0]
            
            if target_offset is None:
                target_offset = 1
            else:
                target_offset = target_offset + 1
            
            #Generate Dynamic Change Hash Colum for Input DF
            #val newDf = df.selectExpr("concat(nvl(PRODUCT_ID, ''), nvl(PRODUCT_NAME, '')) as NEW_COLUMN")
            changehash_list_in = [f"nvl({_}, '')" for _ in hsh_col]
            changehash_list =','.join({str(k) for k in changehash_list_in})
            changehash_list= 'concat('+changehash_list+')'
            
            changehash = expr(changehash_list)
                
            #Add  Change Hash Colum for Input DF
            todays_df = todays_df_in.withColumn("CHANGE_HASH_IN",md5(changehash))
            
            #display(todays_df)
            #display(target_active )
            
            # COMMAND ----------
            
            #Finding the rows to Updated and Inserted
            delta_table_df= target_active
            all_col = srg_col + key_col + chg_col + hsh_col +scd_col
            chg_col_in = ['CHANGE_HASH_IN']
            diff_col_in = key_col + chg_col_in
            delta_table_df_new = target_active.select(diff_col)
            todays_df_new = todays_df.select(diff_col_in)
            rows_to_be_update_df= delta_table_df_new.join(todays_df_new, on=key_col, how='inner').select(diff_col)
            todays_df = todays_df.withColumnRenamed("CHANGE_HASH_IN","CHANGE_HASH")
            rows_to_be_insert_df= todays_df.subtract(delta_table_df.select(todays_df.columns))           
            
            #delta_table_df_new.join(todays_df_new, on=key_col, how='inner').select(col_list).show()
            
            # COMMAND ----------
            
            #Adding New Columns 
            #f.to_timestamp(f.lit('2022-02-02'),'yyyy-MM-dd'))
            todays_data_df = rows_to_be_insert_df.withColumn("BUSINESS_EFFECTIVE_BEGIN_DATETIME",f.to_timestamp(f.lit(self.process_date),'yyyy-MM-dd')) \
                .withColumn("BUSINESS_EFFECTIVE_END_DATETIME", f.lit(None).cast('Timestamp')) \
                .withColumn("INSERTED_DATE", f.lit(datetime.now()) )\
                .withColumn("LASTMODIFIED", f.lit(datetime.now()) ) \
                .withColumn("ACTIVE_FLAG",f.lit('Y')) \
            
            #todays_data_df.show()
            print("Hello")
            todays_data_df = self.dfZipWithIndex(todays_data_df,  target_offset, srg_col_name ).select(all_col)
            
            #Update Records in Traget table
            END_DATE = f.lit(datetime.combine(date.today(), datetime.min.time())-timedelta(minutes=0,seconds=1))
            yesterday = (datetime.now() - timedelta(1)).strftime('%Y-%m-%d')
            condition = self.build_condition_string(key_col)
            delta_table.alias("target").merge(rows_to_be_update_df.alias("updates"),condition = condition).whenMatchedUpdate(set = {"BUSINESS_EFFECTIVE_END_DATETIME": END_DATE, "ACTIVE_FLAG" :lit('N'), "LASTMODIFIED": f.lit(datetime.now()) }).execute()
            
            print("Hello")            
            #Insert Records in Traget table
            delta_table.alias("target").merge(todays_data_df.alias("new_records"),condition = "1 != 1").whenNotMatchedInsertAll().execute()
            
            print("Upsert Completed")
    
        except Exception as e:
        
            print("Upsert Failed")
        

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from PRODUCTS_SCD2

# COMMAND ----------

spark.read.csv("/FileStore/tables/scd2/Product-4.csv", header = "true").show()

# COMMAND ----------

delta_lake_path = "/user/hive/warehouse/products_scd2"
#delta_lake_path = "/mnt/containershareddna03/dldemo/tables/table1"
#/mnt/containershareddna03/dldemo/tables/table1
current_df = spark.read.csv("/FileStore/tables/scd2/Product-4.csv", header = "true")
primary_key_list = ["PRODUCT_KEY"]
process_date = "2022-03-14"
table_name="products_scd2"
sur_key="PRODUCT_ID"
A = scdUpsert(delta_lake_path,current_df,primary_key_list,sur_key,table_name)
A.execute()



# COMMAND ----------

# MAGIC %sql
# MAGIC select * from PRODUCTS_SCD2

# COMMAND ----------

# MAGIC %md
# MAGIC delta_lake_path = "/mnt/containershareddna03/dldemo/tables/table1"
# MAGIC current_df = spark.read.csv("/mnt/containershareddna03/dldemo/input/emp1.csv", header = "true")
# MAGIC primary_key_list = ["id"]
# MAGIC process_date = "2022-03-14"
# MAGIC table_name="table1"
# MAGIC sur_key="id"
# MAGIC A = createUpsert(spark,delta_lake_path,current_df,primary_key_list,process_date,sur_key,table_name)
# MAGIC A.execute()

# COMMAND ----------

from pyspark.sql.functions import md5,col
from pyspark.sql.functions import concat,expr,lit
from pyspark.sql import functions as f
from datetime import datetime, timedelta
from datetime import date
from delta import DeltaTable
import delta
from pyspark.sql.types import LongType, LongType, StructField, StructType

class scdUpsert:
    #Setting Initial List Varaiable
   
    
    # COMMAND ----------
    
    def __init__(self, deltalake_path, current_data_df, primary_key_list, sur_key,table_name):
        #self.spark = spark
        self.deltalake_path = deltalake_path
        self.current_data_df = current_data_df
        self.primary_key_list = primary_key_list
        #self.process_date = process_date
        
        self.table_name = table_name
        #process_date = '2022-03-01'
        self.srg_col_name = sur_key
        self.key_col = primary_key_list

        # To enable the schema drift in delta table
        #self.spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled = true")
    
    def build_condition_string( self,primary_key_list):
        condition_list = [f'target.{_} = updates.{_}' for _ in primary_key_list]
        #condition_list.append(f'target.CHANGE_HASH = updates.CHANGE_HASH')
        #condition_list.append(f'target.ACTIVE_FLAG = "Y"')
        
        return ' and '.join(condition_list)
    
    # COMMAND ----------
    
    def synch_columns_in_two_dataframe(self,df1,df2):
            schema1 = set(df1.schema)
            schema2 = set(df2.schema)
            
            for i in schema2.difference(schema1):
                df1 = df1.withColumn(i.name,f.lit(None).cast(i.dataType))
            for i in schema1.difference(schema2):
                df2 = df2.withColumn(i.name,f.lit(None).cast(i.dataType))
    
            df2 = df2.select(df1.columns)
    
            return df1, df2
    
    # COMMAND ----------
    
    def dfZipWithIndex (self,df, offset, colName):
        # df - source dataframe
        # offset - Adjust to ZipWithIndex's Index
        # colName - name of the index column
        
        new_schema = StructType(
            [StructField(colName, LongType(),True)]  #new added field
            + df.schema.fields)                      #table fields
        
        zipped_rdd = df.rdd.zipWithIndex()
        
        new_rdd = zipped_rdd.map(lambda row: ([row[1]+offset] + list(row[0])))
        
        return spark.createDataFrame(new_rdd, new_schema)
    
    # COMMAND ----------
    def execute(self):
        try:
            
            # Read the  source file - Start Date is a source effective date
            todays_df_in = self.current_data_df
            
            #Main Execution--------
            
            key_col = self.key_col
            process_date = datetime.now().strftime('%Y-%m-%d')
            deltalake_path = self.deltalake_path
            srg_col_name = self.srg_col_name
            srg_col=[srg_col_name]
            scd_col = ['ACTIVE_FLAG','BUSINESS_EFFECTIVE_BEGIN_DATETIME','BUSINESS_EFFECTIVE_END_DATETIME','INSERTED_DATE','LASTMODIFIED']
            add_col = self.key_col + scd_col
            #in_col = ['ABC','PRODUCT_ID']
            in_col = todays_df_in.columns
            hsh_col = list(set(in_col) - set(add_col))
            chg_col = ['CHANGE_HASH']
            diff_col = key_col + chg_col
            tar_col = key_col + hsh_col
            all_col = srg_col + key_col + chg_col + hsh_col +scd_col
            
            
            
            #Read the delta Table
            
            delta_table = DeltaTable.forPath(spark, deltalake_path)
            #delta_table = self.read_delta_table(self.spark, self.deltalake_path)
            #Take Active Records from delta table
            target_active = delta_table.toDF().where("ACTIVE_FLAG = 'Y' ")
                       
            #Finding offset
            target_offset = target_active.groupby().max(srg_col_name).collect()[0][0]
            
            if target_offset is None:
                target_offset = 1
            else:
                target_offset = target_offset + 1
            
            #Generate Dynamic Change Hash Colum for Input DF
            #val newDf = df.selectExpr("concat(nvl(PRODUCT_ID, ''), nvl(PRODUCT_NAME, '')) as NEW_COLUMN")
            changehash_list_in = [f"nvl({_}, '')" for _ in hsh_col]
            changehash_list =','.join({str(k) for k in changehash_list_in})
            changehash_list= 'concat('+changehash_list+')'
            
            changehash = expr(changehash_list)
                
            #Add  Change Hash Colum for Input DF
            todays_df = todays_df_in.withColumn("CHANGE_HASH_IN",md5(changehash))
            
            #display(todays_df)
            #display(target_active )
            
            # COMMAND ----------
            
            #Finding the rows to Updated and Inserted
            delta_table_df= target_active
            all_col = srg_col + key_col + chg_col + hsh_col +scd_col
            print("ALL",all_col)
            print("ALL",hsh_col)
            chg_col_in = ['CHANGE_HASH_IN']
            diff_col_in = key_col + chg_col_in
            delta_table_df_new = target_active.select(diff_col)
            todays_df_new = todays_df.select(diff_col_in)
            rows_to_be_update_df= delta_table_df_new.join(todays_df_new, on=key_col, how='inner').where("CHANGE_HASH_IN <> CHANGE_HASH")
            todays_df = todays_df.withColumnRenamed("CHANGE_HASH_IN","CHANGE_HASH")
            rows_to_be_insert_df= todays_df.subtract(delta_table_df.select(todays_df.columns))           
            rows_to_be_insert_df.show()
            rows_to_be_update_df.show()
            delta_table_df_new.show()
            todays_df_new.show()
            #delta_table_df_new.join(todays_df_new, on=key_col, how='inner').select(col_list).show()
            
            # COMMAND ----------
            
            #Adding New Columns 
            #f.to_timestamp(f.lit('2022-02-02'),'yyyy-MM-dd'))
            todays_data_df = rows_to_be_insert_df.withColumn("BUSINESS_EFFECTIVE_BEGIN_DATETIME",f.to_timestamp(f.lit(process_date),'yyyy-MM-dd')) \
                .withColumn("BUSINESS_EFFECTIVE_END_DATETIME", f.lit(None).cast('Timestamp')) \
                .withColumn("INSERTED_DATE", f.lit(datetime.now()) )\
                .withColumn("LASTMODIFIED", f.lit(datetime.now()) ) \
                .withColumn("ACTIVE_FLAG",f.lit('Y')) \
            
            
            todays_data_df = self.dfZipWithIndex(todays_data_df,  target_offset, srg_col_name ).select(all_col)
            
            #Update Records in Traget table
            END_DATE = f.lit(datetime.combine(date.today(), datetime.min.time())-timedelta(minutes=0,seconds=1))
            yesterday = (datetime.now() - timedelta(1)).strftime('%Y-%m-%d')
            condition = self.build_condition_string(key_col)
            delta_table.alias("target").merge(rows_to_be_update_df.alias("updates"),condition = condition).whenMatchedUpdate(set = {"BUSINESS_EFFECTIVE_END_DATETIME": END_DATE, "ACTIVE_FLAG" :lit('N'), "LASTMODIFIED": f.lit(datetime.now()) }).execute()
                        
            #Insert Records in Traget table
            delta_table.alias("target").merge(todays_data_df.alias("new_records"),condition = "1 != 1").whenNotMatchedInsertAll().execute()
            
            print("Upsert Completed")
    
        except Exception as e:
        
            print("Upsert Failed")
