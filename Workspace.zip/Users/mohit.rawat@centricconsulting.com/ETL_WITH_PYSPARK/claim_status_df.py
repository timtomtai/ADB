# Databricks notebook source
source_path = '/mnt/containershareddna03/Stg'
source_format = 'parquet'
source_delimiter = None
source_header = True
src_path1 = source_path+'/claim_control/claim_control'
src_path2 = source_path+'/claim_control_activity/claim_control_activity'
src_path3 = source_path+'/claim_activity_code/claim_activity_code'
source_file1 = spark.read.load(src_path1,format=source_format, delimiter=source_delimiter, header=source_header)
source_file2 = spark.read.load(src_path2,format=source_format, delimiter=source_delimiter, header=source_header)
source_file3 = spark.read.load(src_path3,format=source_format, delimiter=source_delimiter, header=source_header) 

# COMMAND ----------

source_file1.distinct().show()

# COMMAND ----------

from pyspark.sql.types import LongType, IntegerType, StructField, StructType
from pyspark.sql.functions import concat, lit, col, when
#source_file1.show()
joined_df1 = source_file1.join(source_file2.filter(source_file2["claimactivitycode_id"].isin([1,2,3,4,12])), source_file1["claimcontrol_id"] == source_file2["claimcontrol_id"], how='left').select(concat(source_file1["claimcontrol_id"],lit("#DIA")).alias("CLAIM_FNK"),source_file2["claimactivitycode_id"].alias("STATUS_CODE"),source_file2["dscr"].alias("STATUS_DESC"),lit("").alias("RESERVE_CLOSED_FLAG"),concat(source_file1["claimcontrol_id"],when(~source_file2["claimactivitycode_id"].isin(['1','2']),concat(lit("#"),source_file2["claimactivitycode_id"])).otherwise(lit("")),lit("#DIA")).alias("STATUS_NK"),source_file2["claimactivitycode_id"].alias("join_id"))

joined_outdf = joined_df1.join(source_file3,joined_df1["join_id"] == source_file3["claimactivitycode_id"]).select(joined_df1["*"],source_file3["dscr"].alias("STATUS_NAME"),lit("DIA").alias("SOURCE_SYSTEM_CODE"),lit(" ").alias("STATUS_DATETIME")).select(["STATUS_NK","CLAIM_FNK","STATUS_CODE","STATUS_NAME","STATUS_DESC","STATUS_DATETIME","RESERVE_CLOSED_FLAG","SOURCE_SYSTEM_CODE"])


# concat(source_file1["claimcontrol_id"],concatw(hen(~source_file1["claimactivitycode_id"].isin(['1','2']),concat(lit("#"),source_file2["claimactivitycode_id"])).otherwise(lit" ")),lit("DIA")).alias("STATUS_NK")
#([col("source_file1.claimcontrol_id").alias("cc_claimcontrol_id")])
                                                                                                                                         
# from pyspark.sql.functions import concat, lit, col
 
# df1=df_states.select("*", concat(col("claimcontrol_id"),lit("#DIA"))).alias("CLAIM_FNK"))
# df1.show()                                                                                                                                       #,source_file2.claimactivitycode_id,source_file2.claimactivitycode_id')

# #df.select([col("id").alias("eventid"),col("starttime").alias("eventstarttime"),col("endtime").alias("eventendtime")]+cols+[lit(proceessing_time).alias("processingtime")])
# #joined_df2 = joined_df1.join(source_file3,joined_df1["claimactivitycode_id"]== source_file3["claimactivitycode_id"],how = 'left').select('joined_df1.*')
# # .join(source_file3,source_file2("claimactivitycode_id" ) == source_file3("claimactivitycode_id"),how = 'left').select('source_file1.*')



# CAST(CC.claimcontrol_id as varchar(50)) 
# 			+ CASE WHEN CCA.claimactivitycode_id NOT IN ('1', '2') THEN '#' + CAST(CCA.claimactivitycode_id as varchar(50)) ELSE '' END
# 			+ '#DIA' as [STATUS_NK],
# 		CAST(CC.claimcontrol_id as varchar(50)) + '#DIA'  as [CLAIM_FNK],
# 		CCA.claimactivitycode_id as STATUS_CODE,
# 		CAC.dscr as  STATUS_NAME,
# 		CCA.dscr as  STATUS_DESC,
# 		NULL RESERVE_CLOSED_FLAG
# joined_df = source_file1.join(source_file2, col('source_file1.claimcontrol_id').cast(IntegerType()) == col('source_file2.claimcontrol_id'), 'left')

# joined_df.join(source_file3, col('source_file2.claimactivitycode_id') == col('source_file3.claimactivitycode_id'), 'left').select('source_file1.*').show()

# COMMAND ----------

from pyspark.sql.types import LongType, IntegerType, StructField, StructType
from pyspark.sql.functions import concat, lit, col, when
from delta import DeltaTable
import delta


deltalake_path1 = '/mnt/containershareddna03/Int/edw_claim'
deltalake_path2 = '/mnt/containershareddna03/Int/edw_claim_status'
src_delta_table1 = DeltaTable.forPath(spark, deltalake_path1)
src_delta_table2 = DeltaTable.forPath(spark, deltalake_path2)
source_file1 = src_delta_table1.toDF().where("ACTIVE_FLAG = 'Y' ")
source_file2 = src_delta_table2.toDF().where("ACTIVE_FLAG = 'Y' ").select(["CLAIM_FNK","STATUS_NAME","STATUS_DATETIME"])

# COMMAND ----------

col_list = ["DIM_CLAIM_NK","CLAIM_NUMBER_NAME","CLAIM_STATUS_NAME","CLAIM_STATUS_DATETIME","LOSS_DATETIME","FIRST_NOTICE_OF_LOSS_DATETIME","CLAIM_FIRST_CLOSE_DATETIME","CLAIM_CLOSE_DATETIME","CLAIM_REOPEN_DATETIME","CLAIM_LATEST_REOPEN_DATETIME","LOSS_TYPE_CODE","CLAIM_EVENT_TYPE_CODE","CLAIM_EVENT_TYPE_NAME","CLAIM_TYPE_DESC","CAUSE_OF_LOSS_CODE","CAUSE_OF_LOSS_DESC","LOSS_LOCATION_ADDRESS_1_ADDRESS","LOSS_LOCATION_ADDRESS_2_ADDRESS","LOSS_LOCATION_CITY_ADDRESS","LOSS_LOCATION_STATE_ADDRESS","LOSS_LOCATION_ZIP_ADDRESS","SOURCE_SYSTEM_CODE"]
joined_df1 = source_file1.join(source_file2, source_file1["CLAIM_NK"] == source_file2["CLAIM_FNK"]).select(source_file1["*"],concat(source_file1["CLAIM_NK"],lit("#EDW")).alias("DIM_CLAIM_NK"),source_file2["STATUS_NAME"].alias("CLAIM_STATUS_NAME"),source_file2["STATUS_DATETIME"].alias("CLAIM_STATUS_DATETIME")).select(col_list)
# joined_df1 = source_file1.join(source_file2, source_file1["CLAIM_NK"] == source_file2["CLAIM_FNK"], how='inner').select('source_file1.*',concat(source_file1["CLAIM_NK"],lit("#EDW")).alias("DIM_CLAIM_NK"),'source_file2.STATUS_NAME'.alias("CLAIM_STATUS_NAME"),'source_file2.STATUS_DATETIME'.alias("CLAIM_STATUS_DATETIME"))

# COMMAND ----------

display(joined_df1)