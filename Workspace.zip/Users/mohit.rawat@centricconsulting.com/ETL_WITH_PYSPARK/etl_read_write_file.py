# Databricks notebook source
def readSourceFile(filePath,format, **kwargs) :
    
    
    schema = kwargs.get('schema', None)
    badRecordsPath = kwargs.get ('badRecordsPath', None)
    delimiter = kwargs.get ('delimiter', None)
    pathGlobFilter = kwargs.get ('pathGlobFilter', None)
    header = kwargs.get ('header', None)
    badRecordsPath = kwargs.get ('badRecordsPath', None)
    multiline = kwargs.get ('multiline', None)
    print(schema)
    try:
        df_file_read = spark.read.load(filePath,
                     format=format, schema=schema, delimiter=delimiter, header=header, badRecordsPath=badRecordsPath, multiline=multiline)
        return df_file_read
        
    except Exception as e:
        print("Error in Reading Source File")
    


# COMMAND ----------

# Pushing a csv file 
df1 = readSourceFile ("/FileStore/tables/TABTEST/DATA_*.csv", "csv" ,delimiter="," , schema="a int, b string, c string, d string")

df1.show()

# how it is creating the dataframe shema

# COMMAND ----------

# Pushing a parquet file 
df2 = readSourceFile ("/mnt/containershareddna01/NYCTripSmall.parquet", "parquet")

df2.show()

# COMMAND ----------

# Pushing a json file 
from pyspark.sql.functions import explode, col
df3 = readSourceFile ("/mnt/containershareddna01/Feature.json", "json", multiline=True)


df3.show()

#print(df3['properties'])
#df3 = spark.read.load("/mnt/containershareddna01/Feature.json", format="json",multiline=True)
#df3.select(explode(col('properties')).alias('normalized')).show()
df31 = df3.select("properties.activities.name")
print(df31)

columns = flatten(df31.schema)
df31.select(columns)



# COMMAND ----------

# Pushing a json file 
df4 = readSourceFile ("/tmp/input/jsonFile", "json", badRecordsPath="/tmp/badRecordsPathPY")

df4.show()

# COMMAND ----------

df_file_read = spark.read.load("/tmp/input/jsonFile",
                     format="json", pathGlobFilter="*.*", schema="a int, b int, name string , dok timestamp", badRecordsPath="/tmp/badRecordsPathPY")