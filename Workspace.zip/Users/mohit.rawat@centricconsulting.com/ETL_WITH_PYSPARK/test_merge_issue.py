# Databricks notebook source
from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import concat,when,to_date,col,lit
from pyspark.sql.types import StructType,StringType,TimestampType,DecimalType,IntegerType,StructField

source_format = "parquet" # This can be "csv", "json", "parquet" depending upon the source file
source_delimiter = None # This can be "," or anyother delimiter or None
source_header = True # This can be True or False or None
source_path = '/mnt/containershareddna03/Stg'
src_path1 = source_path+'/claim_control/claim_control'
src_path2 = source_path+'/claim_control_activity/claim_control_activity'
src_path3 = source_path+'/claim_activity_code/claim_activity_code'
source_file1 = spark.read.load(src_path1,
         format=source_format, delimiter=source_delimiter, header=source_header)
source_file2 = spark.read.load(src_path2,
         format=source_format, delimiter=source_delimiter, header=source_header)
source_file3 = spark.read.load(src_path3,
         format=source_format, delimiter=source_delimiter, header=source_header)         
      
      

        
joined_df1 = source_file1.join(source_file2.filter(source_file2["claimactivitycode_id"].isin([1,2,3,4,12])), source_file1["claimcontrol_id"] == source_file2["claimcontrol_id"], how='left').select(concat(source_file1["claimcontrol_id"],lit("#DIA")).alias("CLAIM_FNK"),source_file2["claimactivitycode_id"].alias("STATUS_CODE"),source_file2["dscr"].alias("STATUS_DESC"),lit("").alias("RESERVE_CLOSED_FLAG"),concat(source_file1["claimcontrol_id"],when(~source_file2["claimactivitycode_id"].isin(['1','2']),concat(lit("#"),source_file2["claimactivitycode_id"])).otherwise(lit("")),lit("#DIA")).alias("STATUS_NK"),source_file2["claimactivitycode_id"].alias("join_id"),source_file2["pcadded_date"].alias("STATUS_DATETIME"),source_file2["num"].alias("NUM"))
source_file = joined_df1.join(source_file3,joined_df1["join_id"] == source_file3["claimactivitycode_id"]).select(joined_df1["*"],source_file3["dscr"].alias("STATUS_NAME"),lit("DIA").alias("SOURCE_SYSTEM_CODE"))
source_field_list = ["STATUS_NK","CLAIM_FNK","STATUS_CODE","STATUS_NAME","STATUS_DESC","STATUS_DATETIME","RESERVE_CLOSED_FLAG","SOURCE_SYSTEM_CODE","NUM"]
source_file = source_file.select(source_field_list)


source_file.registerTempTable("Tab1")
source_file = spark.sql("SELECT  * from Tab1")
        

# COMMAND ----------

display(spark.sql("SELECT  * from Tab1 where STATUS_NK= '348#DIA'").distinct())