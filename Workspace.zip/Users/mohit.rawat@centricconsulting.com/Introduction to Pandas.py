# Databricks notebook source
# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:3.75em;color:purple; font-style:bold"><br>
# MAGIC Pandas</p><br>
# MAGIC 
# MAGIC *pandas* is a Python library for data analysis. It offers a number of data exploration, cleaning and transformation operations that are critical in working with data in Python. 
# MAGIC 
# MAGIC *pandas* build upon *numpy* and *scipy* providing easy-to-use data structures and data manipulation functions with integrated indexing.
# MAGIC 
# MAGIC The main data structures *pandas* provides are *Series* and *DataFrames*. After a brief introduction to these two data structures and data ingestion, the key features of *pandas* this notebook covers are:
# MAGIC * Generating descriptive statistics on data
# MAGIC * Data cleaning using built in pandas functions
# MAGIC * Frequent data operations for subsetting, filtering, insertion, deletion and aggregation of data
# MAGIC * Merging multiple datasets using dataframes
# MAGIC * Working with timestamps and time-series data
# MAGIC 
# MAGIC **Additional Recommended Resources:**
# MAGIC * *pandas* Documentation: http://pandas.pydata.org/pandas-docs/stable/
# MAGIC * *Python for Data Analysis* by Wes McKinney
# MAGIC * *Python Data Science Handbook* by Jake VanderPlas
# MAGIC 
# MAGIC Let's get started with our first *pandas* notebook!

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.75em;color:#2462C0; font-style:bold"><br>
# MAGIC 
# MAGIC Import Libraries
# MAGIC </p>

# COMMAND ----------

import pandas as pd

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.75em;color:#2462C0; font-style:bold">
# MAGIC Introduction to pandas Data Structures</p>
# MAGIC <br>
# MAGIC *pandas* has two main data structures it uses, namely, *Series* and *DataFrames*. 
# MAGIC 
# MAGIC <p style="font-family: Arial; font-size:1.75em;color:#2462C0; font-style:bold">
# MAGIC pandas Series</p>
# MAGIC 
# MAGIC *pandas Series* one-dimensional labeled array. 

# COMMAND ----------

ser = pd.Series([100, 'foo', 300, 'bar', 500], ['tom', 'bob', 'nancy', 'dan', 'eric'])

# COMMAND ----------

ser

# COMMAND ----------

ser.index

# COMMAND ----------

ser.loc[['nancy','bob']]

# COMMAND ----------

ser[[4, 3, 1]]

# COMMAND ----------

ser.iloc[2]

# COMMAND ----------

'bob' in ser

# COMMAND ----------

ser

# COMMAND ----------

ser * 2

# COMMAND ----------

ser[['nancy', 'eric']] ** 2

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.75em;color:#2462C0; font-style:bold">
# MAGIC pandas DataFrame</p>
# MAGIC 
# MAGIC *pandas DataFrame* is a 2-dimensional labeled data structure.

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.25em;color:#2462C0; font-style:bold">
# MAGIC Create DataFrame from dictionary of Python Series</p>

# COMMAND ----------

d = {'one' : pd.Series([100., 200., 300.], index=['apple', 'ball', 'clock']),
     'two' : pd.Series([111., 222., 333., 4444.], index=['apple', 'ball', 'cerill', 'dancy'])}

# COMMAND ----------

df = pd.DataFrame(d)
print(df)

# COMMAND ----------

df.index

# COMMAND ----------

df.columns

# COMMAND ----------

pd.DataFrame(d, index=['dancy', 'ball', 'apple'])

# COMMAND ----------

pd.DataFrame(d, index=['dancy', 'ball', 'apple'], columns=['two', 'five'])

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.25em;color:#2462C0; font-style:bold">
# MAGIC Create DataFrame from list of Python dictionaries</p>

# COMMAND ----------

data = [{'alex': 1, 'joe': 2}, {'ema': 5, 'dora': 10, 'alice': 20}]

# COMMAND ----------

pd.DataFrame(data)

# COMMAND ----------

pd.DataFrame(data, index=['orange', 'red'])

# COMMAND ----------

pd.DataFrame(data, columns=['joe', 'dora','alice'])

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.25em;color:#2462C0; font-style:bold">
# MAGIC Basic DataFrame operations</p>

# COMMAND ----------

df

# COMMAND ----------

df['one']

# COMMAND ----------

df['three'] = df['one'] * df['two']
df

# COMMAND ----------

df['flag'] = df['one'] > 250
df

# COMMAND ----------

three = df.pop('three')

# COMMAND ----------

three

# COMMAND ----------

df

# COMMAND ----------

del df['two']

# COMMAND ----------

df

# COMMAND ----------

df.insert(2, 'copy_of_one', df['one'])
df

# COMMAND ----------

df['one_upper_half'] = df['one'][:2]
df

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.75em;color:#2462C0; font-style:bold">
# MAGIC Case Study: Movie Data Analysis</p>
# MAGIC <br>This notebook uses a dataset from the MovieLens website. We will describe the dataset further as we explore with it using *pandas*. 
# MAGIC 
# MAGIC ## Download the Dataset
# MAGIC 
# MAGIC Please note that **you will need to download the dataset**. Although the video for this notebook says that the data is in your folder, the folder turned out to be too large to fit on the edX platform due to size constraints.
# MAGIC 
# MAGIC Here are the links to the data source and location:
# MAGIC * **Data Source:** MovieLens web site (filename: ml-20m.zip)
# MAGIC * **Location:** https://grouplens.org/datasets/movielens/
# MAGIC 
# MAGIC Once the download completes, please make sure the data files are in a directory called *movielens* in your *Week-3-pandas* folder. 
# MAGIC 
# MAGIC Let us look at the files in this dataset using the UNIX command ls.

# COMMAND ----------

# Note: Adjust the name of the folder to match your local directory

!ls ./movielens

# COMMAND ----------

!cat ./movielens/movies.csv | wc -l

# COMMAND ----------

!head -5 ./movielens/ratings.csv

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.75em;color:#2462C0; font-style:bold">
# MAGIC Use Pandas to Read the Dataset<br>
# MAGIC </p>
# MAGIC <br>
# MAGIC In this notebook, we will be using three CSV files:
# MAGIC * **ratings.csv :** *userId*,*movieId*,*rating*, *timestamp*
# MAGIC * **tags.csv :** *userId*,*movieId*, *tag*, *timestamp*
# MAGIC * **movies.csv :** *movieId*, *title*, *genres* <br>
# MAGIC 
# MAGIC Using the *read_csv* function in pandas, we will ingest these three files.

# COMMAND ----------

movies = pd.read_csv('./movielens/movies.csv', sep=',')
print(type(movies))
movies.head(15)

# COMMAND ----------

# Timestamps represent seconds since midnight Coordinated Universal Time (UTC) of January 1, 1970

tags = pd.read_csv('./movielens/tags.csv', sep=',')
tags.head()

# COMMAND ----------

ratings = pd.read_csv('./movielens/ratings.csv', sep=',', parse_dates=['timestamp'])
ratings.head()

# COMMAND ----------

# For current analysis, we will remove timestamp (we will come back to it!)

del ratings['timestamp']
del tags['timestamp']

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:2em;color:#2467C0">Data Structures </h1>

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:1.5em;color:#2467C0">Series</h1>

# COMMAND ----------

#Extract 0th row: notice that it is infact a Series

row_0 = tags.iloc[0]
type(row_0)

# COMMAND ----------

print(row_0)

# COMMAND ----------

row_0.index

# COMMAND ----------

row_0['userId']

# COMMAND ----------

'rating' in row_0

# COMMAND ----------

row_0.name

# COMMAND ----------

row_0 = row_0.rename('first_row')
row_0.name

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:1.5em;color:#2467C0">DataFrames </h1>

# COMMAND ----------

tags.head()

# COMMAND ----------

tags.index

# COMMAND ----------

tags.columns

# COMMAND ----------

# Extract row 0, 11, 2000 from DataFrame

tags.iloc[ [0,11,2000] ]

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:2em;color:#2467C0">Descriptive Statistics</h1>
# MAGIC 
# MAGIC Let's look how the ratings are distributed! 

# COMMAND ----------

ratings['rating'].describe()

# COMMAND ----------

ratings.describe()

# COMMAND ----------

ratings['rating'].mean()

# COMMAND ----------

ratings.mean()

# COMMAND ----------

ratings['rating'].min()

# COMMAND ----------

ratings['rating'].max()

# COMMAND ----------

ratings['rating'].std()

# COMMAND ----------

ratings['rating'].mode()

# COMMAND ----------

ratings.corr()

# COMMAND ----------

filter_1 = ratings['rating'] > 5
print(filter_1)
filter_1.any()

# COMMAND ----------

filter_2 = ratings['rating'] > 0
filter_2.all()

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:2em;color:#2467C0">Data Cleaning: Handling Missing Data</h1>

# COMMAND ----------

movies.shape

# COMMAND ----------

#is any row NULL ?

movies.isnull().any()

# COMMAND ----------

# MAGIC %md
# MAGIC Thats nice ! No NULL values !

# COMMAND ----------

ratings.shape

# COMMAND ----------

#is any row NULL ?

ratings.isnull().any()

# COMMAND ----------

# MAGIC %md
# MAGIC Thats nice ! No NULL values !

# COMMAND ----------

tags.shape

# COMMAND ----------

#is any row NULL ?

tags.isnull().any()

# COMMAND ----------

# MAGIC %md
# MAGIC We have some tags which are NULL.

# COMMAND ----------

tags = tags.dropna()

# COMMAND ----------

#Check again: is any row NULL ?

tags.isnull().any()

# COMMAND ----------

tags.shape

# COMMAND ----------

# MAGIC %md
# MAGIC Thats nice ! No NULL values ! Notice the number of lines have reduced.

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:2em;color:#2467C0">Data Visualization</h1>

# COMMAND ----------

# MAGIC %matplotlib inline
# MAGIC 
# MAGIC ratings.hist(column='rating', figsize=(15,10))

# COMMAND ----------

ratings.boxplot(column='rating', figsize=(15,20))

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:2em;color:#2467C0">Slicing Out Columns</h1>
# MAGIC  

# COMMAND ----------

tags['tag'].head()

# COMMAND ----------

movies[['title','genres']].head()

# COMMAND ----------

ratings[-10:]

# COMMAND ----------

tag_counts = tags['tag'].value_counts()
tag_counts[-10:]

# COMMAND ----------

tag_counts[:10].plot(kind='bar', figsize=(15,10))

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:2em;color:#2467C0">Filters for Selecting Rows</h1>

# COMMAND ----------

is_highly_rated = ratings['rating'] >= 4.0

ratings[is_highly_rated][30:50]

# COMMAND ----------

is_animation = movies['genres'].str.contains('Animation')

movies[is_animation][5:15]

# COMMAND ----------

movies[is_animation].head(15)

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:2em;color:#2467C0">Group By and Aggregate </h1>

# COMMAND ----------

ratings_count = ratings[['movieId','rating']].groupby('rating').count()
ratings_count

# COMMAND ----------

average_rating = ratings[['movieId','rating']].groupby('movieId').mean()
average_rating.head()

# COMMAND ----------

movie_count = ratings[['movieId','rating']].groupby('movieId').count()
movie_count.head()

# COMMAND ----------

movie_count = ratings[['movieId','rating']].groupby('movieId').count()
movie_count.tail()

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:2em;color:#2467C0">Merge Dataframes</h1>

# COMMAND ----------

tags.head()

# COMMAND ----------

movies.head()

# COMMAND ----------

t = movies.merge(tags, on='movieId', how='inner')
t.head()

# COMMAND ----------

# MAGIC %md
# MAGIC More examples: http://pandas.pydata.org/pandas-docs/stable/merging.html

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.75em;color:#2462C0; font-style:bold"><br>
# MAGIC 
# MAGIC 
# MAGIC Combine aggreagation, merging, and filters to get useful analytics
# MAGIC </p>

# COMMAND ----------

avg_ratings = ratings.groupby('movieId', as_index=False).mean()
del avg_ratings['userId']
avg_ratings.head()

# COMMAND ----------

box_office = movies.merge(avg_ratings, on='movieId', how='inner')
box_office.tail()

# COMMAND ----------

is_highly_rated = box_office['rating'] >= 4.0

box_office[is_highly_rated][-5:]

# COMMAND ----------

is_comedy = box_office['genres'].str.contains('Comedy')

box_office[is_comedy][:5]

# COMMAND ----------

box_office[is_comedy & is_highly_rated][-5:]

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:2em;color:#2467C0">Vectorized String Operations</h1>

# COMMAND ----------

movies.head()

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.35em;color:#2462C0; font-style:bold"><br>
# MAGIC 
# MAGIC Split 'genres' into multiple columns
# MAGIC 
# MAGIC <br> </p>

# COMMAND ----------

movie_genres = movies['genres'].str.split('|', expand=True)

# COMMAND ----------

movie_genres[:10]

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.35em;color:#2462C0; font-style:bold"><br>
# MAGIC 
# MAGIC Add a new column for comedy genre flag
# MAGIC 
# MAGIC <br> </p>

# COMMAND ----------

movie_genres['isComedy'] = movies['genres'].str.contains('Comedy')

# COMMAND ----------

movie_genres[:10]

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.35em;color:#2462C0; font-style:bold"><br>
# MAGIC 
# MAGIC Extract year from title e.g. (1995)
# MAGIC 
# MAGIC <br> </p>

# COMMAND ----------

movies['year'] = movies['title'].str.extract('.*\((.*)\).*', expand=True)

# COMMAND ----------

movies.tail()

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.35em;color:#2462C0; font-style:bold"><br>
# MAGIC 
# MAGIC More here: http://pandas.pydata.org/pandas-docs/stable/text.html#text-string-methods
# MAGIC <br> </p>

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:2em;color:#2467C0">Parsing Timestamps</h1>

# COMMAND ----------

# MAGIC %md
# MAGIC Timestamps are common in sensor data or other time series datasets.
# MAGIC Let us revisit the *tags.csv* dataset and read the timestamps!

# COMMAND ----------

tags = pd.read_csv('./movielens/tags.csv', sep=',')

# COMMAND ----------

tags.dtypes

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.35em;color:#2462C0; font-style:bold">
# MAGIC 
# MAGIC Unix time / POSIX time / epoch time records 
# MAGIC time in seconds <br> since midnight Coordinated Universal Time (UTC) of January 1, 1970
# MAGIC </p>

# COMMAND ----------

tags.head(5)

# COMMAND ----------

tags['parsed_time'] = pd.to_datetime(tags['timestamp'], unit='s')

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.35em;color:#2462C0; font-style:bold">
# MAGIC 
# MAGIC Data Type datetime64[ns] maps to either <M8[ns] or >M8[ns] depending on the hardware
# MAGIC 
# MAGIC </p>

# COMMAND ----------


tags['parsed_time'].dtype

# COMMAND ----------

tags.head(2)

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.35em;color:#2462C0; font-style:bold">
# MAGIC 
# MAGIC Selecting rows based on timestamps
# MAGIC </p>

# COMMAND ----------

greater_than_t = tags['parsed_time'] > '2015-02-01'

selected_rows = tags[greater_than_t]

tags.shape, selected_rows.shape

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.35em;color:#2462C0; font-style:bold">
# MAGIC 
# MAGIC Sorting the table using the timestamps
# MAGIC </p>

# COMMAND ----------

tags.sort_values(by='parsed_time', ascending=True)[:10]

# COMMAND ----------

# MAGIC %md
# MAGIC <h1 style="font-size:2em;color:#2467C0">Average Movie Ratings over Time </h1>
# MAGIC ## Are Movie ratings related to the year of launch?

# COMMAND ----------

average_rating = ratings[['movieId','rating']].groupby('movieId', as_index=False).mean()
average_rating.tail()

# COMMAND ----------

joined = movies.merge(average_rating, on='movieId', how='inner')
joined.head()
joined.corr()

# COMMAND ----------

yearly_average = joined[['year','rating']].groupby('year', as_index=False).mean()
yearly_average[:10]

# COMMAND ----------

yearly_average[-20:].plot(x='year', y='rating', figsize=(15,10), grid=True)

# COMMAND ----------

# MAGIC %md
# MAGIC <p style="font-family: Arial; font-size:1.35em;color:#2462C0; font-style:bold">
# MAGIC 
# MAGIC Do some years look better for the boxoffice movies than others? <br><br>
# MAGIC 
# MAGIC Does any data point seem like an outlier in some sense?
# MAGIC 
# MAGIC </p>

# COMMAND ----------

