# Databricks notebook source
dbutils.fs.mount(
  source = "wasbs://containershareddna01@sashareddna01.blob.core.windows.net",
  mount_point = "/mnt/containershareddna01",
  extra_configs = {"fs.azure.account.key.sashareddna01.blob.core.windows.net":dbutils.secrets.get(scope = "scopedna01", key = "secretdna01")})


# COMMAND ----------

blob_storage_account_access_key = dbutils.secrets.get(scope = "scopedna01", key = "secretdna01")

# COMMAND ----------

