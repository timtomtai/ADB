# Databricks notebook source
# MAGIC %python
# MAGIC 
# MAGIC 
# MAGIC dbutils.fs.mount(
# MAGIC   source = "wasbs://con-adb-test2@saccountnord2mohit.blob.core.windows.net",
# MAGIC   mount_point = "/mnt/con-adb-test3",
# MAGIC   extra_configs = {"fs.azure.account.key.saccountnord2mohit.blob.core.windows.net":dbutils.secrets.get(scope = "scope-adb2", key = "secret-adb2")})

# COMMAND ----------


df= spark.read.csv("/mnt/con-adb-test/DATA_SOURCE.csv")

# COMMAND ----------

df.show()