# Databricks notebook source
dbutils.widgets.text("VarA","Mohit","")
V_name = dbutils.widgets.get("VarA")

spark.conf.set('personal.name',V_name)

df2 = sqlContext.sql("select row_number() over (order by 1) as cntr,Name from test_delta_table_MR where Name = '${personal.name}'")
df2.show()

df2.write.csv('/FileStore/tables/TABTEST/DATA_TARGET_TRIGGERED_ADF2.csv')