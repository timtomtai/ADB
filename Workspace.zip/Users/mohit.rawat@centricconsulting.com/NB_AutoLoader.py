# Databricks notebook source
#Create directory in DBFS
user_dir = 'mohit.rawat@centricconsulting.com'
upload_path = "/FileStore/tables/shared-uploads/" + user_dir + "/population_data_upload"

dbutils.fs.mkdirs(upload_path)

print(upload_path)

# COMMAND ----------

checkpoint_path = '/tmp/delta/population_data/_checkpoints'
write_path = '/tmp/delta/population_data'

# Set up the stream to begin reading incoming files from the
# upload_path location.
df = spark.readStream.format('cloudFiles') \
  .option('cloudFiles.format', 'csv') \
  .option('header', 'true') \
  .schema('city string, year int, population long') \
  .load(upload_path)

# Start the stream.
# Use the checkpoint_path location to keep a record of all files that
# have already been uploaded to the upload_path location.
# For those that have been uploaded since the last check,
# write the newly-uploaded files' data to the write_path location.
df.writeStream.format('delta') \
  .option('checkpointLocation', checkpoint_path) \
  .start(write_path)

# COMMAND ----------

df_population = spark.read.format('delta').load(write_path)

display(df_population)

# COMMAND ----------

# MAGIC %fs ls /FileStore/tables/shared-uploads/mohit.rawat@centricconsulting.com/population_data_upload

# COMMAND ----------

for s in spark.streams.active:
    s.stop()