# Databricks notebook source
# MAGIC %scala
# MAGIC Seq("""{"a": 1, "b": 2,"name": "mohit", "datetime" : "2022-01-01 00:00:00"}""", """{"a": 1, "b": 2,"name": "rohit", "datetime" :"2021-01-01 00:00:00"}""","""{bad-record""").toDF().write.text("/tmp/input/jsonFile")
# MAGIC 
# MAGIC 
# MAGIC val df = spark.read.option("badRecordsPath", "/tmp/badRecordsPath").schema("a int, b int").json("/tmp/input/jsonFile")

# COMMAND ----------


dbutils.fs.rm("/tmp/input/jsonFile",True)
#%fs rm -rf "/tmp/input/jsonFile"

# COMMAND ----------

dbutils.fs.help()

# COMMAND ----------


df_py = spark.read.load("/tmp/input/jsonFile",
                     format="json", pathGlobFilter="*.*", schema="a int, b int, name string , dok timestamp", badRecordsPath="/tmp/badRecordsPathPY")

df_py.show()

# COMMAND ----------

# MAGIC %fs ls /tmp/badRecordsPathPY/20220111T090421/bad_records

# COMMAND ----------

# MAGIC %fs head dbfs:/tmp/badRecordsPathPY/20220111T090421/bad_records/part-00001-6175afbf-087a-47e4-9bdf-0f03f2a60ed9

# COMMAND ----------

df_py.printSchema()

columns = df_py.dtypes
print(columns)
assert len(columns) == 6, "Expected 6 columns but found " + str(len(columns))

  

# COMMAND ----------

print(columns[0][0])

print(df_py.collect()[0][0] )

type(columns)
type(df_py)

# COMMAND ----------

total = df_py.count()

print("Record Count: {0:0,}".format( total ))

# COMMAND ----------

from pyspark.sql.functions import *

columnD = expr("a + 1")

# This uses the lit(..) to create a literal (constant) value.
columnE = lit("abc")

# Print the type of each attribute
print("columnD: {}".format(columnD))
print("columnE: {}".format(columnE))

# COMMAND ----------

df_py.filter(df_py.name.endswith('it')).collect()

#print(df_py.show())

# COMMAND ----------

df_py.filter(df_py.name.like('%oh%')).collect()

# COMMAND ----------

df_py.filter(df_py.name.startswith('mo')).collect()

# COMMAND ----------

from pyspark.sql import functions as F
df_py.select(df_py.name, F.when(df_py.a > 3, 1).when(df_py.b < 3, -1).otherwise(0)).show()

df = df_py
df[df.name.isin("mohit", "Mike")].collect()

df.select(df.name.substr(1, 3).alias("col")).collect()

df.filter(df.name.rlike('it$')).collect()

# COMMAND ----------

assert columns[0][0] == "prev_id",    "Expected column 0 to be \"prev_id\" but found \"" + columns[0][0] + "\"."
assert columns[0][1] == "int",    "Expected column 0 to be of type \"int\" but found \"" + columns[0][1] + "\"."

assert columns[1][0] == "curr_id",    "Expected column 1 to be \"curr_id\" but found \"" + columns[1][0] + "\"."
assert columns[1][1] == "int",        "Expected column 1 to be of type \"int\" but found \"" + columns[1][1] + "\"."

# COMMAND ----------

fil_DF = (df
  .drop("col_c")
  .filter( col("name") != "Main_Page")
  .filter( col("name") != "-")
  .filter( col("name").like("mo%") == False)
)
fil_DF.show(10, False)

# COMMAND ----------

firstRow = df.first()

print(firstRow)