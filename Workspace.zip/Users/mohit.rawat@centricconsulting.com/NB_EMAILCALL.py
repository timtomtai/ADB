# Databricks notebook source
# MAGIC %run /Users/mohit.rawat@centricconsulting.com/NB_EMAILER

# COMMAND ----------

# MAGIC %run /Users/mohit.rawat@centricconsulting.com/ETL_WITH_PYSPARK/etl_read_write_file

# COMMAND ----------


recipient = "mohit.rawat@centricconsulting.com, nitishkumar.sood@centricconsulting.com"
message = "This is the sample mail using send-grid from Databricks Notebook"
subject = "Regarding mail from DB Notebook"
#attachment = "/dbfs/databricks-datasets/README.md"
attachment = "/dbfs/mnt/containershareddna01/DATA_SOURCE.csv"
SendEmail(recipient,subject,message,attachment)

# COMMAND ----------

#recipient =  dbutils.secrets.get(scope = "scopedna01", key = "secretdna01")
recipient 
message = "Your message here"
subject = "Your subject here"

SendEmail(recipient,subject,message)

# COMMAND ----------





# COMMAND ----------

# MAGIC %sh ls -ltr /dbfs/