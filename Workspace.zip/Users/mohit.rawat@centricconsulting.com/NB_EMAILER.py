# Databricks notebook source
import smtplib
from email.mime.multipart import  MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from os.path import basename


# COMMAND ----------

# setting common variables
mail_from = 'mohit.rawat@centricconsulting.com'
accessId = dbutils.secrets.get(scope = "scopedna01", key = "secret-sendgrid-app-id")

def SendEmail(recipient, subject, message, attachment):
  msg = MIMEMultipart()
  msg['From'] = mail_from
  msg['To'] = recipient
  msg['Subject'] = subject
  mail_body = message
  msg.attach(MIMEText(mail_body))

  f = attachment
  with open(f, "rb") as fil:
       part = MIMEApplication(
           fil.read(),
           Name=basename(f)
       )
    # After the file is closed
       part['Content-Disposition'] = 'attachment; filename="%s"' % basename(f)
       msg.attach(part)
        
  server = smtplib.SMTP_SSL('smtp.sendgrid.net', 465)
  server.ehlo()
  server.login('apikey', accessId)
  server.sendmail(mail_from, recipient, msg.as_string())
  server.close()
  print("Mail sent successfully to server")


