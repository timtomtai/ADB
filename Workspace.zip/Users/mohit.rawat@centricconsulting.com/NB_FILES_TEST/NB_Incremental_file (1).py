# Databricks notebook source
# MAGIC %sql
# MAGIC 
# MAGIC Select * from scd_lastprocessed_date ;
# MAGIC #update scd_lastprocessed_date set processed_date =  '2014-10-01'

# COMMAND ----------

def incremental_filteration(SourcefilePath,format,date_column_index,datecolumn_format, **kwargs) :
    from pyspark.sql.functions import to_date
    #spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    delimiter = kwargs.get ('delimiter', None)
    header = kwargs.get ('header', None)
    
    try:
        #getting last processed date from delta table 
        output=spark.sql("select  processed_date from default.scd_lastprocessed_date")
        Last_processed_date = output.select("processed_date").collect()[0][0]

        #reading tge source data file
        df_file_read = spark.read.load(SourcefilePath,
                     format=format,  delimiter=delimiter, header=header)
        
        date_column_name = df_file_read.schema.names[date_column_index]
        
        df_file_read = df_file_read.filter(to_date(date_column_name, datecolumn_format) >= Last_processed_date)
        spark.sql("update default.scd_lastprocessed_date set processed_date = current_date() ")
        
        return df_file_read 
    except Exception as e:
        print("Error in Reading Source File")
    
    

    
    

# COMMAND ----------



# COMMAND ----------

df_sales.filter(df_sales["Order Date"] =='2014-10-28').show()

# COMMAND ----------

df_file_read = spark.read.load("/FileStore/tables/MODATE-2.csv",format="csv", header = "true", delimiter = ",")

# COMMAND ----------

df_sales = incremental_filteration("/FileStore/tables/Sales_Records.csv",format="csv", header = "true", delimiter = ",", date_column_index = 5,datecolumn_format = "M/d/y")
df_sales.show()


# COMMAND ----------

# MAGIC %fs head /FileStore/tables/Sales_Records.csv

# COMMAND ----------

#df_sales = Scd_filteration("/FileStore/tables/Sales_Records.csv",format="csv", header = "true", delimiter = ",", date_column_index = 5,datecolumn_format = "m/dd/yyyy")
#df_sales.show()
from pyspark.sql import functions as f
from pyspark.sql.functions import to_date
#from pyspark.sql.functions import unix_timestamp, from_unixtime
#spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")
df_sales = df_file_read 
data = df_sales
df = df_sales
date_column_name = "Order Date"

output=spark.sql("select  processed_date from default.scd_lastprocessed_date")
Last_processed_date = output.select("processed_date").collect()[0][0]
#Last_processed_date = "2014-10-01"
print(Last_processed_date)
#df_sales = df_sales.filter(df_sales[date_column_name] >= Last_processed_date)
#df_sales.show()
#df = data.filter(to_date("Order Date")> ("2015-03-14")) 

#df = data.filter(to_date(f.col("Order_Date")) < f.unix_timestamp(f.lit('2014-11-01 00:00:00')).cast('timestamp'))

#df.select(to_date(df.Ship_Date, 'MM/dd/yyyy').alias('dt')).collect() -----Legacy Error


df.show()
print(df["Ship_Date"])
#df2 = df.withColumn("Ship_Date",to_date(df["Ship_Date"], 'MM/dd/yyyy'))
#df.select(from_unixtime(unix_timestamp(df.Ship_Date, 'MM/dd/yyyy')).alias('dt')).collect()

#df = data.filter(from_unixtime(unix_timestamp(df.Ship_Date, 'MM/dd/yyyy')) < f.unix_timestamp(f.lit('2014-11-01 00:00:00')).cast('timestamp'))
date_column_name = "Ship_Date"
#df = data.filter(from_unixtime(unix_timestamp(df[date_column_name], 'MM/dd/yyyy')) < Last_processed_date)
df = data.filter(to_date(date_column_name, 'M/d/yyyy') >= Last_processed_date)
#from_unixtime(unix_timestamp('date_str', 'MM/dd/yyy')).alias('date')

#people.filter("Age > 24")
#.withColumn("column1", to_date(DF["column1"], 'yyyyMMdd'))
#df_file_read = df_sales.withColumn(date_column_name,to_date(df_file_read[date_column_name], datecolumn_format))
#df2 = df_sales.filter(df_sales["Order Date"] >='2014-10-28').select("order Date")

df.show()

# COMMAND ----------

#df_sales.select("Order Date").dtypes
from pyspark.sql.functions import *
spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

date_column_name = "Order Date"
date_format ='m/dd/yyyy'

#df1 = df_sales.withColumn('OrderDate',to_date(df_sales[date_column_name], 'yyyy-MM-dd'))

df_sales = df_sales.withColumn('Order Date',to_date(df_sales[date_column_name], date_format))
df_sales.show()

#df_sales.filter(df_sales[date_column_name] >= '2012-01-22').show

#date_column_name = 'Order Date'
#df_sales.where(date_column_name.date_column_name =='2010-06-27').show()

#df_sales.filter(df_sales[date_column_name] >= '2010-06-27').show() 


# COMMAND ----------

output=spark.sql("select  processed_date from default.scd_lastprocessed_date")

Last_processed_date = output.select("processed_date").collect()[0][0]

date_column_name = "Order Date"
df_sales = df_sales.filter(df_sales[date_column_name] >= Last_processed_date)
df_sales.show()


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from scd_lastprocessed_date

# COMMAND ----------


