# Databricks notebook source
# Read Event Hub's stream
conf = {}
connectionString = "Endpoint=sb://centrictraining12345678.servicebus.windows.net/;SharedAccessKeyName=EH_POLICY;SharedAccessKey=oElTj+K098HLWoUNVjtJT34K6GL8cPl62dBoy9BNwr0=;EntityPath=databricks-demo-eventhub"

conf['eventhubs.connectionString'] = sc._jvm.org.apache.spark.eventhubs.EventHubsUtils.encrypt(connectionString)
read_df = (
  spark
    .readStream
    .format("eventhubs")
    .options(**conf)
    .load()
)

# COMMAND ----------

# Write streams into memory
from pyspark.sql.types import *
import  pyspark.sql.functions as F

read_schema = StructType([
  StructField("event_name", StringType(), True),
  StructField("event_time", StringType(), True)])
decoded_df = read_df.select(F.from_json(F.col("body").cast("string"), read_schema).alias("payload"))

query1 = (
  decoded_df
    .writeStream
    .format("memory")
    .queryName("read_hub")
    .start()
)

# COMMAND ----------

# MAGIC %sql select payload.event_name, payload.event_time from read_hub

# COMMAND ----------

from pyspark.sql import Row

write_schema = StructType([StructField("body", StringType())])
write_row = [Row(body="{\"event_name\":\"Open\",\"event_time\":\"1540601000\"}")]
write_df = spark.createDataFrame(write_row, write_schema)

(write_df
  .write
  .format("eventhubs")
  .options(**conf)
  .save())

# COMMAND ----------

for s in spark.streams.active:
    s.stop()