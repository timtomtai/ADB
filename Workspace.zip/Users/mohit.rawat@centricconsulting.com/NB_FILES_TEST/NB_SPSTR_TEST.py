# Databricks notebook source
dbutils.fs.rm("/tmp/structured-streaming/events", recurse=True)
dbutils.fs.put(
  "/tmp/structured-streaming/events/file01.json",
  """{"event_name":"Open","event_time":1540601000}
{"event_name":"Open","event_time":1540601010}
{"event_name":"Fail","event_time":1540601020}
{"event_name":"Open","event_time":1540601030}
{"event_name":"Open","event_time":1540601040}
{"event_name":"Open","event_time":1540601050}
{"event_name":"Open","event_time":1540601060}
{"event_name":"Fail","event_time":1540601070}
{"event_name":"Open","event_time":1540601080}
{"event_name":"Open","event_time":1540601090}
""", True)

# COMMAND ----------

from pyspark.sql.types import *
from pyspark.sql.functions import *

read_schema = StructType([
  StructField("event_name", StringType(), True),
  StructField("event_time", TimestampType(), True)])
read_df = (
  spark
    .readStream                       
    .schema(read_schema)
    .option("maxFilesPerTrigger", 1)  # one file at a time
    .json("/tmp/structured-streaming/events/")
)

# COMMAND ----------

# Write results in memory
query1 = (
  read_df
    .writeStream
    .format("memory")
    .queryName("read_simple")
    .start()
)

# COMMAND ----------

# MAGIC 
# MAGIC %sql select event_name, date_format(event_time, "MMM-dd HH:mm") from read_simple order by event_time

# COMMAND ----------

dbutils.fs.put(
  "/tmp/structured-streaming/events/file02.json",
  """{"event_name":"Open","event_time":1540601100}
{"event_name":"Open","event_time":1540601110}
{"event_name":"Fail","event_time":1540601120}
{"event_name":"Open","event_time":1540601130}
{"event_name":"Open","event_time":1540601140}
{"event_name":"Open","event_time":1540601150}
{"event_name":"Open","event_time":1540601160}
{"event_name":"Fail","event_time":1540601170}
{"event_name":"Open","event_time":1540601180}
{"event_name":"Open","event_time":1540601190}
""", True)

# COMMAND ----------

# Windowing analysis
group_df = (                 
  read_df
    .groupBy(
      read_df.event_name, 
      window(read_df.event_time, "1 minute"))
    .count()
)

# COMMAND ----------

query2 = (
  group_df
    .writeStream
    .format("memory")
    .queryName("read_counts")
    .outputMode("complete")
    .start()
)

# COMMAND ----------

# MAGIC 
# MAGIC %sql select event_name, date_format(window.end, "MMM-dd HH:mm") as event_time, count from read_counts order by event_time, event_name

# COMMAND ----------

dbutils.fs.put(
  "/tmp/structured-streaming/events/file03.json",
  """{"event_name":"Open","event_time":1540601200}
{"event_name":"Open","event_time":1540601210}
{"event_name":"Fail","event_time":1540601220}
{"event_name":"Open","event_time":1540601230}
{"event_name":"Open","event_time":1540601240}
{"event_name":"Open","event_time":1540601250}
{"event_name":"Open","event_time":1540601260}
{"event_name":"Fail","event_time":1540601270}
{"event_name":"Open","event_time":1540601280}
{"event_name":"Open","event_time":1540601290}
""", True)

# COMMAND ----------

for s in spark.streams.active:
    s.stop()
    print(s)