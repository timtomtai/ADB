# Databricks notebook source
import pandas as pd
import numpy as np

# COMMAND ----------

# MAGIC %fs ls /mnt/containershareddna01

# COMMAND ----------

df = pd.read_csv('/dbfs/mnt/containershareddna01/BL-Flickr-Images-Book.csv' )

#usecols=to_drop
df.head()

# COMMAND ----------

to_drop = ['Edition Statement',
           'Corporate Author',
           'Corporate Contributors',
           'Former owner',
           'Engraver',
           'Contributors',
           'Issuance type',
           'Shelfmarks']

# COMMAND ----------


df.drop(to_drop, inplace=True, axis=1)

# COMMAND ----------

 selected_df =  df[to_drop]
  
selected_df.head()

# COMMAND ----------

#If you know in advance which columns you’d like to retain, another option is to pass them to the usecols argument of pd.read_csv.

# COMMAND ----------

df['Identifier'].is_unique

# COMMAND ----------

df = df.set_index('Identifier')
df.head()

# COMMAND ----------

We can access each record in a straightforward way with loc[]. Although loc[] may not have all that intuitive of a name, it allows us to do label-based indexing, which is the labeling of a row or record without regard to its position:

# COMMAND ----------

df.get_dtype_counts()

# COMMAND ----------

df.loc[1905:, 'Date of Publication'].head(10)

# COMMAND ----------

extr = df['Date of Publication'].str.extract(r'^(\d{4})', expand=False)
extr.head()

# COMMAND ----------

df['Date of Publication'] = pd.to_numeric(extr)
df['Date of Publication'].dtype

# COMMAND ----------

df['Date of Publication'].isnull().sum() / len(df)

# COMMAND ----------

pub = df['Place of Publication']

pub.type()

# COMMAND ----------

london = pub.str.contains('London')

type(london)

# COMMAND ----------

london[1:5]

# COMMAND ----------


oxford = pub.str.contains('Oxford')


# COMMAND ----------

nm1 = np.where([london],[oxford], pub)

print(nm1)



# COMMAND ----------

df['Place of Publication'] = np.where(london, 'London',
                                      np.where(oxford, 'Oxford',
                                               pub.str.replace('-', ' ')))

# COMMAND ----------



# COMMAND ----------

df.head(100)

# COMMAND ----------

