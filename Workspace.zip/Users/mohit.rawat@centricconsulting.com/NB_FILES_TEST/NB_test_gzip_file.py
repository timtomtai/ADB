# Databricks notebook source
df = spark.read.csv("/FileStore/tables/pagecounts_20071209_180000.gz") 

df.count()
