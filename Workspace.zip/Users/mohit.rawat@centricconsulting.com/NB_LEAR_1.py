# Databricks notebook source
dbutils.secrets.listScopes()

dbutils.secrets.list("SelectSires-KV-dev")
