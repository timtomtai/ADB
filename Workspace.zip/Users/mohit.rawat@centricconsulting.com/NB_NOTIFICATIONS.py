# Databricks notebook source
import smtplib
from email.mime.multipart import  MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
from os.path import basename
 
mail_from = 'mohit.rawat@centricconsulting.com'
mail_to = 'mohit.rawat@centricconsulting.com'

accessId = dbutils.secrets.get(scope = "scopedna01", key = "secret-sendgrid-app-id")

msg = MIMEMultipart()
msg['From'] = mail_from
msg['To'] = mail_to
msg['Subject'] = "Subject that is meaningful to the recipient"
mail_body = "Something happened in your databricks notebook"
msg.attach(MIMEText(mail_body))

f = "/dbfs/databricks-datasets/README.md"
with open(f, "rb") as fil:
    part = MIMEApplication(
        fil.read(),
        Name=basename(f)
    )
# After the file is closed
part['Content-Disposition'] = 'attachment; filename="%s"' % basename(f)
msg.attach(part)
        
server = smtplib.SMTP_SSL('smtp.sendgrid.net', 465)
server.ehlo()
server.login('apikey', accessId)
server.sendmail(mail_from, mail_to, msg.as_string())
server.close()
print("Mail sent successfully to server")
