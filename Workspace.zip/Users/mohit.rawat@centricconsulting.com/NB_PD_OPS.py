# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## Overview
# MAGIC 
# MAGIC This notebook will show you how to create and query a table or DataFrame that you uploaded to DBFS. [DBFS](https://docs.databricks.com/user-guide/dbfs-databricks-file-system.html) is a Databricks File System that allows you to store data for querying inside of Databricks. This notebook assumes that you have a file already inside of DBFS that you would like to read from.
# MAGIC 
# MAGIC This notebook is written in **Python** so the default cell type is Python. However, you can use different languages by using the `%LANGUAGE` syntax. Python, Scala, SQL, and R are all supported.

# COMMAND ----------

# File location and type
file_location = "/FileStore/tables/PEOPLE.csv"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
people = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(people)

people.show()

# COMMAND ----------

people.registerTempTable('dpeople_tempTable');



# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC Select * from dpeople_tempTable

# COMMAND ----------

file_location = "/FileStore/tables/DEPARTMENT.csv"
dept = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(dept)

# COMMAND ----------

from pyspark.sql.functions import col, avg
from pyspark.sql import functions as F
fil_df = people.filter("Age > 24").join(dept, people.Dept_Id == dept.Id).groupBy(dept.Name, people.Gender).agg(F.avg(people.Salary),F.max(people.Age))

fil_df.show()
#.agg(avg(people.Salary), max(people.Age))

# COMMAND ----------

schemaDDL = schemaDDL = "NAME STRING, AGE STRING, GENDER  STRING, SALARY FLOAT, DEPT_ID FLOAT"
sourcePath = "/FileStore/tables/PEOPLE.csv"

countsDF = (spark.read
  .format("csv")
  .option("header", "true")
  .schema(schemaDDL)
  .load(sourcePath)
  .groupBy("DEPT_ID", "GENDER").count()
  .withColumnRenamed("DEPT_ID", "DEPARTMENT")
  .orderBy("DEPARTMENT")
)
countsDF.show()


# COMMAND ----------

from pyspark.sql.functions import *

# This uses the col(..) function
columnC = col("Age")

# This uses the expr(..) function which parses an SQL Expression
columnD = expr("salary + 1")

# This uses the lit(..) to create a literal (constant) value.
columnE = lit("abc")
sortedDescDF = (people
  .orderBy( col("Age").desc() )
)  
sortedDescDF.show(10, False)
