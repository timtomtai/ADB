# Databricks notebook source
import requests
import json

options = { 'url' : url, 'method' : 'GET', 'readTimeout' : '10000', 'connectionTimeout' : '2000', 'partitions' : '10'}
    
    

# COMMAND ----------

url = "https://jsonplaceholder.typicode.com/posts/"

print(headers)
res = requests.get(url)
 
print(res )   
data = res.json()
  
print(data)
    


# COMMAND ----------

# Create a new resource
response = requests.post('https://httpbin.org/post', data = {'test':'test1'})
print(response ) 
# Update an existing resource
#requests.put('https://httpbin.org/put', data = {'key':'value'})

# COMMAND ----------

# Create a new resource
dat = { "userId": 2,    "id": 2,    "title": "Mohit Test",    "body": "Total good post"  }
response = requests.post('https://jsonplaceholder.typicode.com/posts', data = { "title": "Mohit Test",    "body": "Total good post"  })
print(response ) 

print( response.json() )

# Update

response = requests.put('https://jsonplaceholder.typicode.com/posts/1', data = { "title": "Mohit Test",    "body": "Total good post"  })
print(response ) 

print( response.json() )
# Update an existing resource
#requests.put('https://httpbin.org/put', data = {'key':'value'})

# COMMAND ----------

# importing the requests library
import requests
  
# api-endpoint
URL = "https://maps.googleapis.com/maps/api/geocode/json"
  
# location given here
#location = "delhi technological university"
location = "Sanatan Dharam Temple, Sector 19, Noida"
 
# defining a params dict for the parameters to be sent to the API
PARAMS = {'address':location, 'key': ''}
  
# sending get request and saving the response as response object
r = requests.get(url = URL, params = PARAMS)
  
# extracting data in json format
data = r.json()
  
print(data)
# extracting latitude, longitude and formatted address 
# of the first matching location
latitude = data['results'][0]['geometry']['location']['lat']
longitude = data['results'][0]['geometry']['location']['lng']
formatted_address = data['results'][0]['formatted_address']
  
# printing the output
print("Latitude:%s\nLongitude:%s\nFormatted Address:%s"
      %(latitude, longitude,formatted_address))

# COMMAND ----------

# MAGIC %sh
# MAGIC URI=https://sashareddna01.blob.core.windows.net/containershareddna01/test3.txt
# MAGIC 
# MAGIC echo $URI
# MAGIC SAS='?sv=2020-08-04&ss=bfqt&srt=sco&sp=rwlacutfx&se=2022-01-05T00:53:54Z&st=2022-01-04T16:53:54Z&spr=https&sig=ex7dyeo8kc0ODrmUDHrQraRbwbx%2FoD7QonUo7EezDJM%3D'
# MAGIC 
# MAGIC echo $SAS
# MAGIC 
# MAGIC URL=${URI}${SAS} 
# MAGIC 
# MAGIC echo $URL
# MAGIC 
# MAGIC curl -H "x-ms-blob-type: BlockBlob" -X PUT -T "/dbfs/databricks-datasets/README.md" $URL

# COMMAND ----------




# COMMAND ----------

files = {'upload_file': open('/dbfs/databricks-datasets/README.md','rb')}
header = {'x-ms-blob-type': 'BlockBlob' }
response = requests.put('https://sashareddna01.blob.core.windows.net/containershareddna01/test2.txt?sv=2020-08-04&ss=bfqt&srt=sco&sp=rwlacutfx&se=2022-01-05T00:53:54Z&st=2022-01-04T16:53:54Z&spr=https&sig=ex7dyeo8kc0ODrmUDHrQraRbwbx%2FoD7QonUo7EezDJM%3D', files=files, headers = header)

print(response)


# COMMAND ----------

PS C:\Users\mohit.rawat> $header = @{                                                                                   >>     'x-ms-blob-type'='BlockBlob'
>> }
PS C:\Users\mohit.rawat> $headers = $header | ConvertTo-Json
PS C:\Users\mohit.rawat> $headers
{
    "x-ms-blob-type":  "BlockBlob"
}
PS C:\Users\mohit.rawat> $file = "C:\Mohit\university_towns.txt"
PS C:\Users\mohit.rawat> $URI = "https://sashareddna01.blob.core.windows.net/containershareddna01/test_powershell.txt?sv=2020-08-04&ss=bfqt&srt=sco&sp=rwlacutfx&se=2022-01-05T00:53:54Z&st=2022-01-04T16:53:54Z&spr=https&sig=ex7dyeo8kc0ODrmUDHrQraRbwbx%2FoD7QonUo7EezDJM%3D"
PS C:\Users\mohit.rawat> #Upload File
PS C:\Users\mohit.rawat> Invoke-RestMethod -Method PUT -Uri $URI -Headers $header -InFile $file

PS C:\Users\mohit.rawat>

$header = @{
    'x-ms-blob-type'='BlockBlob'
}
$headers = $header | ConvertTo-Json

?sv=2020-08-04&ss=bfqt&srt=o&sp=rwdlacutfx&se=2022-01-05T13:36:43Z&st=2022-01-05T05:36:43Z&spr=https&sig=TR43QcnxnX56imjY6%2Bbr69jhCmjHXBsGhyhrSZkVXUw%3D

# COMMAND ----------

new SAS

?sv=2020-08-04&ss=bfqt&srt=o&sp=rwlacutfx&se=2022-01-05T14:42:43Z&st=2022-01-05T06:42:43Z&spr=https&sig=mWInWZznCtNxxMWqIQtALClFuh0glAEshWcERj2dE7U%3D