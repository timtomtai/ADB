# Databricks notebook source
# MAGIC %sql
# MAGIC drop table sur_key_tab;
# MAGIC create table sur_key_tab
# MAGIC (
# MAGIC SK BIGINT ,
# MAGIC ID BIGINT,
# MAGIC RANDOM_NUM DOUBLE
# MAGIC ) USING DELTA
# MAGIC location '/tmp/tables/mr_sur_key_tab';

# COMMAND ----------

# MAGIC %sql
# MAGIC With sample_data(
# MAGIC select ID, rand() RANDOM_NUM
# MAGIC FROM RANGE(0, 100000, 1, 2)
# MAGIC )
# MAGIC 
# MAGIC insert into sur_key_tab
# MAGIC select monotonically_increasing_id () + 1 + (select max(SK) from sur_key_tab)as SK , A.* from sample_data A

# COMMAND ----------

# MAGIC %sql
# MAGIC Select count(*), count(distinct (SK)) from sur_key_tab

# COMMAND ----------

from pyspark.sql.types import LongType, StructField, StructType

df2 = spark.sql("select ID , RANDOM_NUM from sur_key_tab")

df3 = df2.rdd.zipWithIndex()

offset = spark.sql("select max(SK) from sur_key_tab").collect()[0][0] + 1 
print (offset)
colName = "SURROGATE_KEY"
new_schema = StructType(
        [StructField(colName, LongType(),True)]  #new added field
        + df2.schema.fields) 

new_rdd = df3.map(lambda row: ([row[1]+offset] + list(row[0])))
    
df_final= spark.createDataFrame(new_rdd, new_schema)

df_final.show(1000)