# Databricks notebook source
# MAGIC %fs ls /databricks-datasets/airlines

# COMMAND ----------

airlines = DeltaTable.forPath(spark, '/databricks-datasets/airlines')