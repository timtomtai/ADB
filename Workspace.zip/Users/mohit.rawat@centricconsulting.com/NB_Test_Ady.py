# Databricks notebook source
df_cause_death_france.registerTempTable('df_cause_death_france_tempTable');



spark.sql('select SEX, count(1) as counter from df_cause_death_france_tempTable group by SEX').show();