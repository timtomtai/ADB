# Databricks notebook source
# Example 1 - returning data through temporary views.
# You can only return one string using dbutils.notebook.exit(), but since called notebooks reside in the same JVM, you can
# return a name referencing data stored in a temporary view.

## In callee notebook
spark.range(5).toDF("value").createOrReplaceGlobalTempView("my_data")
dbutils.notebook.exit("my_data")
#df3 = spark.sql("select * from global_temp.people")
#df2 = sqlContext.sql("select * from global_temp.my_data")
#df2.show()

# COMMAND ----------

try:
  thisiswrong
except Exception as e:
  print("error")