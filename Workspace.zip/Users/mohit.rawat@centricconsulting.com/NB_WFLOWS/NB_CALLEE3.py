# Databricks notebook source
import json
dbutils.notebook.exit(json.dumps({
  "status": "OK",
  "table": "my_data"
}))