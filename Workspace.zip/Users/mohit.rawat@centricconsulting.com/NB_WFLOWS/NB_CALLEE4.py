# Databricks notebook source

dbutils.widgets.text("var1","var1default","var1Label")
dbutils.widgets.text("var2","var2default","var2Label")
print (dbutils.widgets.get("var1"))
print (dbutils.widgets.get("var2"))