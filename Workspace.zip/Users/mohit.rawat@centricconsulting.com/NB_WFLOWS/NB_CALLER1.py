# Databricks notebook source
returned_table = dbutils.notebook.run("/Users/mohit.rawat@centricconsulting.com/NB_WFLOWS/NB_CALLEE1", 60)
global_temp_db = spark.conf.get("spark.sql.globalTempDatabase")
display(table(global_temp_db + "." + returned_table))

#df3 = spark.sql("select * from global_temp.people")
#df2 = sqlContext.sql("select * from global_temp.my_data")

# COMMAND ----------

