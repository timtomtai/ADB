# Databricks notebook source
returned_table = dbutils.notebook.run("/Users/mohit.rawat@centricconsulting.com/NB_WFLOWS/NB_CALLEE2", 60)

display(spark.read.parquet(returned_table))