# Databricks notebook source
import json
#returned_table = dbutils.notebook.run("/Users/mohit.rawat@centricconsulting.com/NB_WFLOWS/NB_CALLEE2", 60)

## In caller notebook
result = dbutils.notebook.run("/Users/mohit.rawat@centricconsulting.com/NB_WFLOWS/NB_CALLEE3", 60)
print(json.loads(result))