# Databricks notebook source
dbutils.notebook.run("/Users/mohit.rawat@centricconsulting.com/NB_WFLOWS/NB_CALLEE4", 60, {"var1": "data", "var2": "data2"})