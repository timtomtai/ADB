# Databricks notebook source
# MAGIC %run /Users/mohit.rawat@centricconsulting.com/Scheduled_Run $VarA="Mohit"

# COMMAND ----------

