# Databricks notebook source
dbutils.widgets.text("VarA","Mohit","")
V_name = dbutils.widgets.get("VarA")
print (V_name)
#getArgument("VarName", "Rohit")  

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from test_delta_table_MR where Name= getArgument('VarA')

# COMMAND ----------

# MAGIC %python 
# MAGIC spark.conf.set('personal.name',"Rohit")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from test_delta_table_MR where Name= '${personal.name}'

# COMMAND ----------

spark.range(5).toDF("value").write.parquet("dbfs:/tmp/results/my_data_adf")