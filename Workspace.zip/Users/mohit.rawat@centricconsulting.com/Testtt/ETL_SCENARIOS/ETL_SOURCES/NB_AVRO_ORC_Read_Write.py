# Databricks notebook source
# MAGIC %md
# MAGIC #AVRO & ORC Files
# MAGIC ### Reading data from ORC and AVRO Files##
# MAGIC -  We re-used the generic readSourceFile function which was created for reading csv , parquet & json file
# MAGIC 
# MAGIC ### Writing  DF as AVRO & ORC file directly ##
# MAGIC 
# MAGIC ### Writing DFs with partioning and showing demo for partition pruning 
# MAGIC 
# MAGIC Data Read without partition pruning i.e. all/full file scan ! 
# MAGIC <img src ='/files/tables/Databricks_Shell___Details_for_Query_691.png'>
# MAGIC 
# MAGIC 
# MAGIC Data Read  partition pruning i.e. only needed partition scan/read !
# MAGIC <img src ='/files/tables/Databricks_Shell___Details_for_Query_50.png'>

# COMMAND ----------

def readSourceFile(filePath,format, **kwargs) :
    
    
    schema = kwargs.get('schema', None)
    badRecordsPath = kwargs.get ('badRecordsPath', None)
    delimiter = kwargs.get ('delimiter', None)
    pathGlobFilter = kwargs.get ('pathGlobFilter', None)
    header = kwargs.get ('header', None)
    badRecordsPath = kwargs.get ('badRecordsPath', None)
    multiline = kwargs.get ('multiline', None)
    print(schema)
    try:
        
        
        df_file_read = spark.read.load(filePath,
                     format=format, schema=schema, delimiter=delimiter, header=header, badRecordsPath=badRecordsPath, multiline=multiline)
        return df_file_read
        
    except Exception as e:
        print("Error in Reading Source File")

# COMMAND ----------

# Pushing a orc file 
df1 = readSourceFile ("/FileStore/tables/ORC_File_Test", "orc")

df1.show()


# COMMAND ----------

# Pushing a avro file 
df1 = readSourceFile ("/FileStore/tables/AVRO_File_Test", "com.databricks.spark.avro")

df1.show()

# COMMAND ----------

#Generic - Reading CSV , writing as avro & orc 


df= spark.read.csv("/FileStore/tables/Data_Validation_File.csv",header = "true", inferSchema ="false")

df.show()

df.write.mode("overwrite").orc("/FileStore/tables/ORC_File_Test")

df.write.mode("overwrite").format("avro").save("/FileStore/tables/AVRO_File_Test")

#Generic - Reading avro & orc Files - Even without header the Dataframes have the heading/field name
df_orc= spark.read.orc("/FileStore/tables/ORC_File_Test")
df_avro=spark.read.format("com.databricks.spark.avro").option("header","true").load("/FileStore/tables/AVRO_File_Test")

df_orc.show()
df_avro.show()

# COMMAND ----------

# Partition Pruning 

#Write with partition
df.write.mode("overwrite").format("parquet").partitionBy("DepID").save("/FileStore/tables/ParquetPath/Parquet-Partition-File")
df.write.mode("overwrite").format("parquet").partitionBy("DepID").option("path","/FileStore/tables/ParquetPath/table1").saveAsTable("Parquet_Partition_Table")
#Write without partition
df.write.mode("overwrite").format("parquet").option("path","/FileStore/tables/ParquetPath/table2").saveAsTable("Parquet_Partition_Table2")


# COMMAND ----------

#Read the filtered data on partition key
df_part_prun= spark.read.parquet("/FileStore/tables/ParquetPath/table1").filter("DepID < 1")

# COMMAND ----------

df_part_prun.explain(True)
# With PartitionFilters: [isnotnull(DepID#967), (DepID#967 < 1)] it reads the necessary partition only

# COMMAND ----------

#Creating temp view on partitioned file
spark.read.format("parquet").load("/FileStore/tables/ParquetPath/table1/").createOrReplaceTempView("store_sales")

# COMMAND ----------

#Creating temp view on non-partitioned file
spark.read.format("parquet").load("/FileStore/tables/ParquetPath/table2/").createOrReplaceTempView("store_sales2")

# COMMAND ----------

#Reading data from view created on top of partition 
spark.sql("select * from store_sales where DepID <1").collect()

# COMMAND ----------

#Reading data from view created on non-partitioned path
spark.sql("select * from store_sales2 where DepID <1").collect()

# COMMAND ----------

