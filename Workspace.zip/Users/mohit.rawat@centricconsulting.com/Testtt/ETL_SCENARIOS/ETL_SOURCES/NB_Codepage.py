# Databricks notebook source
import os    
from chardet import detect
## input parameter is source file
srcfile="/dbfs/FileStore/tables/oss/Codecheck.txt"

# function to get file encoding type
def get_encoding_type(file):
    with open(file, 'rb') as f:
        rawdata = f.read()
    return detect(rawdata)['encoding']

## Call the function
from_codec = get_encoding_type(srcfile)
print(from_codec)

# COMMAND ----------

## reading source file
import codecs
source = codecs.open("/dbfs/FileStore/tables/oss/Codecheck.txt","r","iso-8859-1")
source.read()



# COMMAND ----------

## encode decode function
import codecs
source = codecs.open("/dbfs/FileStore/tables/oss/Codecheck.txt","r","iso-8859-1")
rdd=source.read().encode("utf-8")
print(rdd)
rdd.decode("utf-8")

# COMMAND ----------

## input parameters
srcfile="/dbfs/FileStore/tables/oss/Codecheck.txt"
newFilename= "/dbfs/FileStore/tables/oss/Codecheck1.txt"
encoding_from='iso-8859-1'

## function to create target file with a specified codepage
def correctSubtitleEncoding(filename, newFilename, encoding_from, encoding_to='UTF-8'):
    with open(filename, 'r', encoding=encoding_from) as fr:
        with open(newFilename, 'w', encoding=encoding_to) as fw:
            for line in fr:
                fw.write(line[:-1]+'\r\n')
## Call fuction
correctSubtitleEncoding(srcfile,newFilename,encoding_from)
from_codec = get_encoding_type(newFilename)   ## function to check file codepage
print(from_codec)

# COMMAND ----------

## read target file
import codecs
target=codecs.open("/dbfs/FileStore/tables/oss/Codecheck1.txt","r","utf-8")
target.read()

# COMMAND ----------

import pandas as pd
pd.read_table('/dbfs/FileStore/tables/oss/Codecheck.txt',encoding='iso-8859-1')

# COMMAND ----------

import pandas as pd
pd.read_table('/dbfs/FileStore/tables/oss/Codecheck1.txt',encoding='utf-8')

# COMMAND ----------

df=spark.read.format('text').option("header","true").load('/FileStore/tables/oss/Codecheck1.txt',sep=',')
#spark.read.option("encoding", "iso-8859-1").text('/FileStore/tables/oss/Codecheck.txt')
df.show()