# Databricks notebook source
# Description : Function checkFlagFile is for checking for flag files that describe the data load completed from source.
# InPut Parameters : (filepath,filenameregex, flagext,waittime,retry ,**kwargs)
#       filePath: Path for reading the file.
#       filenameregex: file name with regex pattern . (if flag file need to check for specific set of files)
#       flagext : extension of flag file that supposed to come with actual data file.
#       waittime : time period for checking flag file again if it is not present
#       retry : no of times need to check for flag file if not present

#    Example to run this function : checkFlagFile ('/dbfs/FileStore/tables/TABTEST/Files','.*.csv$', '.txt',4,'5' )

# COMMAND ----------

def checkFlagFile (filepath,filenameregex, flagext,waittime,retry ,**kwargs) :	
	
    
    import os
    import re
    import time
    
    FLAG_FILE_FOUND = [];
    FLAG_FILE_NOT_FOUND = [];
    FLAG_FILE_FOUND.clear();
    FLAG_FILE_NOT_FOUND.clear();
    files_at_path= [filepath+"/"+files for files in os.listdir(filepath)]
    pattern_file = re.compile(r''+filenameregex+'')
    #print(pattern_file)
    files_at_path_regex_pattern = [s for s in files_at_path if pattern_file.match(s)]
    print('#CSV FILES# \n',files_at_path_regex_pattern)
    for file in files_at_path_regex_pattern:
        file_name = os.path.basename(file)
        flag_file_name = os.path.splitext(file)[0] + flagext
        #print (flag_file_name)
        #print(file_name)
        check_file = os.path.exists(flag_file_name)
        #print(check_file)
        if check_file is True:
            FLAG_FILE_FOUND.append(file_name)
            print(file_name , "is available for load")
        else:
            for i in retry:
                time.sleep(waittime)
                check_file = os.path.exists(flag_file_name)  
                if check_file is True:
                    FLAG_FILE_FOUND.append(file_name)
                    print(file_name , "is available for load") 
                    break
                else:
                    FLAG_FILE_NOT_FOUND.append(file_name)
                    print("Flag File not found for",file_name)
                    
    df_flag_file_found = FLAG_FILE_FOUND
    df_flag_file_not_found = FLAG_FILE_NOT_FOUND
    return df_flag_file_found , df_flag_file_not_found

# COMMAND ----------

checkFlagFile ('/dbfs/FileStore/tables/Files/Test','.*.csv$', '.txt',4,'5' )