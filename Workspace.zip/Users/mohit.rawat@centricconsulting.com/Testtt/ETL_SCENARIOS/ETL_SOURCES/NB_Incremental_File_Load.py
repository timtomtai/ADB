# Databricks notebook source
# Description : function[Incremental_File_load] is responsible to fetch data from the source file from the date cinfigured as in increamental table.
# InPut Parameters :
#       SourcefilePath: Path for reading the configuration file to read variables. 
#       format: file format of configuration file.
#       date_column_index: index of date column on which we need to filter the data, as per array logic from the source file.
#       datecolumn_format: need to specify the olrder and seperator of date column value from the source data for exapmple : (M/d/y) or (d/M/y) or (M-d-y) 
#       **kwargs: config file level parameters : delimiter, header
#
#if we are not having any records for specific source file in config table then funtion will consider'1900-01-01' as default last processing date.
# after every successful run of the function it will automatically update the last processing date to current dat of run in config table
#

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC Select * from scd_lastprocessed_date ;
# MAGIC --update scd_lastprocessed_date set processed_date =  '2017-01-01' , filepath = '/FileStore/tables/Sales_Records.csv'

# COMMAND ----------

def Incremental_File_load(SourcefilePath,format,date_column_index,datecolumn_format, **kwargs) :
    from pyspark.sql.functions import to_date
    #from pyspark.sql.functions import unix_timestamp, from_unixtime
    #spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    delimiter = kwargs.get ('delimiter', None)
    header = kwargs.get ('header', None)
    
    try:
        #getting last processed date from delta table 
        output=spark.sql('select  processed_date from default.scd_lastprocessed_date where filepath = "%s" ' % (SourcefilePath))
        
        #setting default value for last_processed_date
        if output.count()>0:
            Last_processed_date = output.select("processed_date").collect()[0][0]
        else:
            Last_processed_date = "1900-01-01"    
        #print(Last_processed_date)
        #reading tge source data file
        df_file_read = spark.read.load(SourcefilePath,
                     format=format,  delimiter=delimiter, header=header)
        
        date_column_name = df_file_read.schema.names[date_column_index]
        
        df_file_read = df_file_read.filter(to_date(date_column_name, datecolumn_format) >= Last_processed_date)
        
        #df_file_read = data.filter(from_unixtime(unix_timestamp(df_file_read.Ship_Date, 'MM/dd/yyyy')) < f.unix_timestamp(f.lit('2014-11-01 00:00:00')).cast('timestamp'))
        spark.sql('update default.scd_lastprocessed_date set processed_date = current_date()  where filepath = "%s" ' % (SourcefilePath) )
        
        return df_file_read 
    except Exception as e:
        print("Error in Reading Source File")
    
    

    
    

# COMMAND ----------

df_sales = Incremental_File_load("/FileStore/tables/Sales_Records.csv",format="csv", header = "true", delimiter = ",", date_column_index = 5,datecolumn_format = "M/d/y")
df_sales.show()
