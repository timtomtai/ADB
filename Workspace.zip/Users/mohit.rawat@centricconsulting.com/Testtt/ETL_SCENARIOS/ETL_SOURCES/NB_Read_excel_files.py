# Databricks notebook source
#sample data file path
sampleDataFilePath = "/mnt/containershareddna01/teamC_storage/Order History.xlsx"

#sheet address("'TabName'!'first_cell:last_cell(optional)'") in excel
Address1 = "'Holdings'!A1"
Address2 = "'Transactions'!A1"
Address3 = "'NAV'!E8:G17"

#read excelfile
df = spark.read.format("com.crealytics.spark.excel") \
.option("header", 'true') \
.option("inferSchema", 'true') \
.option("treatEmptyValuesAsNulls", "false") \
.option("dataAddress", Address1) \
.load(sampleDataFilePath)
display(df)

# This dataFrame will store and display the contents of "Transactions" sheet.
# To fetch "Holdings" tab we need to replace "Address1" in line 13.

# COMMAND ----------

#read excelfile
df_NAV = spark.read.format("com.crealytics.spark.excel") \
.option("header", 'true') \
.option("inferSchema", 'true') \
.option("treatEmptyValuesAsNulls", "false") \
.option("dataAddress", Address3) \
.load(sampleDataFilePath)
display(df_NAV)

# COMMAND ----------

df.filter(df['Scheme Name'].like("Mirae %") | df['Scheme Name'].like("Invesco %"))\
.select('Scheme Name').distinct().sort('Scheme Name').show(truncate=False)

# COMMAND ----------

from pyspark.sql.functions import *
df=df.withColumn('Scheme Name',regexp_replace('Scheme Name','- ',''))

# COMMAND ----------

df.filter(df['Scheme Name'].like("Mirae %") | df['Scheme Name'].like("Invesco %"))\
.select('Scheme Name').distinct().sort('Scheme Name').show(truncate=False)

# COMMAND ----------

df.select('Scheme Name').distinct().show(truncate=False)

# COMMAND ----------

df = df.withColumn("Date",df["Date"].cast('date'))
df.show()

# COMMAND ----------

from pyspark.sql import functions as F
df1=df.groupBy('Scheme Name').agg(F.sum('Units').alias('Total Units'),\
                              F.min('NAV').alias('Min NAV'),\
                               F.avg('NAV').alias('Average NAV'),\
                              F.max('NAV').alias('Max NAV'),\
                               F.sum('Amount').alias('Total Amount'),\
                              F.count('Scheme Name').alias('Premiums Count'))
df1.show()

# COMMAND ----------

df1 = df1.withColumn("Total Units",round(col('Total Units'),2))\
    .withColumn("Average NAV",round(col('Average NAV'),2))
df1.show()

# COMMAND ----------

#read excelfile
df_NAV = spark.read.format("com.crealytics.spark.excel") \
.option("header", 'true') \
.option("inferSchema", 'true') \
.option("treatEmptyValuesAsNulls", "false") \
.option("dataAddress", Address3) \
.load(sampleDataFilePath)
display(df_NAV)

# COMMAND ----------

df_NAV = df_NAV.withColumn("NAV",round(col('NAV'),2))\
    .withColumn("Date",df_NAV['Date'].cast("date"))
df_NAV.show()

# COMMAND ----------

#df1.select('Scheme Name').show(truncate=False)
df2=df1.join(df_NAV,df1['Scheme Name']==df_NAV['Scheme Name'],'inner')\
.select(df1['Scheme Name'],'Total Units','Min NAV','Average NAV','MAX NAV','Total Amount','NAV','Premiums Count')
df2.show()

# COMMAND ----------

df2 = df2.withColumn("Current_value",df2['Total Units']*df2['NAV'])
df2=df2.withColumn("Profit",df2['Current_value']-df2['Total Amount'])
df2=df2.withColumn("Profit %",df2['Profit']*100/df2['Total Amount'])
df2=df2.withColumn("Current_value",round(col('Current_value'),2))\
        .withColumn("Profit",round(col('Profit'),2))\
        .withColumn("Profit %",round(col('Profit %'),2))\
        .withColumn('Scheme Name',when(col("Scheme Name") == 'Nippon India Pharma Fund Direct Plan Growth Plan Growth Option Growth','Nippon India Pharma Fund Direct Plan').otherwise(df2['Scheme Name']))
df2.show()

# COMMAND ----------

df2.select('Scheme Name','Total Units','Min NAV','Average NAV','MAX NAV',col('NAV').alias('Current NAV'),'Total Amount','Current_value','Profit','Profit %').sort(col('Profit %').desc()).show(truncate=False)