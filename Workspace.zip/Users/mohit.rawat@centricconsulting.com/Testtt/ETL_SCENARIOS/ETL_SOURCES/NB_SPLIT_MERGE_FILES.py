# Databricks notebook source
# Function split_file() splits the file of any format into n no of files based on no of lines
# Input Parameters for function split_file() are as below:
outputbase = '/dbfs/FileStore/tables/oss/data'
inputfile='/dbfs/FileStore/tables/oss/test_txt.txt'
fileformat='.txt'
splitlen = 2


def split_file(outputbase,inputfile,fileformat,splitlen) :
    input= open(inputfile,'r').read().split('\n')
    i=1
    for lines in range(0,len(input),splitlen):
        outputdata=input[lines:lines+splitlen]
        output=open(outputbase+str(i)+fileformat,'w')
        output.write('\n'.join(outputdata))
        output.write('\n')
        output.close()
        i+=1
    print("file split operation has been successfull")

# Call the function
split_file(outputbase,inputfile,fileformat,splitlen);

# COMMAND ----------

# Split a csv file based on chunksize
# input parameter
bigfilepath =r'/dbfs/FileStore/tables/oss/merge_file.csv'
PartNum =2
OutputPath =r'/dbfs/FileStore/tables/oss/output'

## function body
def split_file_chunk(bigfilepath,PartNum,OutputPath):
    from webbrowser import get
    import pandas as pd;
    import os;

    with open(bigfilepath) as fp:
        for (count, _) in enumerate(fp, 1):
           pass

    #print(count)
    ChunkSizePart = (count)//PartNum
    #print(ChunkSizePart)
    for i,chunk in enumerate(pd.read_csv(bigfilepath, chunksize=ChunkSizePart)):
        chunk.to_csv(OutputPath+'chunk{}.csv'.format(i), index=False)
        
    print("file split operation has been successfull")
        
#call function
split_file_chunk(bigfilepath,PartNum,OutputPath)

# COMMAND ----------

# Function merge_file() merge the file of any format at a location into one files based on file pattern
# Input Parameters for function merge_file() are as below:
outputfile= '/dbfs/FileStore/tables/oss/data.txt'
sourcepath='/dbfs/FileStore/tables/oss/'
regex_txt = '.*data\d+\.txt$'

def merge_file(outputfile,sourcepath,regex_txt) :
    import os
    import shutil
    import re;

    with open(outputfile,'wb') as fdst:
        for subdir,dirs,files in os.walk(sourcepath):
            for file in files:
                filename=sourcepath+file
                pattern_txt = re.compile(r''+regex_txt+'')
                if pattern_txt.match(filename):
                    print('###txt REGEX OUT FILES#### \n',filename)
                    with open(filename,'rb') as fsrc:
                        shutil.copyfileobj(fsrc,fdst,1024*1024*10)
    print("file merge operation has been successfull")

# Call the function
fdst=merge_file(outputfile,sourcepath,regex_txt);

# COMMAND ----------

filePath='/dbfs/FileStore/tables/oss/data.txt'
#filePath='/dbfs/FileStore/tables/oss/test_txt.txt'
#filePath='/dbfs/FileStore/tables/oss/test_txt2.txt'
#filePath='/dbfs/FileStore/tables/oss/merge_file.csv'
#filePath='/dbfs/FileStore/tables/oss/outputchunk1.csv'
file=open(filePath,'r')
lines = file.read() 
lines

# COMMAND ----------

#Create multiple CSV files from existing CSV file based on column
#input Parameters:
inputfile="/dbfs/FileStore/tables/oss/SalesRecords.csv"
column_name='Car'
outputpath='/dbfs/FileStore/tables/oss/'
replace_symbols = ['>', '<', ':', '"', '/', '\\\\', '\|', '\?', '\*']
#function body
def Split_file_on_Column(inputfile,column_name,outputpath,replace_symbols) :
    import pandas as pd

    # DataFrame to read our input CSV file
    dataFrame = pd.read_csv(inputfile)
    #print("\nInput CSV file = \n", dataFrame)
    dataFrame[column_name] = (
        dataFrame[column_name].replace(replace_symbols, '', regex=True).str.strip()
    )
    # groupby to generate CSVs on the basis of Car names in Car column
    for (car), group in dataFrame.groupby([column_name]):
       group.to_csv(f'{outputpath}/{car}.csv', index=False)
    
    print("file split operation has been successfull")

#call function
Split_file_on_Column(inputfile,column_name,outputpath,replace_symbols)
#Displaying values of the generated CSVs
import pandas as pd
print("\nCSV 1 = \n", pd.read_csv("/dbfs/FileStore/tables/oss/SalesRecords.csv"))
print("\nCSV 1 = \n", pd.read_csv("/dbfs/FileStore/tables/oss/BMW.csv"))
print("\nCSV 2 = \n", pd.read_csv("/dbfs/FileStore/tables/oss/Lexus.csv"))
print("\nCSV 3 = \n", pd.read_csv("/dbfs/FileStore/tables/oss/Jaguar.csv"))

# COMMAND ----------

splitsize=29
filename='/dbfs/FileStore/tables/oss/merge_file.csv'
outputbase='/dbfs/FileStore/tables/oss/data'
format='.csv'
def split_file_size(splitsize,filename,outputbase,format) :
    import os
    try:
        file_size = os.stat(filename).st_size
        print (file_size)

        file_obj= open(filename,'r')
        for i in range( int(file_size/int(splitsize))):
            print(i)
            #print (file_obj.read(int(splitsize)).split('\n'))
            outputdata= file_obj.read(int(splitsize)).split('\n')
            print(outputdata)
            output=open(outputbase+str(i+1)+format,'w')
            print(output)
            output.write('\n'.join(outputdata))
            output.close()

        print("file split operation has been successfull")
       
    except exception:
            print("incorrect input parameter")
        
        
split_file_size(splitsize,filename,outputbase,format)