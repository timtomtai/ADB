# Databricks notebook source
# MAGIC %md
# MAGIC This function takes two mandatory inputs i.e. zip file Path and zip File Pattern
# MAGIC 
# MAGIC With additional extractFile parameter - we have option to extract ALL or a specific set of files(using optional filenameregex parameter) from the zip file
# MAGIC With extractDir we can define an new unzip folder path
# MAGIC with dfOutput parameter set as Y - we can return a data frame else a List of the unzipped files
# MAGIC 
# MAGIC It can take a zip file pattern but can an only one zip file at once, multiple zip file handling at once is not done in the function
# MAGIC 
# MAGIC unzip_files(zipFilePath, zipFilePattern, **kwargs)

# COMMAND ----------

def unzip_files(zipFilePath, zipFilePattern, **kwargs) :
    
    try:
        import os
        import shutil
        import zipfile
        import re
        import datetime
        import glob 
        from pyspark.sql.types import StructType
        
        #extract All file or Pattern
        extractFile = kwargs.get ('extractFile', 'All')
        extractDir = kwargs.get ('extractDir', '/dbfs/FileStore/tables/UNZIPFOLDER/')
        #output as DF or unzipped filename list
        dfOutput = kwargs.get ('dfOutput', 'N')
        
        filenameregex = kwargs.get ('filenameregex', '*')
            
        my_dir = zipFilePath
        
        my_zip = zipFilePath+zipFilePattern
        
        files_at_path= [zipFilePath+fd for fd in os.listdir(zipFilePath)]
          
        
        cntr = 0
        for item in files_at_path: 
            
            items = os.path.basename(item)
            zippattern_file =r''+zipFilePattern+''
            if re.match(zippattern_file, items):
                
                dt = datetime.datetime.now().isoformat()
                xdt = dt.replace(":", "-").replace(".", "-")
                     
        
        
        
                
                with zipfile.ZipFile(item) as zip_file:
                
                    for member in zip_file.namelist():
                        
                        #print(member)
                        if extractFile == "All" :
                            zip_file.extractall(extractDir)
                            #print (extractFile)
                            if dfOutput == "Y" :
                                extractDirDBFS = extractDir.replace('/dbfs','')
                                fullfilepath = extractDirDBFS+filenameregex
                                outputDF = spark.read.csv(fullfilepath)
                                return outputDF
                            else :
                                
                                #print (extractDir)
                                fullfilepath = extractDir+filenameregex
                                #print(fullfilepath)
                                outputList = glob.glob(fullfilepath)
                                return outputList
                        else:        
                            
                            filename = os.path.basename(member)
                            # skip directories
                            if not filename:
                                continue
                        
                            # copy file (taken from zipfile's extract)
                            #pattern_file = re.compile(r''+filenameregex+'')
                            pattern_file =r''+filenameregex+''
                            
                            #print(pattern_file)
                            if re.match(pattern_file,filename):
                                source = zip_file.open(member)
                                
                                uniquefname = member.replace("/", "-").replace(".","-")
                                tfname = "fileoutzipout"+uniquefname+xdt
                                
                                
                                target = open(os.path.join(extractDir, tfname), "wb")
                                
                                with source, target:
                                    shutil.copyfileobj(source, target)
                                    
                                    extractDirDBFS = extractDir.replace('/dbfs','')
                                    filepath = extractDirDBFS+tfname
                                    filepathList = extractDir+tfname
                                tempdf = spark.read.csv(filepath, sep=",")
                                
                                if (cntr == 0 ):
                                    outputDF = tempdf
                                    
                                    outputList = []
                                    outputList.append(filepathList)
                                    #print(outputList)
                                    
                                else :
                                    outputDF = outputDF.union(tempdf)
                                    
                                    outputList.append(filepathList)
                                    
                                    
                                cntr = cntr + 1
                            
                if (cntr == 0 ):
                    if dfOutput == "Y" :
                        outputDF = spark.createDataFrame([], StructType([]))
                        return outputDF
                    else :
                        outputList = []
                        return outputList
                else :
                    if dfOutput == "Y" :
                        
                        return outputDF
                    else :
                        
                        return outputList
                    
                    
                
    except Exception as e:
         print("Error in Unzipping File")

# COMMAND ----------

output = unzip_files("/dbfs/FileStore/tables/", "ZIP_FILE_TEST2.*zip" , dfOutput = "Y", extractFile="Spcl" , filenameregex= "POP.*csv", extractDir="/dbfs/FileStore/tables/UNZIPFOLDER/") 

output.show()

# COMMAND ----------

output = unzip_files("/dbfs/FileStore/tables/", "ZIP_FILE_TEST2.zip" , dfOutput = "N", extractFile="Spcl" , filenameregex= "POP3.*csv", extractDir="/dbfs/FileStore/tables/UNZIPFOLDER/") 

print(output)

# COMMAND ----------

output = unzip_files("/dbfs/FileStore/tables/", "ZIP_FILE_TEST3_\d{1,3}.zip$" , dfOutput = "Y", extractFile="Spcl" , filenameregex= "POP2.*csv", extractDir="/dbfs/FileStore/tables/UNZIPFOLDER/") 

output.show()


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC Spark can directly handle gzip files ,below given a example of the same

# COMMAND ----------

df_file_read = spark.read.load("/FileStore/tables/POP2_csv.gz", format="csv" ,delimiter=",")

df_file_read.show()