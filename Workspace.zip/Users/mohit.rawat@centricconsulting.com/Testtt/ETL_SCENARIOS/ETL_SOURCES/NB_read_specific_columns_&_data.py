# Databricks notebook source
# We are fetching few columns and specific data from table
# Table is already available in Azure database and we are making connection with database and fetching data

# COMMAND ----------

jdbcHostname = "dbserverdna01.database.windows.net"
jdbcDatabase = "dbdna01"
jdbcPort = 1433
username = 'admindna01'
password = 'admindna@01'
connectionProperties = {
  "user" : username,
  "password" : password,
  "driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"
  }
jdbcUrl = "jdbc:sqlserver://{0}:{1};database={2};user={3};password={4}".format(jdbcHostname, jdbcPort, jdbcDatabase, username, password)
Url = "jdbc:sqlserver://{0}:{1};database={2}".format(jdbcHostname, jdbcPort, jdbcDatabase)

# COMMAND ----------

df = spark.read.jdbc(url=Url, table="(select * from test_bs_1) test_data", properties=connectionProperties)
display(df)

# COMMAND ----------

# We can fetch specic columns and data by changing below script

df_from_table = spark.read.jdbc(url=Url, table="(select Name, Salary from test_bs_1 where Name = 'Rohit') test_data", properties=connectionProperties)
display(df_from_table)

# COMMAND ----------

#Below is an example for csv to fetch Name and Salary columns data where Name is equal to Rohit

# COMMAND ----------

# data in csv file
spark.read.csv("/mnt/containershareddna01/DATA_SOURCE.csv",header = "true").show()

# COMMAND ----------

# store specific data in dataframe
df_001= spark.read.csv("/mnt/containershareddna01/DATA_SOURCE.csv",header = "true").select("Name","Salary").filter("Name = 'Rohit'")
df_001.show()