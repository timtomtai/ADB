# Databricks notebook source

# Description : function[encryptfile] is responsible to encrypt data from a file present in blob storage.
# InPut Parameters : (filePath,keyFileName,encryptedFilePath)
#       filePath: Path for reading the file which needs to be encrypt.(Need to encrypt file only once, if you )
#       keyFileName: file name in which key will be stored. (Please pass unique key name everytime so that previous key will not replaced)
#       encryptedFilePath: Path and file name in which encrypted data will be stored.

# function is developed to accept above mentioned 3 parameters for now.
#


# COMMAND ----------

#Please read comment before passing input parameters in this function
def encryptfile(filePath,keyFileName,encryptedFilePath) :
    
    try:
        #!pip install cryptography
        
        # import required module
        from cryptography.fernet import Fernet
        # key generation
        key = Fernet.generate_key()
        
        # string the key in a file
        with open(keyFileName, 'wb') as filekey:
         filekey.write(key)
        
        # opening the key
        with open(keyFileName, 'rb') as filekey:
         key = filekey.read()
        
         
        # using the generated key
        fernet = Fernet(key)
  
        # opening the original file to encrypt
        with open(filePath, 'rb') as file:
         original = file.read()
      
        # encrypting the file
        encrypted = fernet.encrypt(original)

        # opening the file in write mode and 
        # writing the encrypted data
        with open(encryptedFilePath, 'wb') as encrypted_file:
         encrypted_file.write(encrypted)
        
    except Exception as e:
         print("Error while encrypting file")
        


# COMMAND ----------

import os
directory = os.getcwd()
print(directory)

# COMMAND ----------

encryptfile("/dbfs/mnt/containershareddna01/Covid_Ohio_state_2.csv",'keyfile.key',"/dbfs/mnt/containershareddna01/Covid_Ohio_state_2.csv")

# COMMAND ----------


# Description : function[decryptfile] is responsible to decrypt data from encrypted file present in blob storage.
# InPut Parameters : (filePath,keyFileName,decryptedFilePath)
#       filePath: Path for reading the file which needs to be decrypt. 
#       keyFileName: file name from which key will be fetched to decrypt data.
#       decryptedFilePath: Path and file name in which decrypted data will be stored.

# function is developed to accept above mentioned 3 parameters for now.
#

# COMMAND ----------

def decryptfile(filePath,keyFileName,decryptedFilePath) :
    
    try:
        # !pip install cryptography
        
        # import required module
        from cryptography.fernet import Fernet

        # opening the key
        with open(keyFileName, 'rb') as filekey:
         key = filekey.read()
  
        # using the generated key
        fernet = Fernet(key)
  
        # opening the encrypted file
        with open(filePath, 'rb') as enc_file:
         encrypted = enc_file.read()
  
        # decrypting the file
        decrypted = fernet.decrypt(encrypted)
        
        # opening the file in write mode and
        # writing the decrypted data
        with open(decryptedFilePath, 'wb') as dec_file:
         dec_file.write(decrypted)
        
    except Exception as e:
         print("Error while decrypt file")
        


# COMMAND ----------

decryptfile("/dbfs/mnt/containershareddna01/Covid_Ohio_state_2.csv",'keyfile.key',"/dbfs/mnt/containershareddna01/Covid_Ohio_state_2.csv")