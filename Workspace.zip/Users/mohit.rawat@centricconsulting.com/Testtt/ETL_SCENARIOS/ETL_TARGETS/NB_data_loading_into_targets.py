# Databricks notebook source
df_001= spark.read.csv("/mnt/containershareddna01/DATA_SOURCE.csv",header = "true")
df_001.show()

# COMMAND ----------

df_001.write.format("delta").mode("overwrite").saveAsTable("test_delta_table_bs_2")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from test_delta_table_bs_2;

# COMMAND ----------

# MAGIC %sql
# MAGIC --Here you can try any insert and update in our delta table
# MAGIC insert into test_delta_table_bs_2 values('Kumar', 'IN','M',220);
# MAGIC --update test_delta_table_bs set Address = 'HR' where Name = 'Rishi';
# MAGIC select * from test_delta_table_bs_2 where Name = 'Kumar';

# COMMAND ----------

# You can fetch data from DBFS path as shown below
# Need to upload file on DBFS
dbfs= spark.read.csv("/FileStore/tables/Covid_Ohio_state_f7.csv",header = "true")
dbfs.show()

# COMMAND ----------

# Here you can load/ write data into DBFS path and at Blob storage container using mount point
dbfs.write.format("csv").mode("overwrite").csv("/FileStore/tables/dbfs_010.csv",header="true")
dbfs.write.format("delta").mode("overwrite").csv("/mnt/containershareddna02/dbfs_010.csv",header="true")

# COMMAND ----------

# We are checking data has been stored into that path
dbfs_fetched_from_DBFS= spark.read.csv("/FileStore/tables/dbfs_010.csv/part*.csv",header = "true")
dbfs_fetched_from_DBFS.show()

# COMMAND ----------

# Now we can insert/load data into sql server 

# COMMAND ----------

# These are creds, And we will use this url and jdbcUrl to read and store data into sql server
jdbcHostname = "dbserverdna01.database.windows.net"
jdbcDatabase = "dbdna01"
jdbcPort = 1433
username = 'admindna01'
password = 'admindna@01'
connectionProperties = {
  "user" : username,
  "password" : password,
  "driver" : "com.microsoft.sqlserver.jdbc.SQLServerDriver"
  }
jdbcUrl = "jdbc:sqlserver://{0}:{1};database={2};user={3};password={4}".format(jdbcHostname, jdbcPort, jdbcDatabase, username, password)
Url = "jdbc:sqlserver://{0}:{1};database={2}".format(jdbcHostname, jdbcPort, jdbcDatabase)

# COMMAND ----------

df_from_container= spark.read.csv("/mnt/containershareddna01/DATA_SOURCE.csv",header = "true")
df_from_container.show()


# COMMAND ----------

# We are creating a table - test_bs_1 in sql server using that Url and properties
from pyspark.sql import *
df_table_creation_from_file = DataFrameWriter(df_from_container)
df_table_creation_from_file.jdbc(url=Url, table= "test_bs_1", mode ="overwrite", properties = connectionProperties)


# COMMAND ----------

# fetching data from table which we have stored
df_from_table = spark.read.jdbc(url=Url, table="(select * from test_bs_1) test_data", properties=connectionProperties)
display(df_from_table)

# COMMAND ----------

# We can fetch filtered data fron table
df_from_table = spark.read.jdbc(url=Url, table="(select Name, Salary from test_bs_1 where Name = 'Rohit') test_data", properties=connectionProperties)
display(df_from_table)

# COMMAND ----------

# We can save script into vsariablr like - pushdown_query and can use as below
pushdown_query = "(select * from test_bs_1) test_data"
df_from_table = spark.read.jdbc(url=Url, table=pushdown_query, properties=connectionProperties)
display(df_from_table)

# COMMAND ----------

# MAGIC %sql
# MAGIC -- We can insert records directly into table
# MAGIC 
# MAGIC -- insert into test_bs_1 values(5,'Rishi','1');
# MAGIC -- insert into test_bs_1 values(10,'John','1');
# MAGIC -- insert into test_bs_1 values(9,'Payal','0');
# MAGIC -- insert into test_bs_1 values(7,'Rajan','1');
# MAGIC 
# MAGIC select * from test_bs_1 where id between 5 and 15;