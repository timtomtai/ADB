# Databricks notebook source
df_001= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state.csv",header = "true")
df_001.show()

# COMMAND ----------

sourcePath = "/mnt/containershareddna02/Covid_Ohio_state.csv"
targetFileFolder = "/mnt/containershareddna02/Compression"
targetPathUNcompressed = f"{targetFileFolder}/Covid_Ohio_state_uncompressed.csv"
targetPathGzip = f"{targetFileFolder}/Covid_Ohio_state_Gzip.csv"
targetPathSnappy = f"{targetFileFolder}/Covid_Ohio_state_Snappy.csv"
targetPathBzip = f"{targetFileFolder}/Covid_Ohio_state_Bzip.csv"
targetPathLZ4 = f"{targetFileFolder}/Covid_Ohio_state_LZ4.csv"

# COMMAND ----------

# Write the file using NO COMPRESSION, SNAPPY, GZIP, LZ4 etc
df_001.write.mode("overwrite").csv(targetPathUNcompressed)
df_001.write.mode("overwrite").option("compression","GZIP").csv(targetPathGzip)
df_001.write.mode("overwrite").option("compression","snappy").csv(targetPathSnappy)
df_001.write.mode("overwrite").option("compression","bzip2").csv(targetPathBzip)
df_001.write.mode("overwrite").option("compression","lz4").csv(targetPathLZ4)

# COMMAND ----------

# let's compare the size of different files

uncompressed_size = sum([f.size for f in dbutils.fs.ls(targetPathUNcompressed) ])
print(f"Uncompressed file size : {uncompressed_size} bytes")

Gzip_size = sum([f.size for f in dbutils.fs.ls(targetPathGzip) ])
print(f"GZIP file size : {Gzip_size} bytes")

snappy_size = sum([f.size for f in dbutils.fs.ls(targetPathSnappy) ])
print(f"snappy file size : {snappy_size} bytes")

Bzip_size = sum([f.size for f in dbutils.fs.ls(targetPathBzip) ])
print(f"Bzip file size : {Bzip_size} bytes")

LZ4_size = sum([f.size for f in dbutils.fs.ls(targetPathLZ4) ])
print(f"LZ4 file size : {LZ4_size} bytes")

# COMMAND ----------

