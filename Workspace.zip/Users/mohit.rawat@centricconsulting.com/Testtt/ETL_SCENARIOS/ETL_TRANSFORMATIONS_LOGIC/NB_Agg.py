# Databricks notebook source
file_location = "/FileStore/tables/S_NS/Aggdata.txt"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = " "

# The applied options are for CSV files. For other file types, these will be ignored.
df = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df)



# COMMAND ----------

from pyspark.sql.functions import *

# sum,avg,max,min,mean,count

df.groupBy("State").agg(max("InsuredValue").alias("Max_InsuredValue")).show()

# COMMAND ----------

df.groupBy("State").agg(min("InsuredValue").alias("Min_InsuredValue")).show()

# COMMAND ----------

df.groupBy("State").agg(avg("InsuredValue").alias("Avg_InsuredValue")).show()

# COMMAND ----------

df.groupBy("State").agg(sum("InsuredValue").alias("Sum_InsuredValue")).show()

# COMMAND ----------

df.groupBy("State", "Expiry").agg(sum("InsuredValue").alias("Sum_InsuredValue"),max("InsuredValue").alias("Max_InsuredValue"),avg("InsuredValue").alias("Avg_InsuredValue"),min("InsuredValue").alias("Min_InsuredValue")).show()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS Tbl;
# MAGIC CREATE TABLE Tbl
# MAGIC USING csv
# MAGIC OPTIONS (path "/FileStore/tables/S_NS/Aggdata.txt", header "true", delimiter = " ");

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC Select State, Max(InsuredValue) as Max_InsuredValue from Tbl group by State

# COMMAND ----------

# MAGIC %sql
# MAGIC Select State, Min(InsuredValue) as Min_InsuredValue from Tbl group by State

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC Select * from Tbl

# COMMAND ----------

import pyspark
from pyspark.sql import SparkSession
from delta.tables import *
from pyspark.sql.functions import *
from pyspark.sql.types import StringType,BooleanType,DateType

# from babel.numbers import format_decimal


# format_decimal(188518982.18, locale='en_US')

df1= df.withColumn("InsuredValue",col("InsuredValue").cast("int"))


# COMMAND ----------

# df1.groupBy("State").agg(sum("InsuredValue").alias("Sum_InsuredValue")).show()

df1.show()