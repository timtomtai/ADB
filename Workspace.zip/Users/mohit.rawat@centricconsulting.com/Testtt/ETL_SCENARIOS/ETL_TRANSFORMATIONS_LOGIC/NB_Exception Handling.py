# Databricks notebook source
import sys

list = ['x', 1e-15, 5]

for result in list:

    try:

        print("The result is", result)

        y = 1/int(result)

        #break

    except:

        print("Whew!", sys.exc_info()[0], "occurred.") ### sys.exc_info() returns the name of the exception

        print("Next input please.")

        print()

print("The answer of", result, "is", y)

# COMMAND ----------

import sys

list = ['x', 1e-15, 5]

for result in list:

    try:

        print("The result is", result)

        y = 1/int(result)

        #break

    except Exception as e:

        print(e)

# COMMAND ----------

try:

     #x = int(input("Enter a positive integer:"))
     x=-6

     if x <= 0:

         raise ValueError("It is not a positive number!")

except ValueError as val_e:

    print(val_e)

# COMMAND ----------

try:

    #number = int(input("Enter a number: "))
    number=2

    assert number % 2 == 0

except:

    print("This is an odd number!")

else:

    print("This is an even number!")

    rem = number % 2

    print("The remainder is ", rem)

# COMMAND ----------

try:

   file = open('/dbfs/FileStore/tables/oss/test_txt.txt',encoding = 'utf-8')
   print(file.read())
   # this performs file operations

finally:

   file.close()
   print('file closed')

# COMMAND ----------

#user defined Exception
class MyError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

try:
    raise MyError(2*2)
except MyError as e:
    print('My exception occurred, value:', e.value)

# COMMAND ----------

# MAGIC %md
# MAGIC try { start transaction; execute statements; commit transaction;} catch (Exception e) { perform rollback; } finally { close DB resources like statement; }

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from new_table_eh_delta

# COMMAND ----------

try:    
    from delta.tables import *
    import sys
    #deltaTable = DeltaTable.forPath(spark, "/delta/diamonds/")
    deltaTable = DeltaTable.forName(spark, "new_table_eh_delta")
    #fullHistoryDF = deltaTable.history()    # get the full history of the table
    #fullHistoryDF.show()
    lastOperationDF = deltaTable.history(1) # get the last operation
    version=lastOperationDF.select('version').collect()[0][0]
    print(version)
    TimeStamp=lastOperationDF.select('timestamp').collect()[0][0]
    print(TimeStamp)
    spark.sql("insert into new_table_eh_delta values (4,4,4,4,'Active')")
    spark.sql("insert into new_table_eh_delta values (4,0,4,4,'Active')")
  
except Exception as e:
    print("return to previous version due to error:", sys.exc_info()[0])
    deltaTable.restoreToVersion(version) # restore table to oldest version
    print(e.args)
    x, y = e.args     # unpack args
    print('x =', x)   #<class 'Exception'>
    print('y =', y)
    #deltaTable.restoreToTimestamp(TimeStamp) # restore to a specific timestamp