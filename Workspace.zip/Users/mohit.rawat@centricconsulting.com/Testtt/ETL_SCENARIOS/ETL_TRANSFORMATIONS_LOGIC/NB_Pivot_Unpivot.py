# Databricks notebook source
# MAGIC %md # Pivot Spark dataFrame

# COMMAND ----------

# Read csv file with columns (Product, amount and Country) 
from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from pyspark.sql.types import *

df=spark.read.option('header','true').csv("/mnt/containershareddna01/teamC_storage/Product.csv",inferSchema='true')
df.show()

# COMMAND ----------

df_pivot = df.groupBy("Product").pivot("Country").sum("Amount")
df_pivot.show()

# COMMAND ----------

# MAGIC %md #Unpivot

# COMMAND ----------

unpivotExpr = "stack(4, 'Canada', Canada, 'China', China, 'Mexico', Mexico,'USA',USA) as (Country,Total)"
unPivotDF = df_pivot.select("Product", expr(unpivotExpr))\
.where("Total is not null")
unPivotDF.show(truncate=False)