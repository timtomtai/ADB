# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC SCD2 - With End Date as the indicator of the active record

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Create the table
# MAGIC CREATE TABLE PRODUCTS_SCD (PRODUCT_ID INT,PRODUCT_NAME STRING,PRODUCT_PRICE INT,PRODUCT_DESC STRING,START_DATE DATE, END_DATE DATE);

# COMMAND ----------

# MAGIC %md
# MAGIC SCD2 Operational Scenarios Starts from here

# COMMAND ----------

# Read the  source file - Start Date is a source effective date
updatesDF = spark.read.csv("/FileStore/tables/Product-5.csv", header = "true")

updatesDF.show()

# COMMAND ----------

from delta.tables import *
#read the delta Table
PRODUCTS_SCD = DeltaTable.forPath(spark, '/user/hive/warehouse/products_scd')



# COMMAND ----------

# FInd the changed/updated records
stagedPart1 = updatesDF.alias("updates").join(PRODUCTS_SCD.toDF().alias("products"), "PRODUCT_ID").where("isnull(products.END_DATE) = true AND (updates.PRODUCT_NAME <> products.PRODUCT_NAME OR updates.PRODUCT_PRICE <> products.PRODUCT_PRICE OR  products.PRODUCT_DESC <> updates.PRODUCT_DESC )").selectExpr("NULL as mergeKey", "updates.*")
stagedPart1.show()

# COMMAND ----------

# FInd the new records
stagedPart2 = updatesDF.selectExpr("PRODUCT_ID as mergeKey", "*")
stagedPart2.show()

# COMMAND ----------

# FInd the deleted records
stagedPartDeleted = PRODUCTS_SCD.toDF().alias("products").join(updatesDF,"PRODUCT_ID","left_anti").selectExpr("'D' as mergeKey", "products.*").distinct()

stagedPartDeleted.show()

# COMMAND ----------

#Union both Chnaged and New Records
stagedUpdates = stagedPart1.union(stagedPart2)
stagedUpdates.show()

# COMMAND ----------

#Using Merge - Updated the existing record and insert new records
PRODUCTS_SCD.alias("products")\
    .merge(
        stagedUpdates.alias("staged_updates"),
        "products.PRODUCT_ID = mergeKey"
    )\
    .whenMatchedUpdate(
        condition = "isnull(products.END_DATE) = true AND (staged_updates.PRODUCT_NAME <> products.PRODUCT_NAME OR staged_updates.PRODUCT_PRICE <> products.PRODUCT_PRICE OR  products.PRODUCT_DESC <> staged_updates.PRODUCT_DESC )"
        ,set = 
            {
       
            "END_DATE" : "staged_updates.START_DATE" 
            }
    
    ).whenNotMatchedInsert(values =
        {
    
        "PRODUCT_ID" : "staged_updates.PRODUCT_ID",
        "PRODUCT_NAME" : "staged_updates.PRODUCT_NAME",
        "PRODUCT_PRICE" : "staged_updates.PRODUCT_PRICE",
        "PRODUCT_DESC" : "staged_updates.PRODUCT_DESC",
        "START_DATE" : "staged_updates.START_DATE",
        "END_DATE" : "null"
        }
    )\
      .execute()

# COMMAND ----------

#Using Merge - Updated the deleted records

from datetime import datetime, timedelta
from pyspark.sql.functions import *
yesterday = (datetime.now() - timedelta(1)).strftime('%Y-%m-%d')


PRODUCTS_SCD.alias("products")\
    .merge(
        stagedPartDeleted.alias("staged_deleted"),
        ("products.PRODUCT_ID = staged_deleted.PRODUCT_ID and staged_deleted.mergeKey = 'D'")
    )\
    .whenMatchedUpdate(
        condition = "isnull(products.END_DATE) = true"
        ,set = 
            {
       
            "END_DATE" : lit(yesterday)
            }
    
    ).execute()



# COMMAND ----------

# MAGIC %sql 
# MAGIC 
# MAGIC Select * from PRODUCTS_SCD