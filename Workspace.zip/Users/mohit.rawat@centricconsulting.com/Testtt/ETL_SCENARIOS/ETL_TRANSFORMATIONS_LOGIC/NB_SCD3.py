# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC SCD3 - With last one set of historical records 

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Create the table
# MAGIC CREATE TABLE EMPLOYEES_SCD (EMP_ID INT,EMP_NAME STRING,EMP_ADDRESS STRING,EMP_ADDRESS_PREVIOUS STRING);

# COMMAND ----------

# MAGIC %md
# MAGIC SCD3 Operational Scenarios Starts from here

# COMMAND ----------

# Read the  source file
updatesDF = spark.read.csv("/FileStore/tables/EMP_SCD3-1.csv", header = "true")

updatesDF.show()

# COMMAND ----------


from delta.tables import *
#read the delta Table
EMPLOYEES_SCD = DeltaTable.forPath(spark, '/user/hive/warehouse/employees_scd')



# COMMAND ----------

# FInd the changed/updated records
stagedPart1 = updatesDF.alias("updates").join(EMPLOYEES_SCD.toDF().alias("employees"), "EMP_ID").where("updates.EMP_ADDRESS <> employees.EMP_ADDRESS").selectExpr("NULL as mergeKey", "updates.*")
stagedPart1.show()

# COMMAND ----------

#FInd the new records
stagedPart2 = updatesDF.selectExpr("EMP_ID as mergeKey", "*")
stagedPart2.show()

# COMMAND ----------

#Union both changed and new records
stagedUpdates = stagedPart1.union(stagedPart2)
stagedUpdates.show()

# COMMAND ----------

#Using Merge - Updated the existing record and insert new records
PRODUCTS_SCD.alias("employees")\
    .merge(
        stagedUpdates.alias("staged_updates"),
        "employees.EMP_ID = mergeKey"
    )\
    .whenMatchedUpdate(
        condition = "(staged_updates.EMP_ADDRESS <> employees.EMP_ADDRESS)"
        ,set = 
            {
       
            "EMP_ADDRESS_PREVIOUS" : "employees.EMP_ADDRESS",
            "EMP_ADDRESS" : "staged_updates.EMP_ADDRESS" 
            }
    
    ).whenNotMatchedInsert(
        condition = "(isnull(staged_updates.mergeKey) = false )"
        ,values =
        {
    
            "EMP_ID" : "staged_updates.EMP_ID",
            "EMP_NAME" : "staged_updates.EMP_NAME",
            "EMP_ADDRESS" : "staged_updates.EMP_ADDRESS"
        }
    )\
      .execute()

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from EMPLOYEES_SCD