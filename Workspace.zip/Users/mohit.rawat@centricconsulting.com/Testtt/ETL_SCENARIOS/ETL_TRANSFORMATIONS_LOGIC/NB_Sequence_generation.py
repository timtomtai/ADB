# Databricks notebook source
df_fetching_from_blob= spark.read.csv("/mnt/containershareddna02/dbfs_001.csv/part*.csv",header = "true")
df_fetching_from_blob.show()
DF=df_fetching_from_blob
DF.show()

# COMMAND ----------

###final##
#geneate sequence in a dataframe incrementally
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
from pyspark.sql.functions import when
from pyspark.sql.functions import *

DF=DF.withColumn('id',lit(None))
s=DF.agg({"id": "max"}).collect()[0][0]
if s==None:
    s=0
#DF1=DF.withColumn('id', when(DF.id.isNull(),s+row_number().over(Window.orderBy('id')))\
                         #.otherwise(DF.id))
DF1=DF.filter(DF.id.isNull()).withColumn('id',s+row_number().over(Window.orderBy('claim_id')))
DF1.show()

# COMMAND ----------

## create dummy data scenario for incremental load
from pyspark.sql.functions import when
DF2=DF1.withColumn('id', when(DF1.id > 10, None)\
                      .otherwise(DF1.id))
DF2.show()

# COMMAND ----------

#2nd run
###final##
#geneate sequence in a dataframe incrementally
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
from pyspark.sql.functions import when

s=DF2.agg({"id": "max"}).collect()[0][0]
if s==None:
    s=0
DF3=DF2.withColumn('id', when(DF2.id.isNull(),s+row_number().over(Window.orderBy('id')))\
                         .otherwise(DF2.id))
#DF3=DF2.filter(DF2.id.isNull()).withColumn('id',s+row_number().over(Window.orderBy('claim_id')))
DF3.show()

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import dense_rank
#seed = 23
seed=DF3.agg({"id": "max"}).collect()[0][0]
df1=DF3.withColumn('label', seed+dense_rank().over(Window.orderBy('id')))
df1.show(20)

# COMMAND ----------

from pyspark.sql.window import Window

from pyspark.sql.functions import monotonically_increasing_id,row_number

df2 =DF3.withColumn("row_idx",row_number().over(Window.orderBy(monotonically_increasing_id())))
df2.show(20)

# COMMAND ----------

from pyspark.sql.window import Window

from pyspark.sql.functions import monotonically_increasing_id,row_number

df3 =DF3.withColumn("row_idx",1+monotonically_increasing_id())
df3.show(10)

# COMMAND ----------

# MAGIC %md
# MAGIC ###with tables using SQL and df.rdd.zipWithIndex()

# COMMAND ----------

df_fetching_from_blob.createOrReplaceTempView("Sur_using_sql")
df_SurrKey = spark.sql("select row_number() over(order by claim_id) as Surrogate_key, Claim_id,Cust_id,Policy_number,status from Sur_using_sql")
df_SurrKey.show()

# COMMAND ----------

# Need to create this function for creation of Surrogate Key in existing dataframe

from pyspark.sql.types import LongType, StructField, StructType
def dfZipWithIndex (df, offset , colName ):
    # df - source dataframe
    # offset - Adjust to ZipWithIndex's Index
    # colName - name of the index column
    
    new_schema = StructType(
        [StructField(colName, LongType(),True)]  #new added field
        + df.schema.fields)                      #table fields
    
    zipped_rdd = df.rdd.zipWithIndex()
    
    new_rdd = zipped_rdd.map(lambda row: ([row[1]+offset] + list(row[0])))
    
    return spark.createDataFrame(new_rdd, new_schema)

# COMMAND ----------

df_with_surrKey = dfZipWithIndex(df_fetching_from_blob, offset = 1, colName = "Surrogate_key" )
df_with_surrKey.createOrReplaceTempView("DataFrame_View")
df_final=spark.sql("select * from DataFrame_View")
df_final.show()

# COMMAND ----------

# Second run
N = spark.sql("select max(Surrogate_key) from DataFrame_View").collect()[0][0]

df_with_surrKey = dfZipWithIndex(df_fetching_from_blob, offset = N+1, colName = "Surrogate_key" )
df_with_surrKey.createOrReplaceTempView("DataFrame_View1")

# creating dataframe from view
df_final_surrKey = spark.sql("select * from DataFrame_View1")
df_final_surrKey.show()

# COMMAND ----------

from pyspark.sql.functions import sequence, explode,col
df=spark.sql("SELECT sequence(1,30,2) as id,claim_id from DataFrame_View1" ).withColumn("id",explode(col("id")))
df.show()