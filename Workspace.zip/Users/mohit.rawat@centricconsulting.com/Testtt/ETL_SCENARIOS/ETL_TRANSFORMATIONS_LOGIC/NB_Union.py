# Databricks notebook source
# Here we have performed Union and Union All operation using Pyspark and sparksql

# COMMAND ----------

# File location and type
file_location = "/FileStore/tables/S_NS/Tab3.txt"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = " "

# The applied options are for CSV files. For other file types, these will be ignored.
df3 = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df3)

# COMMAND ----------

# File location and type
file_location = "/FileStore/tables/S_NS/Tab1.txt"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = " "

# The applied options are for CSV files. For other file types, these will be ignored.
df1 = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df1)

# COMMAND ----------

# File location and type
file_location = "/FileStore/tables/S_NS/Tab2.txt"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = " "

# The applied options are for CSV files. For other file types, these will be ignored.
df2 = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df2)

# COMMAND ----------

# UNION

Union_df = df1.union(df2)
Union_df.show()




# COMMAND ----------

Union_df1 = df1.union(df2).union(df3)
Union_df1.show()
Union_df1.count()

# COMMAND ----------

Union_df2 = df1.union(df2).union(df3).distinct()
Union_df2.show()
Union_df2.count()

# COMMAND ----------

Union_df3 = df1.unionAll(df2).unionAll(df3)
Union_df3.show()
Union_df3.count()

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS Tab1;
# MAGIC CREATE TABLE Tab1
# MAGIC USING csv
# MAGIC OPTIONS (path "/FileStore/tables/S_NS/Tab1.txt", header "true", delimiter = " ");
# MAGIC 
# MAGIC DROP TABLE IF EXISTS Tab2;
# MAGIC CREATE TABLE Tab2
# MAGIC USING csv
# MAGIC OPTIONS (path "/FileStore/tables/S_NS/Tab2.txt", header "true", delimiter = " ");
# MAGIC 
# MAGIC DROP TABLE IF EXISTS Tab3;
# MAGIC CREATE TABLE Tab3
# MAGIC USING csv
# MAGIC OPTIONS (path "/FileStore/tables/S_NS/Tab3.txt", header "true", delimiter = " ");

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from Tab1
# MAGIC UNION
# MAGIC Select * from Tab2
# MAGIC UNION 
# MAGIC Select * from Tab3

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from Tab1
# MAGIC UNION ALL
# MAGIC Select * from Tab2
# MAGIC UNION ALL
# MAGIC Select * from Tab3