# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC We have used these commonds to read the delimeted data, quotechar variable is used for reading of the data

# COMMAND ----------

import pyspark ;
from pyspark.sql import SparkSession;

df= spark.read.format('csv').option("header","true").load('/mnt/containershareddna01/teamC_storage/cars.csv',delimiter=',');
df2= spark.read.format('csv').option("header","true").load('/mnt/containershareddna01/teamC_storage/cars2.csv',delimiter=',', quotechar='"');


df.show(5)


df2.show(5)

# COMMAND ----------

file_location = "/FileStore/tables/S_NS/Tab2.txt"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = " "
quotechar='"'

# The applied options are for CSV files. For other file types, these will be ignored.
df2 = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .option("quote", quotechar) \
  .load(file_location)

display(df2)

# COMMAND ----------

file_location = "/FileStore/tables/S_NS/File1.txt"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = ","
quotechar='"'

# The applied options are for CSV files. For other file types, these will be ignored.
df3 = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .option("quote", quotechar) \
  .load(file_location)

display(df3)