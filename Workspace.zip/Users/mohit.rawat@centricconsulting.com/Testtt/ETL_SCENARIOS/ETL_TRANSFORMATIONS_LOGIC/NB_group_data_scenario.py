# Databricks notebook source
# MAGIC %md
# MAGIC Various grouped data related scenarios are taken - more details in below link
# MAGIC 
# MAGIC https://spark.apache.org/docs/3.1.1/api/python/reference/api/pyspark.sql.GroupedData.html

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.functions import col
import pyspark.sql.functions as F

# Creating dataframe
df= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_join.csv",header = "true", inferSchema ="true")

#Add the death year column

df_year = df.withColumn("year",df.date.substr(-4,4))
df_year.show()


# COMMAND ----------

#Find the death details grouped per year & state using agg

df_year2 =df_year.groupBy("year","state").agg(F.max(df_year.death), F.max(df_year.deathIncrease))

df_year2.show()

# COMMAND ----------

# Filter on grouped data

df_year2 =df_year.groupBy("year","state").agg(F.max(df_year.death).alias("max_deaths"), F.max(df_year.deathIncrease).alias("max_deathIncrease")).where(col("max_deaths") >=10000).show(truncate=False)



# COMMAND ----------


#Find the mean directly over mutliple columns

df_year2 =df_year.groupBy("year").mean('death','deathIncrease').withColumnRenamed("avg(death)","death_mean")


df_year2.show()

# COMMAND ----------

#Pivot columns

df_year.groupBy("state").pivot("year", ["2021", "2020", "2019"]).mean("death").show()


# COMMAND ----------

# Apply In Pandas
import pandas as pd  
from pyspark.sql.functions import pandas_udf

def avg_func(key, pdf):
    # key is a tuple of one numpy.int64, which is the value
    # of 'id' for the current group
    return pd.DataFrame([key + (pdf.death.mean(),pdf.deathIncrease.mean(),)])
df_year.groupby('year').applyInPandas(
    avg_func, schema="year string, death_mean double, deathIncrease_mean double").show() 