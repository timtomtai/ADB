# Databricks notebook source
# We have few null values in source data, we will put default value for null values, and we will replace null with its mean and mode values by filling data

# COMMAND ----------

# We have this csv file in blob storage and we are fetching data with help of our existing mount 
df_01= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_null.csv",header = "true", inferSchema = "true")
df_01.show()

# COMMAND ----------

# Now we will skip null values
df_01.count() # Total count in dataframe is 368


# COMMAND ----------

# If we will drop null related records, count will be 319, We are not storing it in dataframe
# na.drop() will drop all records having any null value, and count() will display its count
df_01.na.drop().show()

# COMMAND ----------

df_01.show()

# COMMAND ----------

# na.drop have 3 parameters - how, thresh and subset
# how - any or all (any - drop a row if any column value have null) (all - drop a row if all its values are null)
# thresh - If specified, drop rows that have less that 'thresh' non-null value
# sunset - optional list of column names to consider

df_01.na.drop(how="any",thresh=3).show()

# COMMAND ----------

df_01.na.drop(how="all").show()

# COMMAND ----------

# If we have 4 columns having not-null value, it will not drop that record
df_01.na.drop(how="any",thresh=4).count()

# COMMAND ----------

# using subset
# if death column having null value, it will drop that row
df_01.na.drop(how="any",subset="death").show()

# COMMAND ----------

df_01.na.drop(how="any",subset="death").count()

# COMMAND ----------

# checking death and state
df_01.na.drop(how='any',subset=['death','state'])

# COMMAND ----------

df_01.show()

# COMMAND ----------

df_05.printSchema()

# COMMAND ----------

# filling default values for null
df_03 = df_01.na.fill('01-01-9999', 'date')

# COMMAND ----------

type(df_03)
df_03.show()

# COMMAND ----------

df_01.na.fill("99999").show()

# COMMAND ----------

# default value for specific column
# df_01.na.fill('Not Available','death').show() # this will not work because column is int datatype 
df_01.na.fill(99999999,'death').show()

# COMMAND ----------

# Now we are calculating mean value of columns - death and deathIncrease, and replacing those values with null
# We need to import Imputer to do this, it will create more columns with mean values in place of null values

from pyspark.ml.feature import Imputer

imputer = Imputer(
    inputCols=['death','deathIncrease'],
    outputCols=["{}_imputed".format(c) for c in ['death','deathIncrease']]
                 ).setStrategy("mean")

# COMMAND ----------

type(imputer)

# COMMAND ----------

# using imputer as shown below, It will replace null values with mean value in mentioned columns

imputer.fit(df_01).transform(df_01).show()

# 5242 is mean value of death column, 
# 48 is mean value in deathIncrease column

# it has generated 2 new columns having mean values - death_imputed, deathIncrease_imputed as shown below

# COMMAND ----------

type(df_02)