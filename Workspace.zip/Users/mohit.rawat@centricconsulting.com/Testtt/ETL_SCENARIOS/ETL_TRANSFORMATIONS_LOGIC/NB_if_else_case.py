# Databricks notebook source
# PySpark supports a way to check multiple conditions in sequence and returns a value when the first condition met by using SQL like case when and when().otherwise() expressions, these works similar to “Switch" and "if then else" statements.

# COMMAND ----------

# PySpark When Otherwise – when() is a SQL function that returns a Column type and otherwise() is a function of Column, if otherwise() is not used, it returns a None/NULL value.
# PySpark SQL Case When – This is similar to SQL expression, Usage: CASE WHEN cond1 THEN result WHEN cond2 THEN result... ELSE result END.

# COMMAND ----------

# dataframe
df= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_join.csv",header = "true", inferSchema ="true")
df.show()

# COMMAND ----------

#  when(condition).otherwise(default)
from pyspark.sql.functions import when
variable = "deathIncrease_new"
df1 = df.withColumn(variable, when(df.deathIncrease == 0, "zero")
                                 .when(df.deathIncrease.isNull() ,"zero")
                                 .otherwise(df.deathIncrease))
df1.show()

# COMMAND ----------

# using select
from pyspark.sql.functions import col
df2 = df.select(col("*"), when(df.deathIncrease == 0, "zero")
                                 .when(df.deathIncrease.isNull() ,"zero")
                                 .otherwise(df.deathIncrease).alias("new_colum")) 
df2.show()

# COMMAND ----------

# Case When statement

# CASE
#     WHEN condition1 THEN result_value1
#     WHEN condition2 THEN result_value2
#     -----
#     -----
#     ELSE result
# END;

# COMMAND ----------

# using withColumn
from pyspark.sql.functions import col, expr
df3 = df.withColumn(variable, expr("CASE WHEN deathIncrease = 0 THEN 'Zero' " + 
               "WHEN deathIncrease = null THEN 'Zero' " +
               "ELSE deathIncrease END"))
df3.show()


# COMMAND ----------

# using select
from pyspark.sql.functions import col, expr
df4 = df.select(col("*"), expr("CASE WHEN deathIncrease = 0 THEN 'ZerO' " +
           "WHEN deathIncrease = null THEN 'Zero'" +
           "ELSE deathIncrease END").alias(variable))
df4.show()

# COMMAND ----------

 df.show()