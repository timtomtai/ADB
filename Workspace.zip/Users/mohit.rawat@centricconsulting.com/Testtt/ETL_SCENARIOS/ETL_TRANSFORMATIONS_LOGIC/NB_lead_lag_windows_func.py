# Databricks notebook source
# PySpark Window functions - lead , lag
# This is the same as the LAG & LEAD function in SQL.

# COMMAND ----------

# df_01 is dataframe which
df_01= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_join.csv",header = "true", inferSchema ="true").sort("date")
df_01.show()

# COMMAND ----------

df_01.printSchema()

# COMMAND ----------

# lag - This is the same as the LAG function in SQL.
# We need to use lag function with partitionBy and orderBy same as in sql

from pyspark.sql.functions import lag , col   
from pyspark.sql.window import Window
df_02 = df_01.withColumn("lag",lag("hospitalized",1).over(Window.partitionBy('state').orderBy("date")))

# COMMAND ----------

df_02.show()

# COMMAND ----------

df_02.printSchema()

# COMMAND ----------

df_02.select("date","state","death","hospitalized", "lag",(col("hospitalized") + col("lag")).alias("hospitalized_from_last_48_hours")).show() 

# COMMAND ----------

# lead - This is the same as the LEAD function in SQL.

from pyspark.sql.functions import lag ,lead, col   
from pyspark.sql.window import Window
df_lead = df_01.withColumn("lead",lead("hospitalized",1).over(Window.partitionBy('state').orderBy("date")))

# COMMAND ----------

df_lead.show()

# COMMAND ----------

df_lead.printSchema()

# COMMAND ----------

df_lead.select("date","state","death","hospitalized", "lead",(col("hospitalized") + col("lead")).alias("hospitalized_included_next_day")).show() 