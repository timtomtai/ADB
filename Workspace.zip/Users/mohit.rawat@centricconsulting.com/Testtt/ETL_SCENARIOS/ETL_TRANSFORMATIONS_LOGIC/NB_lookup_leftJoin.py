# Databricks notebook source
# We can lookup 2 dataframes (or files) and can store data into new one.


# COMMAND ----------

# df_01 is first dataframe which has state column common with another dataframe df_02's column States
df_01= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_join.csv",header = "true", inferSchema ="true")
df_01.show()
# df_01.count() # 368

# COMMAND ----------

df_02= spark.read.csv("/mnt/containershareddna02/lookupfile_States.csv",header = "true", inferSchema ="true")
df_02.show()
# df_02.count() # 51

# COMMAND ----------

df_02.join(df_01,df_01.state == df_02.States,'left').show()
# df_01.join(df_02,df_01.state == df_02.States,'left').count() #368

# COMMAND ----------

df_01.createOrReplaceTempView("df1")
df_02.createOrReplaceTempView("df2")

sqlContext.sql("SELECT DISTINCT df1.*, df2.* FROM df1 inner join df2 on " + "df1.state == df2.States").show()


# COMMAND ----------

df_03 = df_02.join(df_01,df_01.death == df_02.Census,'left')
# df_01.join(df_02,df_01.state == df_02.States,'left').count() #368
# df_03.printSchema()
df_03.show()