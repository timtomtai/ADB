# Databricks notebook source
# MAGIC %md
# MAGIC MD5 :
# MAGIC Calculates the MD5 digest and returns the value as a 32 character hex string

# COMMAND ----------

from pyspark.sql.functions import md5
from pyspark.sql.functions import col
from pyspark.sql.functions import *

# Creating dataframe
df= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_join.csv",header = "true", inferSchema ="true")

#Add the death year column

df_year = df.withColumn("year",df.date.substr(-4,4)).withColumn("Dummy_len_column", lit(1)).withColumn("StateSecondChar",col("state").substr(instr(col("state"),'H'),col("Dummy_len_column")))
df_year.show()


# COMMAND ----------


# md5 function over a column
df_year.select(md5('year').alias('yearhash')).distinct().show(truncate=False)


# COMMAND ----------

# md5 function over conactenated columns
df_year.select(md5(concat(df_year.date,df_year.state,df_year.death)).alias('concated_hash')).distinct().show(truncate=False)



# COMMAND ----------

# md5 function over concatenated columns with a seperator
df_year.select(md5(concat_ws('_',df_year.date,df_year.state,df_year.death)).alias('concated_hash')).distinct().show(truncate=False)

# COMMAND ----------

# md5 function over concatenated columns with a seperator and handling null/na values

df_year.na.fill(value="",subset=["date","state","death"]).select(md5(concat_ws('_',"date","state","death")).alias('concated_hash')).show(truncate=False)

