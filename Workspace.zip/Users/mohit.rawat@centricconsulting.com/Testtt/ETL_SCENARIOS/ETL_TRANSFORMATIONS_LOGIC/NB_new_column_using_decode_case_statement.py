# Databricks notebook source
# We can add new column Using when(condition).otherwise(default) which has same functionality as Case, decode, if else 

# COMMAND ----------

# dataframe
df= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_join.csv",header = "true", inferSchema ="true")
df.show()

# COMMAND ----------

# We can add new column with another columns value like this.
# Using when(condition).otherwise(default)
from pyspark.sql.functions import when, col
variable = 'deathIncrease_new'
df.withColumn(variable, when(df.deathIncrease == 0, df.death)
                                 .when(df.deathIncrease.isNull() ,df.death)
                                 .otherwise(df.deathIncrease)).show()



# COMMAND ----------

# We can add string and another column's value to a new column like this
# Using when(condition).otherwise(default)
from pyspark.sql.functions import *
df.withColumn(variable, when(df.deathIncrease == 0, concat(lit("death - "),df.death))
                                 .when(df.deathIncrease.isNull() ,concat(lit("death -"),df.death))
                                 .otherwise(df.deathIncrease)).show()

# COMMAND ----------

# Creating a new column which have sub-string from column (state) and value of column death by using concat
# Using when(condition).otherwise(default)
from pyspark.sql.functions import *
df.withColumn(variable, when(df.deathIncrease == 0, concat(df.state[0:1],lit(" - "),df.death))
                                 .when(df.deathIncrease.isNull() ,concat(df.state[0:2],lit(" - "),df.death))
                                 .otherwise(df.deathIncrease)).show()