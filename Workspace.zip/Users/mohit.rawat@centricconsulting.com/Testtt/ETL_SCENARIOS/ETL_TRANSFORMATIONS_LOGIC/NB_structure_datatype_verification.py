# Databricks notebook source
# We need to verify csv file's columns and its datatypes, below functions will give you result that Datatypes are as expected or not.

# COMMAND ----------

def verifyStructure(filePath) :
    
    #from pyspark.sql.functions import *   
    try:
        dictFile = {'date': 'string', 'state': 'string', 'death': 'int', 'deathConfirmed': 'int', 'deathIncrease': 'int', 'deathProbable': 'int', 'hospitalized': 'int'}
        
        dfCsv = spark.read.format("csv") \
                   .option("header", "true") \
                   .option("inferSchema", "true") \
                   .load(filePath)
      # using dict we are typecasting tuple into the dictionary
        dfCsvDict = dict(dfCsv.dtypes)
        
        
        if dictFile == dfCsvDict:
         print("Verification Completed - Structure and Datatypes are as expected") 

        else :
         print("Verification Completed - Structure and Datatypes are not as expected") 
            
    except Exception as e:
         print("Verification Failed")
        


# COMMAND ----------

verifyStructure("/mnt/containershareddna02/Covid_Ohio_state_join.csv")

# COMMAND ----------

# Compare Structure and Datatype of 2 files
def verifyStructureWithFile(filePath, verifiedDummyFile) :
    
    #from pyspark.sql.functions import *   
    try:
      # dictFile = {'date': 'string', 'state': 'string', 'death': 'int', 'deathConfirmed': 'int', 'deathIncrease': 'int', 'deathProbable': 'int', 'hospitalized': 'int'}
        
        dfVerifiedDummyFile = spark.read.format("csv") \
                   .option("header", "true") \
                   .option("inferSchema", "true") \
                   .load(verifiedDummyFile)
        
        dfVerifiedDummyFileDict = dict(dfVerifiedDummyFile.dtypes)
        
        dfCsv = spark.read.format("csv") \
                   .option("header", "true") \
                   .option("inferSchema", "true") \
                   .load(filePath)
      # using dict we are typecasting tuple into the dictionary
        dfCsvDict = dict(dfCsv.dtypes)
        
        
        if dfVerifiedDummyFileDict == dfCsvDict:
         print("Verification Completed - Structure and Datatypes are as expected") 

        else :
         print("Verification Completed - Structure and Datatypes are not as expected") 
            
    except Exception as e:
         print("Verification Failed")
        


# COMMAND ----------

verifyStructureWithFile("/mnt/containershareddna02/Covid_Ohio_state.csv","/mnt/containershareddna02/Covid_Ohio_state_join.csv")

# COMMAND ----------

verifyStructureWithFile("/mnt/containershareddna02/Covid_Ohio_state_1.csv","/mnt/containershareddna02/Covid_Ohio_state_join.csv")

# COMMAND ----------

# In any column, if there is data having wrong type, (if datatype of column is int but data in that column have string, then using inferSchema it change column's datatype from int to string automatically) it will automatically change its column datatype and will not match with dummy file's datatype.
# Also if no. of columns is different from dummy file, it will give "not as expected"