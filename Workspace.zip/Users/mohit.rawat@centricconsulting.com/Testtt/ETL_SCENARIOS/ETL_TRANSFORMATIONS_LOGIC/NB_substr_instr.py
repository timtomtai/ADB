# Databricks notebook source
# using substr and instr in pyspark
# startPos and length must be the same type. Both can be <class 'pyspark.sql.column.Column'> or <class 'int'>, but it must be same while using substr

# COMMAND ----------

df_01= spark.read.csv("/mnt/containershareddna02/Covid_Ohio_state_null.csv",header = "true", inferSchema = "true")
df_01.show()

# COMMAND ----------

# doing on from pyspark.sql.functions import *
df_01.withColumn("monthvalue", col("date").substr(instr(col("date"), '-')+1, instr(col("date"), '-')-1)).show()

# COMMAND ----------

# doing on M/dd/yyyy format
from pyspark.sql.functions import *
df_01.withColumn("datevalue", col("date").substr(instr(col("date"), '/')+1, instr(col("date"), '/'))).show()

# COMMAND ----------

df_year = df_01.withColumn("StateINSTR",col("state").substr(instr(col("state"),'H'),instr(col("state"),'H')))
df_year.show()

# COMMAND ----------

df_year = df_01.withColumn("StateINSTR",col("state").substr(instr(col("state"),'H'),instr(col("state"),'H')))
df_year.show()


# COMMAND ----------

df_year = df_01.withColumn("StateINSTR",col("state").substr(2,1))
df_year.show()