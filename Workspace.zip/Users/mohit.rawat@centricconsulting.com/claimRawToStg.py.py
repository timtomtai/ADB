# Databricks notebook source
df_claim= spark.read.load('/mnt/containershareddna03/Raw/claim_activity_code/claim_activity_code.parquet',format="parquet", header="true", delimiter=None)
df = df_claim
display(df_claim)

# COMMAND ----------

df_claim= spark.read.csv('/mnt/containershareddna03/Raw/claimant/claimant_202203121647079937.csv',header="true",inferSchema ="false")
df = df_claim
display(df_claim)

# COMMAND ----------


display(df)

# COMMAND ----------

df_claim= spark.read.load('/mnt/containershareddna03/Raw/sex/sex_202203141647283421.json', format="json", multiline ="true")
df = df_claim
display(df_claim)

# COMMAND ----------

df = df.withColumn('sex_id',col('sex_id').cast(IntegerType()))
df = df.withColumn('tableorder',col('tableorder').cast(IntegerType()))
df = df.withColumn('iso_bureaucode',col('iso_bureaucode').cast(IntegerType()))
df = df.withColumn('naii_bureaucode',col('naii_bureaucode').cast(IntegerType()))
df = df.withColumn('niss_bureaucode',col('niss_bureaucode').cast(IntegerType()))
df = df.withColumn('pcadded_date',to_date('pcadded_date', 'yyyy-MM-dd HH:mm:ss.SSSSSSS'))
df = df.withColumn('last_modified_date',to_date('last_modified_date', 'yyyy-MM-dd HH:mm:ss.SSSSSSSSS'))
df = df.withColumn('sexcategory_id',col('sexcategory_id').cast(IntegerType()))
df = df.withColumn('version_begin_timestamp',to_date('version_begin_timestamp', 'yyyy-MM-dd HH:mm:ss.SSSSSSS'))
df = df.withColumn('version_end_timestamp',to_date('version_end_timestamp', 'yyyy-MM-dd HH:mm:ss.SSSSSSS'))

# COMMAND ----------

df.show()

# COMMAND ----------

from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import to_date,col
from pyspark.sql.types import StructType,StringType,TimestampType,DecimalType,IntegerType,StructField

# COMMAND ----------

df = df.withColumn('sex_id',col('sex_id').cast(IntegerType()))
df = df.withColumn('tableorder',col('tableorder').cast(IntegerType()))
df = df.withColumn('iso_bureaucode',col('iso_bureaucode').cast(IntegerType()))
df = df.withColumn('naii_bureaucode',col('naii_bureaucode').cast(IntegerType()))
df = df.withColumn('niss_bureaucode',col('niss_bureaucode').cast(IntegerType()))
df = df.withColumn('pcadded_date',unix_timestamp(col('pcadded_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('last_modified_date',unix_timestamp(col('last_modified_date'), 'yyyy-MM-dd HH:mm:ss.SSSSSSSSS').cast(TimestampType()))
df = df.withColumn('sexcategory_id',col('sexcategory_id').cast(IntegerType()))
df = df.withColumn('version_begin_timestamp',unix_timestamp(col('pcadded_date'), 'yyyy-MM-dd HH:mm:ss.SSSSSSS').cast(TimestampType()))
df = df.withColumn('version_end_timestamp',unix_timestamp(col('version_end_timestamp'), 'yyyy-MM-dd HH:mm:ss.SSSSSSS').cast(TimestampType()))

# COMMAND ----------

df = df.withColumn('claimcontrol_id',col('claimcontrol_id').cast(IntegerType()))
df = df.withColumn('claimant_num',col('claimant_num').cast(IntegerType()))
df = df.withColumn('users_id',col('users_id').cast(IntegerType()))
df = df.withColumn('claimantstatus_id',col('claimantstatus_id').cast(IntegerType()))
df = df.withColumn('claimattorney_id',col('claimattorney_id').cast(IntegerType()))
df = df.withColumn('claimfirm_id',col('claimfirm_id').cast(IntegerType()))
df = df.withColumn('claimfinancials_num',col('claimfinancials_num').cast(IntegerType()))
df = df.withColumn('claimanttype_id',col('claimanttype_id').cast(IntegerType()))
df = df.withColumn('relationship_id',col('relationship_id').cast(IntegerType()))
df = df.withColumn('claimcarrier_id',col('claimcarrier_id').cast(IntegerType()))
df = df.withColumn('claimcarrieradjuster_id',col('claimcarrieradjuster_id').cast(IntegerType()))
df = df.withColumn('claimcontrolvehicle_num',col('claimcontrolvehicle_num').cast(IntegerType()))
df = df.withColumn('driver_num',col('driver_num').cast(IntegerType()))
df = df.withColumn('pcadded_date',unix_timestamp(col('pcadded_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('unit_num',col('unit_num').cast(IntegerType()))
df = df.withColumn('applicant_num',col('applicant_num').cast(IntegerType()))
df = df.withColumn('claimcontrolproperty_num',col('claimcontrolproperty_num').cast(IntegerType()))
df = df.withColumn('claimpayee_id',col('claimpayee_id').cast(IntegerType()))
df = df.withColumn('claimclueoperator_id',col('claimclueoperator_id').cast(IntegerType()))
df = df.withColumn('driverexcludetype_id',col('driverexcludetype_id').cast(IntegerType()))
df = df.withColumn('last_modified_date',unix_timestamp(col('last_modified_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('statute_of_limitations',unix_timestamp(col('statute_of_limitations'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('workcomp',col('workcomp').cast(IntegerType()))
df = df.withColumn('prepared_date',unix_timestamp(col('prepared_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('admin_notified_date',unix_timestamp(col('admin_notified_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('claimcareprovider_id',col('claimcareprovider_id').cast(IntegerType()))
df = df.withColumn('occurred_on_premises',col('occurred_on_premises').cast(IntegerType()))
df = df.withColumn('date_of_disability',unix_timestamp(col('date_of_disability'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('time_workday_begin',unix_timestamp(col('time_workday_begin'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('last_work_date',unix_timestamp(col('last_work_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('employer_notified_date',unix_timestamp(col('employer_notified_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('salary_continued',col('salary_continued').cast(IntegerType()))
df = df.withColumn('paid_day_of_injury',unix_timestamp(col('paid_day_of_injury'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('days_per_week',col('days_per_week').cast(IntegerType()))
df = df.withColumn('hours_per_day',col('hours_per_day').cast(IntegerType()))
df = df.withColumn('state_id',col('state_id').cast(IntegerType()))
df = df.withColumn('date_hired',unix_timestamp(col('date_hired'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('dependents',col('dependents').cast(IntegerType()))
df = df.withColumn('medicare_recipient',col('medicare_recipient').cast(IntegerType()))
df = df.withColumn('medicare_waiver_received',col('medicare_waiver_received').cast(IntegerType()))
df = df.withColumn('average_weekly_wage',col('average_weekly_wage').cast(DecimalType()))
df = df.withColumn('contacted_date',unix_timestamp(col('contacted_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('contacted',col('contacted').cast(IntegerType()))
df = df.withColumn('injury',col('injury').cast(IntegerType()))
df = df.withColumn('minor_medical',col('minor_medical').cast(IntegerType()))
df = df.withColumn('occupationtype_id',col('occupationtype_id').cast(IntegerType()))
df = df.withColumn('gross_income',col('gross_income').cast(DecimalType()))
df = df.withColumn('employeed_at_time_of_loss',col('employeed_at_time_of_loss').cast(IntegerType()))
df = df.withColumn('is_insured2',col('is_insured2').cast(IntegerType()))
df = df.withColumn('is_insured1',col('is_insured1').cast(IntegerType()))
df = df.withColumn('is_invalid_iso_data',col('is_invalid_iso_data').cast(IntegerType()))
df = df.withColumn('claimattorney_num',col('claimattorney_num').cast(IntegerType()))
df = df.withColumn('claimfirmattorney_claimfirm_id',col('claimfirmattorney_claimfirm_id').cast(IntegerType()))
df = df.withColumn('is_represented',col('is_represented').cast(IntegerType()))
df = df.withColumn('additionalpolicyholder_num',col('additionalpolicyholder_num').cast(IntegerType()))
df = df.withColumn('weekly_benefit_amount',col('weekly_benefit_amount').cast(DecimalType()))
df = df.withColumn('typeofsettlementlossconditioncode_id',col('typeofsettlementlossconditioncode_id').cast(IntegerType()))
df = df.withColumn('temporarydisabilitybenefitextinguishmentcode_id',col('temporarydisabilitybenefitextinguishmentcode_id').cast(IntegerType()))
df = df.withColumn('medicalextinguishmentindicator_yesno_id',col('medicalextinguishmentindicator_yesno_id').cast(IntegerType()))
df = df.withColumn('jurisdiction_state_id',col('jurisdiction_state_id').cast(IntegerType()))
df = df.withColumn('averageweeklywagecode_id',col('averageweeklywagecode_id').cast(IntegerType()))
df = df.withColumn('actlossconditioncode_id',col('actlossconditioncode_id').cast(IntegerType()))
df = df.withColumn('reported_to_cms_update',col('reported_to_cms_update').cast(IntegerType()))
df = df.withColumn('reported_to_cms_last_reported_date',unix_timestamp(col('reported_to_cms_last_reported_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('reported_to_cms_date',unix_timestamp(col('reported_to_cms_date'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('reported_to_cms',col('reported_to_cms').cast(IntegerType()))
df = df.withColumn('version_begin_timestamp',unix_timestamp(col('version_begin_timestamp'), 'yyyy-MM-dd HH:mm:ss.SSSSSSS').cast(TimestampType()))
df = df.withColumn('version_end_timestamp',unix_timestamp(col('version_end_timestamp'), 'yyyy-MM-dd HH:mm:ss.SSSSSSS').cast(TimestampType()))


# COMMAND ----------


display(df)

df.schema


# COMMAND ----------

from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import to_date,col
from pyspark.sql.types import StructType,StringType,TimestampType,DecimalType,IntegerType,StructField

df = df.withColumn('LOSS_DATETIME',unix_timestamp(col('LOSS_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('FIRST_NOTICE_OF_LOSS_DATETIME',unix_timestamp(col('FIRST_NOTICE_OF_LOSS_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
df = df.withColumn('CLAIM_SETUP_DATETIME',unix_timestamp(col('CLAIM_SETUP_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
df = df.withColumn('CLAIM_OPEN_DATETIME',unix_timestamp(col('CLAIM_OPEN_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
df = df.withColumn('CLAIM_CLOSE_DATETIME',unix_timestamp(col('CLAIM_CLOSE_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
df = df.withColumn('CLAIM_REOPEN_DATETIME',unix_timestamp(col('CLAIM_REOPEN_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
df = df.withColumn('CLAIM_FIRST_CLOSE_DATETIME',unix_timestamp(col('CLAIM_FIRST_CLOSE_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
df = df.withColumn('CLAIM_LATEST_REOPEN_DATETIME',unix_timestamp(col('CLAIM_LATEST_REOPEN_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
df = df.withColumn('CLAIM_FAULT_FLAG',col('CLAIM_FAULT_FLAG').cast(IntegerType()))
df = df.withColumn('REQUESTED_CLAIM_AMOUNT',col('REQUESTED_CLAIM_AMOUNT').cast(DecimalType()))
df = df.withColumn('POLICY_DEDUCTIBLE_AMOUNT',col('POLICY_DEDUCTIBLE_AMOUNT').cast(DecimalType()))
df = df.withColumn('POLICY_LIMIT_AMOUNT',col('POLICY_LIMIT_AMOUNT').cast(DecimalType()))



# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import to_date,col
from pyspark.sql import functions as F
from pyspark.sql.types import StructType,StringType,TimestampType,DecimalType,IntegerType,StructField
df_claim = df_claim.withColumn('LOSS_DATETIME',to_timestamp(unix_timestamp(col('LOSS_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast('timestamp')))



display(df_claim)



# COMMAND ----------

f = df.withColumn(
            'new_date',
                F.to_date(
                    F.unix_timestamp('STRINGCOLUMN', 'MM-dd-yyyy').cast('timestamp')))

# COMMAND ----------

df_claim = df_claim.withColumn('LOSS_DATETIME',to_date('LOSS_DATETIME', 'y-M-d H:m:s.S').withColumn('FIRST_NOTICE_OF_LOSS_DATETIME',to_date('FIRST_NOTICE_OF_LOSS_DATETIME', 'y-M-d H:m:s.S')).withColumn('CLAIM_SETUP_DATETIME',to_date('CLAIM_SETUP_DATETIME', 'y-M-d'))df_claim = df_claim.withColumn('LOSS_DATETIME',to_date('LOSS_DATETIME', 'y-M-d H:m:s.S').withColumn('FIRST_NOTICE_OF_LOSS_DATETIME',to_date('FIRST_NOTICE_OF_LOSS_DATETIME', 'y-M-d H:m:s.S')).withColumn('CLAIM_SETUP_DATETIME',to_date('CLAIM_SETUP_DATETIME', 'y-M-d')).withColumn('CLAIM_OPEN_DATETIME',to_date('CLAIM_OPEN_DATETIME', 'y-M-d')).withColumn('CLAIM_CLOSE_DATETIME',to_date('CLAIM_CLOSE_DATETIME', 'y-M-d')).withColumn('CLAIM_REOPEN_DATETIME',to_date('CLAIM_REOPEN_DATETIME', 'y-M-d')).withColumn('CLAIM_FIRST_CLOSE_DATETIME',to_date('CLAIM_FIRST_CLOSE_DATETIME', 'y-M-d')).withColumn('CLAIM_LATEST_REOPEN_DATETIME',to_date('CLAIM_LATEST_REOPEN_DATETIME', 'y-M-d')).withColumn('CLAIM_FAULT_FLAG',col('CLAIM_FAULT_FLAG').cast(IntegerType())).withColumn('REQUESTED_CLAIM_AMOUNT',col('REQUESTED_CLAIM_AMOUNT').cast(DecimalType())).withColumn('POLICY_DEDUCTIBLE_AMOUNT',col('POLICY_DEDUCTIBLE_AMOUNT').cast(DecimalType())).withColumn('POLICY_LIMIT_AMOUNT',col('POLICY_LIMIT_AMOUNT').cast(DecimalType())).withColumn('CLAIM_REOPEN_DATETIME',to_date('CLAIM_REOPEN_DATETIME', 'y-M-d')).withColumn('CLAIM_FIRST_CLOSE_DATETIME',to_date('CLAIM_FIRST_CLOSE_DATETIME', 'y-M-d')).withColumn('CLAIM_LATEST_REOPEN_DATETIME',to_date('CLAIM_LATEST_REOPEN_DATETIME', 'y-M-d')).withColumn('CLAIM_FAULT_FLAG',col('CLAIM_FAULT_FLAG').cast(IntegerType())).withColumn('REQUESTED_CLAIM_AMOUNT',col('REQUESTED_CLAIM_AMOUNT').cast(DecimalType())).withColumn('POLICY_DEDUCTIBLE_AMOUNT',col('POLICY_DEDUCTIBLE_AMOUNT').cast(DecimalType())).withColumn('POLICY_LIMIT_AMOUNT',col('POLICY_LIMIT_AMOUNT').cast(DecimalType()))

# COMMAND ----------

.withColumn('CLAIM_SETUP_DATETIME',to_date('CLAIM_SETUP_DATETIME', 'y-M-d'))
.withColumn('CLAIM_OPEN_DATETIME',to_date('CLAIM_OPEN_DATETIME', 'y-M-d'))
                               .withColumn('CLAIM_CLOSE_DATETIME',to_date('CLAIM_CLOSE_DATETIME', 'y-M-d'))
                               .withColumn('CLAIM_REOPEN_DATETIME',to_date('CLAIM_REOPEN_DATETIME', 'y-M-d'))
                               .withColumn('CLAIM_FIRST_CLOSE_DATETIME',to_date('CLAIM_FIRST_CLOSE_DATETIME', 'y-M-d'))
                               .withColumn('CLAIM_LATEST_REOPEN_DATETIME',to_date('CLAIM_LATEST_REOPEN_DATETIME', 'y-M-d'))
                               .withColumn('CLAIM_FAULT_FLAG',col('CLAIM_FAULT_FLAG').cast(IntegerType()))
                               .withColumn('REQUESTED_CLAIM_AMOUNT',col('REQUESTED_CLAIM_AMOUNT').cast(DecimalType()))
                               .withColumn('POLICY_DEDUCTIBLE_AMOUNT',col('POLICY_DEDUCTIBLE_AMOUNT').cast(DecimalType()))
                               .withColumn('POLICY_LIMIT_AMOUNT',col('POLICY_LIMIT_AMOUNT').cast(DecimalType()))

# COMMAND ----------

from pyspark.sql.types import StructType,StringType,TimestampType,DecimalType,IntegerType,StructField

apply_schema=StructType([StructField('CLAIM_NK',StringType(),False),
	StructField('CLAIM_POLICY_FNK',StringType(),True),
	StructField('CATASTROPHE_FNK',StringType(),True),
	StructField('LITIGATION_FNK',StringType(),True),
	StructField('CLAIM_NUMBER_NAME',StringType(),True),
	StructField('LEGACY_CLAIM_NUMBER_NAME',StringType(),True),
	StructField('LOSS_DATETIME',TimestampType(),True),
	StructField('FIRST_NOTICE_OF_LOSS_DATETIME',TimestampType(),True),
	StructField('CLAIM_SETUP_DATETIME',TimestampType(),True),
	StructField('CLAIM_OPEN_DATETIME',TimestampType(),True),
	StructField('CLAIM_CLOSE_DATETIME',TimestampType(),True),
	StructField('CLAIM_REOPEN_DATETIME',TimestampType(),True),
	StructField('CLAIM_FIRST_CLOSE_DATETIME',TimestampType(),True),
	StructField('CLAIM_LATEST_REOPEN_DATETIME',TimestampType(),True),
	StructField('OCCURRENCE_NAME',StringType(),True),
	StructField('CAUSE_OF_LOSS_CODE',StringType(),True),
	StructField('CAUSE_OF_LOSS_DESC',StringType(),True),
	StructField('CAUSE_OF_LOSS_CATEGORY_NAME',StringType(),True),
	StructField('LOSS_TYPE_CODE',StringType(),True),
	StructField('LOSS_DESC',StringType(),True),
	StructField('CLAIM_EVENT_TYPE_CODE',StringType(),True),
	StructField('CLAIM_EVENT_TYPE_NAME',StringType(),True),
	StructField('CLAIM_TYPE_DESC',StringType(),True),
	StructField('LOSS_LOCATION_ADDRESS_1_ADDRESS',StringType(),True),
	StructField('LOSS_LOCATION_ADDRESS_2_ADDRESS',StringType(),True),
	StructField('LOSS_LOCATION_CITY_ADDRESS',StringType(),True),
	StructField('LOSS_LOCATION_STATE_ADDRESS',StringType(),True),
	StructField('LOSS_LOCATION_STATE_CODE',StringType(),True),
	StructField('LOSS_LOCATION_ZIP_ADDRESS',StringType(),True),
	StructField('CLOSE_REASON_DESC',StringType(),True),
	StructField('AGENT_REGION_CODE',StringType(),True),
	StructField('CLAIM_FAULT_FLAG',IntegerType(),True),
	StructField('CLAIM_SEVERITY_DESC',StringType(),True),
	StructField('FRAUD_CODE',StringType(),True),
	StructField('REQUESTED_CLAIM_AMOUNT',DecimalType(),True),
	StructField('POLICY_DEDUCTIBLE_AMOUNT',DecimalType(),True),
	StructField('POLICY_LIMIT_AMOUNT',DecimalType(),True),
	StructField('BUSINESS_EFFECTIVE_BEGIN_DATETIME',TimestampType(),True),
	StructField('BUSINESS_EFFECTIVE_END_DATETIME',TimestampType(),True),
	StructField('RECORD_VALID_BEGIN_DATETIME',TimestampType(),True),
	StructField('RECORD_VALID_END_DATETIME',TimestampType(),True),
	StructField('ENTERED_DATETIME',TimestampType(),True),
	StructField('UPDATED_DATETIME',TimestampType(),True),
	StructField('PROCESS_BATCH_ID',IntegerType(),True),
	StructField('INVALIDATED_BATCH_LOOP_SEQUENCE',StringType(),True),
	StructField('INTRA_BATCH_LOOP_SEQUENCE',IntegerType(),True),
	StructField('GENERATED_RECORD_FLAG',IntegerType(),True),
	StructField('CHANGE_HASH',StringType(),True),
	StructField('SOURCE_SYSTEM_CODE',StringType(),True)
])




# COMMAND ----------

df_claim_new = sqlContext.createDataFrame(df_claim.rdd, apply_schema)

# COMMAND ----------

https://chih-ling-hsu.github.io/2017/03/28/how-to-change-schema-of-a-spark-sql-dataframe

# COMMAND ----------

display(df_claim_new)

# COMMAND ----------

dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/config/data_quality_config__6_.txt", "/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt", recurse=True)

# COMMAND ----------

dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/controllerRawToStg", "/FileStore/tables/DataEng/RawtoStg/controllerRawToStg.py")

# COMMAND ----------

dbutils.fs.cp("/FileStore/tables/DataEng" , "/mnt/containershareddna03/bkkp/code/", True)

# COMMAND ----------

dbutils.fs.mv("/FileStore/tables/DataEng/StgtoInt/config/scdUpsert-1.py", "/FileStore/tables/DataEng/StgtoInt/config/scdUpsert.py")

# COMMAND ----------


dbutils.fs.mv("/FileStore/tables/DataEng/StgtoInt/claimStatusStgToInt-2.py", "/FileStore/tables/DataEng/StgtoInt/claimStatusStgToInt.py")

# COMMAND ----------

dbutils.fs.mv("/FileStore/tables/DataEng/InttoPri/config/martLoader-1.py", "/FileStore/tables/DataEng/InttoPri/config/martLoader.py")
#/FileStore/tables/DataEng/StgtoInt/claimStgToInt-1.py config/scdUpsert-1.py

# COMMAND ----------

dbutils.fs.mv("/FileStore/tables/DataEng/InttoPri/dimClaimIntToPri-1.py", "/FileStore/tables/DataEng/InttoPri/dimClaimIntToPri.py")

# COMMAND ----------

dbutils.fs.ls("dbfs:/databricks/")

# COMMAND ----------

# MAGIC %fs ls /dbfs/mnt/containershareddna03/Raw/claim/*.*

# COMMAND ----------

dbutils.fs.mv("/FileStore/tables/DataEng/InttoPri/controllerIntToPri-1.py", "/FileStore/tables/DataEng/InttoPri/controllerIntToPri.py")

# COMMAND ----------

import glob

abc = (glob.glob('/databricks/driver/*.*'))
abc.sort()

print(abc)

#distFile = sc.textFile("/databricks/driver/2022-03-13_1647199537RawtoStg.log").collect()

#for row in distFile:
    #print(row[0] + "," +str(row[1]))

# COMMAND ----------

with open('/databricks/driver/2022-03-23_1648069871IntToPri.log') as f:
    lines = f.readlines()
    print(lines)
    #for lines in (file.readlines() [-N:]):
    #        print(line, end ='')
    f.close()

# COMMAND ----------

import sys
# We are inserting below sys path so that we can import any python file from this location
sys.path.insert(0,'/dbfs/FileStore/tables/DataEng/RawtoStg/')

import logging
from config.logging_init_file import init_loging
from config.rawToStgAbstract import rawToStgAbstract
from config.data_validator import dataValidator
from pyspark.sql import SparkSession 
import glob
import shutil
from pyspark.sql.functions import to_timestamp
from pyspark.sql.functions import unix_timestamp
from pyspark.sql.functions import to_date,col
from pyspark.sql.types import StructType,StringType,TimestampType,DecimalType,IntegerType,StructField

class claimRawtoStg(rawToStgAbstract):
    def __init__(self,src,dst):
        self.logger, self.file_name = init_loging(__name__)
        self.logger.info("Started Initializing....")
        self.source_path = glob.glob('/dbfs'+src)
        self.dest_path = dst  
        self.spark = SparkSession.builder.master("master").appName(__name__).enableHiveSupport().getOrCreate()
        self.logger.info("Initialization is completed")

    def read(self):
        self.logger.info("Started Reading file of input file")
        try:
            source_format = "csv" # This can be "csv", "json", "parquet" depending upon the source file
            source_delimiter = "," # This can be "," or anyother delimiter or None
            source_header = True # This can be True or False or None
            self.source_file = self.spark.read.load(self.source_path,
                     format=source_format, delimiter=source_delimiter, header=source_header)
            self.logger.info("Reading of input file is completed")
        except:
            self.logger.critical("Issue in reading the input file")

    def validate(self):
        self.dq_config_parser_name ="claim"
        self.logger.info("Started data validation")
        filtered_df , errordf  = dataValidator ("/dbfs/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt", src_Initials= self.dq_config_parser_name, input_df= self.source_file) 
        errordf.toPandas().to_csv("/dbfs/mnt/containershareddna03/logs/Data_Validation_Logs/claim/"+self.file_name+".csv")
        self.logger.info("Number of bad records: ",errordf.count())
        self.logger.info("Data validation is completed")

    def trans(self):
        self.logger.info("Started Data transformation")
        self.source_file = self.source_file.withColumn('LOSS_DATETIME',unix_timestamp(col('LOSS_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('FIRST_NOTICE_OF_LOSS_DATETIME',unix_timestamp(col('FIRST_NOTICE_OF_LOSS_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIM_SETUP_DATETIME',unix_timestamp(col('CLAIM_SETUP_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIM_OPEN_DATETIME',unix_timestamp(col('CLAIM_OPEN_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIM_CLOSE_DATETIME',unix_timestamp(col('CLAIM_CLOSE_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIM_REOPEN_DATETIME',unix_timestamp(col('CLAIM_REOPEN_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIM_FIRST_CLOSE_DATETIME',unix_timestamp(col('CLAIM_FIRST_CLOSE_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIM_LATEST_REOPEN_DATETIME',unix_timestamp(col('CLAIM_LATEST_REOPEN_DATETIME'), 'yyyy-MM-dd').cast(TimestampType()))
        self.source_file = self.source_file.withColumn('CLAIM_FAULT_FLAG',col('CLAIM_FAULT_FLAG').cast(IntegerType()))
        self.source_file = self.source_file.withColumn('REQUESTED_CLAIM_AMOUNT',col('REQUESTED_CLAIM_AMOUNT').cast(DecimalType()))
        self.source_file = self.source_file.withColumn('POLICY_DEDUCTIBLE_AMOUNT',col('POLICY_DEDUCTIBLE_AMOUNT').cast(DecimalType()))
        self.source_file = self.source_file.withColumn('POLICY_LIMIT_AMOUNT',col('POLICY_LIMIT_AMOUNT').cast(DecimalType()))
        self.logger.info("Completed Data transformation")

    def store(self):
        self.logger.info("Started storing the file")
        self.source_file.write.mode("Overwrite").parquet(self.dest_path)
        shutil.move("/dbfs"+self.source_path,"/dbfs/mnt/containershareddna03/Raw/claim/processed/"+self.file_name+"claim.csv")
        self.logger.info("Storing of file is completed")

# COMMAND ----------

import glob
path= glob.glob('/dbfs/mnt/containershareddna03/Raw/claim/*.*')
#print(path)
#path = path.replace('/dbfs','')
#print(path)
test_list = [i.replace('/dbfs','') for i in path]
print(test_list)
#path = ['/dbfs/mnt/containershareddna03/Raw/claim/2022-03-13claim.csv']
spark.read.load(test_list,format="csv").show()
#spark.read.load(path,format="csv",inferSchema ="false").show()

# COMMAND ----------

def partfilemover(source_path,file_pattern,target_file, **kwargs):

	import shutil
	import os
	from datetime import datetime
	import glob
	
	target_dateformat=kwargs.get('target_dateformat', 'None')
	source_path=source_path
	file_pattern=file_pattern
	
	filename, file_extension = os.path.splitext(target_file)
	if target_dateformat == "None" :
		target_file=target_file
	else:
		now = datetime.now()
		datetime_str = now.strftime(target_dateformat)
		target_file=filename+'_'+datetime_str+file_extension
	
	files_at_path= [fd for fd in glob.glob(source_path+file_pattern)]
	for items in files_at_path:
		try:
			if item == "_SUCCESS" :
				target_file=target_file+'/'+item
			shutil.move(items, target_file)
		except Exception as x :
			print(sys.exc_info())
			sys.exit("File movement failed")
		
		
		
		