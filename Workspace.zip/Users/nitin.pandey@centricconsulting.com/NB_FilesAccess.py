# Databricks notebook source
dbutils.fs.mount(
    source = "wasbs://nitincontainer@storageaccnitin.blob.core.windows.net",
    mount_point = "/mnt/nitincontainer",
    extra_configs = {"fs.azure.account.key.storageaccnitin.blob.core.windows.net":dbutils.secrets.get(scope = "scopenitin", key = "secretnitin")})


# COMMAND ----------

# MAGIC %fs ls /mnt/nitincontainer/

# COMMAND ----------

display(dbutils.fs.mounts())