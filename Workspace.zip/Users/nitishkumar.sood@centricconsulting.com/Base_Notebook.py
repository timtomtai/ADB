# Databricks notebook source
# Creating widgets for leveraging parameters, and printing the parameters

dbutils.widgets.text("InputParam1", "3","")
Param_1 = dbutils.widgets.get("InputParam1")
print (Param_1)



# COMMAND ----------

database = "dbdna01"
table = "Demo_Connectivity"
user = "admindna01"
password  = "admindna@01"

query = "Select * from demo_connectivity where id=" + getArgument('InputParam1')
jdbcurl="jdbc:sqlserver://dbserverdna01.database.windows.net:1433;databaseName=dbdna01"


##query to get Selected data of a table from sql server to DF

jdbcQueryDF = spark.read.format("jdbc") \
    .option("url", jdbcurl) \
    .option("query", query) \
    .option("user", user) \
    .option("password", password) \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .load()

display(jdbcQueryDF)


# COMMAND ----------



# COMMAND ----------


from pyspark.sql.functions import *
df=spark.createDataFrame([["02-03-2013"],["05-06-2023"]],["input"])

df = df.select(col("input"),to_date(col("input"),format = "dd-mm-yyyy").alias("date")) 

df.show()


# COMMAND ----------

from pyspark.sql.functions import year
df=spark.createDataFrame([["02-03-2013"],["05-06-2023"]],["input"])
df.show()
