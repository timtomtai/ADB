# Databricks notebook source

# File location and type
file_location = "/FileStore/tables/Demo.CSV"
file_type = "CSV"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
df = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df)


# COMMAND ----------


database = "dbdna01"
table = "Demo_Connectivity"
user = "admindna01"
password  = "admindna@01"

query = "Select * from demo_connectivity where id=1"



jdbcurl="jdbc:sqlserver://dbserverdna01.database.windows.net:1433;databaseName=dbdna01"

##query to get complete data of a table from sql server to DF
jdbctableDF = spark.read.format("jdbc") \
    .option("url", jdbcurl) \
    .option("dbtable", table) \
    .option("user", user) \
    .option("password", password) \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .load()

display(jdbctableDF)

##query to get Selected data of a table from sql server to DF

jdbcQueryDF = spark.read.format("jdbc") \
    .option("url", jdbcurl) \
    .option("query", query) \
    .option("user", user) \
    .option("password", password) \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .load()

display(jdbcQueryDF)





# COMMAND ----------


# to append data in existing table

jdbcQueryDF.write.format("jdbc")\
      .option("url", jdbcurl)\
      .option("user", user) \
      .option("password", password) \
      .option("dbtable", table)\
      .mode("append")\
      .save()

# COMMAND ----------


# to create new table in database with df data 


df.write.format("jdbc") \
    .option("url", jdbcurl) \
     .option("dbtable", table) \
    .option("user", user) \
    .option("password", password) \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .save()




# COMMAND ----------

spark = sqlContext.sparkSession

jdbcurl="jdbc:sqlserver://dbserverdna01.database.windows.net:1433;databaseName=dbdna01"

 

database = "dbdna01"
table = "Demo_Connectivity"
user = "admindna01"
password  = "admindna@01"
databaseserver = "dbserverdna01.database.windows.net"

jdbcDF = spark.read.format("jdbc") \
    .option("url", f"jdbc:sqlserver://{databaseserver}:1433;databaseName={database}") \
    .option("dbtable", "Demo_Connectivity") \
    .option("user", user) \
    .option("password", password) \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .load()

jdbcDF.show()