# Databricks notebook source
# File location and type
file_location = "/FileStore/tables/Demo.CSV"
file_type = "CSV"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
df = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df)

# COMMAND ----------

# Delta lakes temp table, limited to current notebook only
temp_table_name = "Demo_Delta"
df.createOrReplaceTempView(temp_table_name)

permanenttablename = "Demo_Delta_Table"
df.write.format("Delta").saveAsTable(permanenttablename)


# COMMAND ----------

# MAGIC 
# MAGIC %sql
# MAGIC 
# MAGIC select * from Demo_Delta;
# MAGIC select * from Demo_Delta_Table;

# COMMAND ----------

read_format = 'delta'
write_format = 'delta'
load_path = '/databricks-datasets/learning-spark-v2/people/people-10m.delta'
save_path = '/tmp/delta/people-10m'
table_name = 'default.people10m'

people = spark \
  .read \
  .format(read_format) \
  .load(load_path)