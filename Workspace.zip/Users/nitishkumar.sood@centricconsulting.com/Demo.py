# Databricks notebook source
import pandas as pd
pd.read_parquet('/dbfs/mnt/containershareddna01/DemoSourceData/claimant_type.parquet', engine='pyarrow')

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE rectangles(a INT, b INT,
# MAGIC                           area INT GENERATED ALWAYS AS  (IDENTITY)  [ START WITH 1 ] [ INCREMENT BY 1 ] );

# COMMAND ----------

df = spark.read.load('/dbfs/mnt/containershareddna01/DemoSourceData/claimanttype.parquet',
                format='parquet', header=None)