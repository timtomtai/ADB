# Databricks notebook source
# MAGIC 
# MAGIC %run /Users/nitishkumar.sood@centricconsulting.com/ETL_Operations/read_write_file

# COMMAND ----------

#geeting data from config file for sql connection
config_df =readSourceFile ("/FileStore/tables/Config_ADF-1.csv", format="csv" ,delimiter=",", header = "true" )
config_df.show()


# COMMAND ----------

#config_df.where(config_df.property=='table').show()
src = 'Src1_'

var1 = config_df.select("value").where(config_df.property== src +'table').collect()[0][0]

#config_df.registerTempTable('config_temptable');

print(var1)



# COMMAND ----------

databasename = "dbdna01"
table = "Demo_Connectivity"
user = "admindna01"
password  = "admindna@01"
databaseserver = "dbserverdna01.database.windows.net"
driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"


query = "Select * from demo_connectivity where id=1"


jdbcurl = f"jdbc:sqlserver://{databaseserver}:1433;databaseName={databasename}"

jdbcDF = spark.read.format("jdbc") \
                   .option("url", jdbcurl) \
                   .option("dbtable", table) \
                   .option("user", user) \
                   .option("password", password) \
                   .option("driver", driver) \
         .load()

jdbcDF.show()

config_df =readDatabaseSource (filePath = "/FileStore/tables/Config_ADF-1.csv", format="csv" ,delimiter=",", header = "true" )
#config_df.show()


# COMMAND ----------

def readDatabaseSource(filePath,format, **kwargs) :
    
    
    schema = kwargs.get('schema', None)
    badRecordsPath = kwargs.get ('badRecordsPath', None)
    delimiter = kwargs.get ('delimiter', None)
    pathGlobFilter = kwargs.get ('pathGlobFilter', None)
    header = kwargs.get ('header', None)
    src = kwargs.get ('src_Initials', None)
    tablename = kwargs.get ('tablename', None)
    query = kwargs.get ('query', None)
    
    config_df = spark.read.load(filePath,
                   format=format, schema=schema, delimiter=delimiter, header=header)
    
  
    databaseDriver = config_df.select("value").where(config_df.property== src+'driver').collect()[0][0]
    
    
    print(databaseDriver)     
    

# COMMAND ----------

readDatabaseSource ("/FileStore/tables/Config_ADF-1.csv", format="csv" ,delimiter=",", header = "true", src_Initials = "Src1_")