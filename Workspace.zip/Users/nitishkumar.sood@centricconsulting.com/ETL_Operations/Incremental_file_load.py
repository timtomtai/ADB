# Databricks notebook source
# MAGIC %sql
# MAGIC 
# MAGIC Select * from scd_lastprocessed_date ;
# MAGIC --update scd_lastprocessed_date set processed_date =  '2014-10-01'

# COMMAND ----------

def Scd_filteration(SourcefilePath,format,date_column_index,datecolumn_format, **kwargs) :
    from pyspark.sql.functions import to_date
    #from pyspark.sql.functions import unix_timestamp, from_unixtime
    #spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    delimiter = kwargs.get ('delimiter', None)
    header = kwargs.get ('header', None)
    
    try:
        #getting last processed date from delta table 
        output=spark.sql('select  processed_date from default.scd_lastprocessed_date where filepath = "%s" ' % (SourcefilePath))
        
        #setting default value for last_processed_date
        if output.count()>0:
            Last_processed_date = output.select("processed_date").collect()[0][0]
        else:
            Last_processed_date = "1900-01-01"    
        #print(Last_processed_date)
        #reading tge source data file
        df_file_read = spark.read.load(SourcefilePath,
                     format=format,  delimiter=delimiter, header=header)
        
        date_column_name = df_file_read.schema.names[date_column_index]
        
        df_file_read = df_file_read.filter(to_date(date_column_name, datecolumn_format) >= Last_processed_date)
        
        #df_file_read = data.filter(from_unixtime(unix_timestamp(df_file_read.Ship_Date, 'MM/dd/yyyy')) < f.unix_timestamp(f.lit('2014-11-01 00:00:00')).cast('timestamp'))
        spark.sql('update default.scd_lastprocessed_date set processed_date = current_date()  where filepath = "%s" ' % (SourcefilePath) )
        
        return df_file_read 
    except Exception as e:
        print("Error in Reading Source File")
    
    

    
    

# COMMAND ----------

df_sales = Scd_filteration("/FileStore/tables/Sales_Records.csv",format="csv", header = "true", delimiter = ",", date_column_index = 5,datecolumn_format = "m/d/y")
df_sales.show()
