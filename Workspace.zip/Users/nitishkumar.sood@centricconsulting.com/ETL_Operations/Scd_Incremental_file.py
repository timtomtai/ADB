# Databricks notebook source
# MAGIC %sql
# MAGIC 
# MAGIC Select * from scd_lastprocessed_date ;
# MAGIC update scd_lastprocessed_date set processed_date =  '2014-10-01'

# COMMAND ----------

def Scd_filteration(SourcefilePath,format,date_column_index,datecolumn_format, **kwargs) :
    from pyspark.sql.functions import to_date
    spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

    delimiter = kwargs.get ('delimiter', None)
    header = kwargs.get ('header', None)
    
    try:
        #getting last processed date from delta table 
        output=spark.sql("select  processed_date from default.scd_lastprocessed_date")
        Last_processed_date = output.select("processed_date").collect()[0][0]

        #reading tge source data file
        df_file_read = spark.read.load(SourcefilePath,
                     format=format,  delimiter=delimiter, header=header)
        
        date_column_name = df_file_read.schema.names[date_column_index]
        
        df_file_read = df_file_read.withColumn(date_column_name,to_date(df_file_read[date_column_name], datecolumn_format))
        
        df_file_read = df_file_read.filter(df_file_read[date_column_name] >= Last_processed_date)
        
        spark.sql("update default.scd_lastprocessed_date set processed_date = current_date() ")
        
        return df_file_read 
    except Exception as e:
        print("Error in Reading Source File")
    
    

    
    

# COMMAND ----------

df_sales.filter(df_sales["Order Date"] =='2014-10-28').show()

# COMMAND ----------

df_sales = Scd_filteration("/FileStore/tables/Sales_Records.csv",format="csv", header = "true", delimiter = ",", date_column_index = 5,datecolumn_format = "MM/DD/YYYY")
df_sales.show()


# COMMAND ----------

#df_sales = Scd_filteration("/FileStore/tables/Sales_Records.csv",format="csv", header = "true", delimiter = ",", date_column_index = 5,datecolumn_format = "m/dd/yyyy")
#df_sales.show()

date_column_name = "Order Date"

output=spark.sql("select  processed_date from default.scd_lastprocessed_date")
Last_processed_date = output.select("processed_date").collect()[0][0]


df_sales = df_sales.filter(df_sales[date_column_name] >= Last_processed_date)
df_sales.show()

# COMMAND ----------

#df_sales.select("Order Date").dtypes
from pyspark.sql.functions import *
spark.sql("set spark.sql.legacy.timeParserPolicy=LEGACY")

date_column_name = "Order Date"
date_format ='m/dd/yyyy'

#df1 = df_sales.withColumn('OrderDate',to_date(df_sales[date_column_name], 'yyyy-MM-dd'))

df_sales = df_sales.withColumn('Order Date',to_date(df_sales[date_column_name], date_format))
df_sales.show()

#df_sales.filter(df_sales[date_column_name] >= '2012-01-22').show

#date_column_name = 'Order Date'
#df_sales.where(date_column_name.date_column_name =='2010-06-27').show()

#df_sales.filter(df_sales[date_column_name] >= '2010-06-27').show() 


# COMMAND ----------

output=spark.sql("select  processed_date from default.scd_lastprocessed_date")

Last_processed_date = output.select("processed_date").collect()[0][0]

date_column_name = "Order Date"
df_sales = df_sales.filter(df_sales[date_column_name] >= Last_processed_date)
df_sales.show()


# COMMAND ----------

# MAGIC %sql
# MAGIC select * from scd_lastprocessed_date

# COMMAND ----------

spark.sql("set spark.sql.legacy.timeParserPolicy=CORRECTED")
from pyspark.sql.functions import *
df=spark.createDataFrame([["02-03-2013"],["05-6-2023"]],["input"])

df = df.select(col("input"),to_date(col("input")).alias("date")) 

df.show()
