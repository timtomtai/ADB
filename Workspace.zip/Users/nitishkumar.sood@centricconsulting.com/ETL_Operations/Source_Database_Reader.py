# Databricks notebook source
#Description : function[readDatabaseSource] is responsible to fetch data from SQL database Table/Query.
# InPut Parameters :
#       configfilePath: Path for reading the configuration file to read variables. 
#       format: file format of configuration file.
#       **kwargs: config file level parameters : delimiter, header
#                 Database Level Parameters : 
#                                src_Initials: it will be initials(Src1, Src2 etc) of your databse level variable names in config file, it will help us in case when we have                                                    multiple sources in a config file.Our function will connect to the requested connection only. suppose you need to make a                                                        connection for 1st source then you have to append the same initials in variable key in config file and need to pass the same to                                                  the function, it will connect the same database automatically. 
#                                tablename:     it will accept the database table name from where you need to populate the data.
#                                query    :     in case you need to get data with a SQL query, you can pass the same in this parameter. it will work for joins, fileration also.
#                          NOTE : funtion will accept one value out of tablename/query at a time. so in function call wither you can pass tablename or query. 
#       Sample config file(CSV):        
        property,value #Header
        Src1_databasename,dbdna01
        Src1_table,Demo_Connectivity
        Src1_user,admindna01
        Src1_password,admindna@01
        Src1_databaseserver,dbserverdna01.database.windows.net
        Src1_driver,com.microsoft.sqlserver.jdbc.SQLServerDriver
#       function is developed to accept above mentioned property names for now, if any one changes there names in config file then there will be a need to update the function           accordingly.
#
#
#
#

# COMMAND ----------

def readDatabaseSource(configfilePath,format, **kwargs) :
    
    delimiter = kwargs.get ('delimiter', None)
    header = kwargs.get ('header', None)
    src = kwargs.get ('src_Initials', None)
    tablename = kwargs.get ('tablename', None)
    query = kwargs.get ('query', None)
    
    try:
        config_df = spark.read.load(configfilePath,
                format=format,  delimiter=delimiter, header=header)
    
        databaseName   = config_df.select("value").where(config_df.property== src+'_databasename').collect()[0][0]
        userName       = config_df.select("value").where(config_df.property== src+'_user').collect()[0][0]
        password       = config_df.select("value").where(config_df.property== src+'_password').collect()[0][0]
        databaseServer = config_df.select("value").where(config_df.property== src+'_databaseserver').collect()[0][0]
        databaseDriver = config_df.select("value").where(config_df.property== src+'_driver').collect()[0][0]
    
        jdbcurl = f"jdbc:sqlserver://{databaseServer}:1433;databaseName={databaseName}"
    
        if tablename is not None:
            jdbcDF = spark.read.format("jdbc") \
                       .option("url", jdbcurl) \
                   .option("dbtable", tablename) \
                   .option("user", userName) \
                   .option("password", password) \
                   .option("driver", databaseDriver) \
                   .load()
            return jdbcDF
        else :
            jdbcDF = spark.read.format("jdbc") \
                   .option("url", jdbcurl) \
                   .option("query", query) \
                   .option("user", userName) \
                   .option("password", password) \
                   .option("driver", databaseDriver) \
                   .load()
            return jdbcDF
    except Exception as e:
         print("Error in Reading Source data")
        


# COMMAND ----------

#example for reading data with a tablename
databaseable = readDatabaseSource ("/FileStore/tables/Config_ADF-1.csv", format="csv" ,delimiter=",", header = "true",tablename= "Demo_Connectivity", src_Initials= "Src1" )
databaseable.show()

# COMMAND ----------

#example for reading data with a query
databaseable_query = readDatabaseSource ("/FileStore/tables/Config_ADF-1.csv", format="csv" ,delimiter=",", header = "true",query= "Select d.* from demo_connectivity d inner join demo_connectivity b on d.id = b.id  where d.id=1", src_Initials= "Src1" )
databaseable_query.show()