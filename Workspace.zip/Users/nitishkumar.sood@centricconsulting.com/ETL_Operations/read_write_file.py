# Databricks notebook source
def readSourceFile(filePath,format, **kwargs) :
    
    
    schema = kwargs.get('schema', None)
    badRecordsPath = kwargs.get ('badRecordsPath', None)
    delimiter = kwargs.get ('delimiter', None)
    pathGlobFilter = kwargs.get ('pathGlobFilter', None)
    header = kwargs.get ('header', None)
    print(schema)
    try:
        df_file_read = spark.read.load(filePath,
                     format=format, schema=schema, delimiter=delimiter, header=header)
        return df_file_read
    except Exception as e:
        print("Error in Reading Source File")
    


# COMMAND ----------



# COMMAND ----------

#df_file_read1 = spark.read.load("/FileStore/tables/TABTEST/DATA_TARGET_TRIGGERED_ADF.csv",
#                     format="csv")

#, schema=schema, badRecordsPath=badRecordsPath

#"/FileStore/tables/TABTEST/DATA_TARGET_TRIGGERED_ADF.csv"

#pathGlobFilter="DATA_TARGET_TRIGGERED_ADF.csv"

# COMMAND ----------

#df_file_read = spark.read.load("/tmp/input/jsonFile",
#                     format="json", pathGlobFilter="*.*", schema="a int, b int, name string , dok timestamp", badRecordsPath="/tmp/badRecordsPathPY")

# COMMAND ----------

data=[["1"]]
df=spark.createDataFrame(data,["id"])