# Databricks notebook source
# MAGIC %run /Users/nitishkumar.sood@centricconsulting.com/Base_Notebook $InputParam1="1" 

# COMMAND ----------

