# Databricks notebook source
# File location and type
file_location = "/FileStore/tables/Demo.CSV"
file_type = "CSV"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
df = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df)

# COMMAND ----------

database = "AZ_Demo"
table = "Demo"
user = "SaAdmin"
password  = "Admin@123"
query = "Select * from demo where id=1"


jdbcurl="jdbc:sqlserver://nitishazddemo.database.windows.net:1433;databaseName=AZ_Demo"

jdbctableDF = spark.read.format("jdbc") \
    .option("url", jdbcurl) \
    .option("dbtable", table) \
    .option("user", user) \
    .option("password", password) \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .load()

display(jdbctableDF)

jdbcQueryDF = spark.read.format("jdbc") \
    .option("url", jdbcurl) \
    .option("query", query) \
    .option("user", user) \
    .option("password", password) \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .load()

display(jdbcQueryDF)





# COMMAND ----------

#store complete data into new sql table

jdbcQueryDF.write.format("jdbc") \
    .option("url", jdbcurl) \
     .option("dbtable", "Demo1") \
    .option("user", user) \
    .option("password", password) \
    .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
    .save()


# COMMAND ----------

#to store df data to an existing table
jdbcQueryDF.write.format("jdbc")\
      .option("url", jdbcurl)\
      .option("user", user) \
      .option("password", password) \
      .option("dbtable", "Demo1")\
      .mode("append")\
      .save()

# COMMAND ----------

