# Databricks notebook source
Select * from sys.tables %sql



# COMMAND ----------

