# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## Overview
# MAGIC 
# MAGIC This notebook will show you how to create and query a table or DataFrame that you uploaded to DBFS. [DBFS](https://docs.databricks.com/user-guide/dbfs-databricks-file-system.html) is a Databricks File System that allows you to store data for querying inside of Databricks. This notebook assumes that you have a file already inside of DBFS that you would like to read from.
# MAGIC 
# MAGIC This notebook is written in **Python** so the default cell type is Python. However, you can use different languages by using the `%LANGUAGE` syntax. Python, Scala, SQL, and R are all supported.

# COMMAND ----------

# File location and type
file_location = "/FileStore/tables/S_NS/Sample2.csv"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
df = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df)

# COMMAND ----------

file_location = "/FileStore/tables/S_NS/Sample1.txt"
file_type = "csv"

# CSV options
infer_schema = "true"
first_row_is_header = "true"
delimiter = ","

# The applied options are for CSV files. For other file types, these will be ignored.
df1 = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df1)


# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS TBL1;
# MAGIC CREATE TABLE TBL1
# MAGIC USING csv
# MAGIC OPTIONS (path "/FileStore/tables/S_NS/Sample1.txt", header "true");
# MAGIC DROP TABLE IF EXISTS TBL2;
# MAGIC CREATE TABLE TBL2
# MAGIC USING csv
# MAGIC OPTIONS (path "/FileStore/tables/S_NS/Sample2.csv", header "true")

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from TBL1
# MAGIC UNION 
# MAGIC Select * from TBL2

# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO TBL1('Product','Customer') Values('Test','PIC')

# COMMAND ----------

from datetime import datetime, date
df = spark.createDataFrame([
    (1, 2., 'string1', date(2000, 1, 1), datetime(2000, 1, 1, 12, 0)),
    (2, 3., 'string2', date(2000, 2, 1), datetime(2000, 1, 2, 12, 0)),
    (3, 4., 'string3', date(2000, 3, 1), datetime(2000, 1, 3, 12, 0))
], schema='a long, b double, c string, d date, e timestamp')

# COMMAND ----------

df.show()

# COMMAND ----------

df3 = df.select("a", "b", "c").describe().show()

# COMMAND ----------

from pyspark.sql import Column
from pyspark.sql.functions import pandas_udf
df.createOrReplaceTempView("tableA")
spark.sql("SELECT * from tableA").show()


# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC Select * from TableA

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC Insert into TableA('a' = 3,'b'= 4,'c' =3)

# COMMAND ----------

# File location and type
file_location = "/FileStore/tables/S_NS/Tab3.txt"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = " "

# The applied options are for CSV files. For other file types, these will be ignored.
df3 = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df3)

# COMMAND ----------

# MAGIC %sql
# MAGIC DROP TABLE IF EXISTS Test3;
# MAGIC CREATE TABLE Test3
# MAGIC USING csv
# MAGIC OPTIONS (path "/FileStore/tables/S_NS/Tab3.txt", header "true");

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from Test3