# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## Overview
# MAGIC 
# MAGIC This notebook will show you how to create and query a table or DataFrame that you uploaded to DBFS. [DBFS](https://docs.databricks.com/user-guide/dbfs-databricks-file-system.html) is a Databricks File System that allows you to store data for querying inside of Databricks. This notebook assumes that you have a file already inside of DBFS that you would like to read from.
# MAGIC 
# MAGIC This notebook is written in **Python** so the default cell type is Python. However, you can use different languages by using the `%LANGUAGE` syntax. Python, Scala, SQL, and R are all supported.

# COMMAND ----------

#sample data file path
sampleDataFilePath = "/FileStore/tables/S_NS/New1.xlsx"
#flags required for reading the excel
isHeaderOn = "true"
isInferSchemaOn = "false"
#sheet address in excel
# sample1Address = “‘sample1’!A1”
# sample2Address = “‘sample2’!A1”
#read excelfile
sample1DF = spark.read.format("com.crealytics.spark.excel") \
.option("header", isHeaderOn) \
.option("inferschema", isInferSchemaOn) \
.option("treatEmptyValuesAsNulls", "false") \
.load(sampleDataFilePath)
display(sample1DF)# Create a view or table


# COMMAND ----------

#sample data file path
sampleDataFilePath = "/mnt/containershareddna01/teamC_storage/Order History.xlsx"

#sheet address("'TabName'!'first_cell:last_cell(optional)'") in excel
Address1 = "'Holdings'!A1"
Address2 = "'Transactions'!A1"
Address3 = "'NAV'!E8:G17"

#read excelfile
df = spark.read.format("com.crealytics.spark.excel") \
.option("header", 'true') \
.option("inferSchema", 'true') \
.option("treatEmptyValuesAsNulls", "false") \
.option("dataAddress", Address2) \
.load(sampleDataFilePath)
display(df)

# This dataFrame will store and display the contents of "Transactions" sheet.
# To fetch "Holdings" tab we need to replace "Address1" in line 13.

# COMMAND ----------

# MAGIC 
# MAGIC %sql
# MAGIC from pyspark.sql.sparksession
# MAGIC Select * from sample1DF