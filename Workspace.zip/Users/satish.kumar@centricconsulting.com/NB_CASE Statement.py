# Databricks notebook source
file_location = "/FileStore/tables/S_NS/Aggdata.txt"
file_type = "csv"

# CSV options
infer_schema = "false"
first_row_is_header = "true"
delimiter = " "

# The applied options are for CSV files. For other file types, these will be ignored.
df = spark.read.format(file_type) \
  .option("inferSchema", infer_schema) \
  .option("header", first_row_is_header) \
  .option("sep", delimiter) \
  .load(file_location)

display(df)


# COMMAND ----------

from pyspark.sql.functions import when
df.withColumn('InsuredValue', 
           when(df.InsuredValue>100, "More than 100 ")
           .when(df.InsuredValue<200, "Less than 200 ")
           .otherwise("No in range")).show()

# COMMAND ----------

# using select
from pyspark.sql.functions import col
df2 = df.select(col("*"), when(df.InsuredValue>100, "More than 100 ")
                                 .when(df.InsuredValue<200, "Less than 200 ")
                                 .otherwise(df.InsuredValue).alias("new_colum")) 
df2.show()

# COMMAND ----------

# using withColumn
from pyspark.sql.functions import col, expr
df3 = df.withColumn("InsuredValue_new", expr("CASE WHEN InsuredValue > 0 THEN 'More than 100' " + 
               "WHEN InsuredValue = null THEN 'Zero' " +
               "ELSE InsuredValue END"))
df3.show()

# COMMAND ----------

# expr select and new column
from pyspark.sql.functions import col, expr
df4 = df.select(col("*"), expr("CASE WHEN InsuredValue > 100 THEN 'More than 100' " +
           "WHEN InsuredValue < 200 THEN 'Less than 200'" +
           "ELSE 'No in range' END").alias("new_colum"))
df4.show()