# Databricks notebook source
# MAGIC %md
# MAGIC 
# MAGIC ## Overview
# MAGIC 
# MAGIC This notebook will show you how to create and query a table or DataFrame that you uploaded to DBFS. [DBFS](https://docs.databricks.com/user-guide/dbfs-databricks-file-system.html) is a Databricks File System that allows you to store data for querying inside of Databricks. This notebook assumes that you have a file already inside of DBFS that you would like to read from.
# MAGIC 
# MAGIC This notebook is written in **Python** so the default cell type is Python. However, you can use different languages by using the `%LANGUAGE` syntax. Python, Scala, SQL, and R are all supported.

# COMMAND ----------

def codepage(input_data):
    for s in input_data:
        i = ' '.join(['0x{:X}'.format(b) for b in s.encode('iso-8859-1')])
        u = ' '.join(['0x{:X}'.format(b) for b in s.encode('utf-8')])
    print('%s | `%s` | `%s`' % (s, i, u))

# COMMAND ----------

codepage('àáâãäåæçèéêëìíîï')

# COMMAND ----------

for s in 'àáâãäåæçèéêëìíîï':
    i = ' '.join(['0x{:X}'.format(b) for b in s.encode('iso-8859-1')]) 
    u = ' '.join(['0x{:X}'.format(b) for b in s.encode('utf-8')])
    print('%s | `%s` | `%s`' % (s, i, u))

# COMMAND ----------

letters = "αβγδ"
rawdata = letters.encode("utf-8")


# COMMAND ----------

rawdata.decode("iso-8859-1")

# COMMAND ----------

rawdata.decode("utf-8")

# COMMAND ----------

rawdata.decode("utf-16")

# COMMAND ----------

rawdata.decode("utf-8")


# COMMAND ----------

import unicodedata

unicodedata.name("€")


# COMMAND ----------

unicodedata.lookup("euro SIGN")


# COMMAND ----------

letters1 = "Î±Î²Î³Î´"
rawdata1 = letters1.encode("utf-8")

# COMMAND ----------

rawdata1.decode("utf-8")