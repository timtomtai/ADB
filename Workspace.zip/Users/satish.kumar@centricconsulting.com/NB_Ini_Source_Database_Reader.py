# Databricks notebook source
# Description : function[readDatabaseSourceIni] is responsible to fetch data from SQL database Table/Query.
# InPut Parameters :
#       configfilePath: Path for reading the configuration/ini file to read variables. 
#       **kwargs: config file level parameters : delimiter, header
#                 Database Level Parameters : 
#                                src_Initials: it will be section (Src1, Src2 etc) of your database level variable names in config/ini file, it will help us in case when we have                                                    multiple sources in a config/ini file.The function will connect the same database automatically. 
#                                tablename:     it will accept the database table name rom where you need to populate the data.
#                                query    :     in case you need to get data with a SQL query, you can pass the same in this parameter. it will work for joins, fileration also.
#                          NOTE : funtion will accept one value out of tablename/query at a time. so in function call wither you can pass tablename or query. 
# Sample ini/config file(CSV):        
# [Src2]
# property = value
# databasename = dbdna02
# table = Demo_Connectivity
# user = admindna01
# password = 
# databaseserver = dbserverdna01.database.windows.net
# driver = com.microsoft.sqlserver.jdbc.SQLServerDriver
# pass_scope = scope_adb_2
# pass_key = dbdna01-properties
# [Src1]
# databasename = dbdna01
# table = Demo_Connectivity
# user = admindna01
# password = admindna@01
# databaseserver = dbserverdna01.database.windows.net
# driver = com.microsoft.sqlserver.jdbc.SQLServerDriver
# pass_scope = scope_adb_2
# pass_key = dbdna01-properties

#       function is developed to accept above mentioned property names for now, if any one changes there names in config file then there will be a need to update the function           accordingly.
#
#
#
#

# COMMAND ----------

def readDatabaseSourceIni(configfilePath, **kwargs) :
    
    from configparser import ConfigParser;   
    try:
        src = kwargs.get ('section', None)
        tablename = kwargs.get ('tablename', None)
        query = kwargs.get ('query', None)
        
        ini_parser = ConfigParser()
        ini_parser.read(configfilePath)
    
        databaseName =ini_parser.get(src,'databasename',fallback='')
        userName =ini_parser.get(src,'user',fallback='')
        password =ini_parser.get(src,'password',fallback='')
        databaseServer =ini_parser.get(src,'databaseserver',fallback='')
        databaseDriver =ini_parser.get(src,'driver',fallback='')
        pass_scope =ini_parser.get(src,'pass_scope',fallback='')
        pass_key =ini_parser.get(src,'pass_key',fallback='')
            
        
        if ((len(pass_key) > 0) and ( len(pass_scope) > 0)):
            
            password = dbutils.secrets.get(scope = pass_scope, key = pass_key)
        
        
        jdbcurl = f"jdbc:sqlserver://{databaseServer}:1433;databaseName={databaseName}"
    
        if tablename is not None:
            jdbcDF = spark.read.format("jdbc") \
                       .option("url", jdbcurl) \
                   .option("dbtable", tablename) \
                   .option("user", userName) \
                   .option("password", password) \
                   .option("driver", databaseDriver) \
                   .load()
            return jdbcDF
        else :
            jdbcDF = spark.read.format("jdbc") \
                   .option("url", jdbcurl) \
                   .option("query", query) \
                   .option("user", userName) \
                   .option("password", password) \
                   .option("driver", databaseDriver) \
                   .load()
            return jdbcDF
    except Exception as e:
         print("Error in Reading Source data")
        


# COMMAND ----------

#example for reading data with a tablename
databaseable = readDatabaseSourceIni ("/dbfs/FileStore/tables/DataEng/Config_DB_Param.txt", tablename= "Name", section= "Diamond")
databaseable.show()

# COMMAND ----------

#example for reading data with a query
databaseable_query = readDatabaseSourceIni ("/dbfs/FileStore/tables/DataEng/Config_DB_Param.txt", query= "Select * from Name", section= "Diamond")
databaseable_query.show()

# COMMAND ----------

Import 
databaseable_query1 = readDatabaseSourceIni ("/dbfs/FileStore/tables/DataEng/Config_DB_Param.txt", query= "Select Count(*) from Name", section= "Diamond")
databaseable_query1.show()