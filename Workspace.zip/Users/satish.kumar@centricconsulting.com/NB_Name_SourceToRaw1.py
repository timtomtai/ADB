# Databricks notebook source
# MAGIC %md
# MAGIC call notebook to initialize function readDatabaseSourceIni to connect to DB

# COMMAND ----------

# MAGIC %run /DATABRICKS_DEMO/SourceToRaw/NB_ConnectToDB

# COMMAND ----------

# MAGIC %md
# MAGIC call notebook to read and write data from DB to raw layer

# COMMAND ----------

# MAGIC %run /DATABRICKS_DEMO/SourceToRaw/NB_writeDBTOFile

# COMMAND ----------

# MAGIC %run /DATABRICKS_DEMO/SourceToRaw/NB_part_file_mover

# COMMAND ----------

def write_Source_file(config_path,tablename,section,target,newtarget):
    databasetable = readDatabaseSourceIni (config_path, tablename=tablename, section=section )
    databasetable.write.format('parquet').option("header","true").parquet(target,header="true")
    
    backupfile=target+"_processed"
    dbutils.fs.cp(target,newtarget,recurse=True)
    dbutils.fs.mv(target,backupfile,recurse=True)

# COMMAND ----------

tablename= "Name"
config_path="/dbfs/FileStore/tables/DataEng/Config_DB_Param.txt"
section= "Diamond" 
target="/mnt/containershareddna01/DemoSourceData/Name.parquet"
newtarget="/mnt/containershareddna02/DataEngineeringLayer/Raw/address/Name.parquet"
# FORMAT="parquet"

write_source_file(config_path,tablename,section,target,newtarget)