# Databricks notebook source
for n in range(2, 10):
     for x in range(2, n):
         if n % x == 0:
             print(n, 'equals', x, '*', n//x)
             break
     else:
         # loop fell through without finding a factor
         print(n, 'is a prime number')

# COMMAND ----------

for i in list(range(2,10,3)):
  print(i)
type(i)

# COMMAND ----------

a = ['Mary', 'had', 'a', 'little', 'lamb']
#len(a)
for i in range(len(a)):
  print(i, a[i], len(a[i]), range(len(a[i])))

#print(range(len(a)))


# COMMAND ----------

for n in range(2,10):
    for i in range(2, n):
        if n % i == 0:
            print(n,'is equal to', i, '*',n//i)
            break
            
    else:
            print(n, 'is a prim number')
 