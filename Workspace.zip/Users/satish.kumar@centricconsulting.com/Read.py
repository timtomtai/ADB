# Databricks notebook source
Sample = (("James", "Sales", 3000), \
    ("Michael", "Sales", 4600),  \
    ("Robert", "Sales", 4100),   \
    ("Maria", "Finance", 3000),  \
    ("James", "Sales", 3000),    \
    ("Scott", "Finance", 3300),  \
    ("Jen", "Finance", 3900),    \
    ("Jeff", "Marketing", 3000), \
    ("Kumar", "Marketing", 2000),\
    ("Saif", "Sales", 4100) \
  )
 
columns= ["employee_name", "department", "salary"]
df = spark.createDataFrame(data = Sample, schema = columns)
df.printSchema()
df.show(truncate=False)

# COMMAND ----------

df.createOrReplaceTempView("Table1")

# COMMAND ----------

# MAGIC %sql
# MAGIC Select * from Table1

# COMMAND ----------

# MAGIC %sql
# MAGIC Insert into Table1 values('Satish','DnA',4321)