# Databricks notebook source
dbutils.fs.mount(
  source = "wasbs://containershareddna01@sashareddna01.blob.core.windows.net",
  mount_point = "/mnt/containershareddna01",
  extra_configs = {"fs.azure.account.key.sashareddna01.blob.core.windows.net":dbutils.secrets.get(scope = "scopedna01", key = "secretdna01")})

# COMMAND ----------

display(dbutils.fs.mounts())
# dbutils.fs.unmount("/mnt/containershareddna01") # To Unmount the Data 
# dbutils.fs.refreshMounts() # To refresh the mounts
#dbutils.widgets.help()

# COMMAND ----------

# MAGIC 
# MAGIC %fs ls /mnt/containershareddna01

# COMMAND ----------

files = dbutils.fs.ls("/mnt/containershareddna01/teamC_storage")
# for fileInfo in files:
#   print(fileInfo.path)

# print("-"*80)

display(files)

# COMMAND ----------

df= spark.read.csv("/mnt/containershareddna01/DATA*.csv")
df.show()

# COMMAND ----------

mydf = sqlContext.read.csv("/FileStore/tables/DATA*.csv",header=True)
mydf.show()

# COMMAND ----------

df1= sqlContext.read.csv("/FileStore/shared_uploads/shashank.jain@centricconsulting.com/annual_enterprise_survey_2020_financial_year_provisional_csv.csv",header=True)
df1.show()

# COMMAND ----------

df1.write.format("delta").mode("overwrite").saveAsTable("Annual_Enterprise_delta_table_SJ")
mydf.write.format("delta").mode("overwrite").saveAsTable("test_delta_SJ")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from Annual_Enterprise_delta_table_SJ

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from test_delta_SJ

# COMMAND ----------

# To Generate Surrogate keys using SQL
df2=sqlContext.sql("select row_number()over(order by name) as Surrogate_Key,* from test_delta_SJ ")
df2.show()

# COMMAND ----------

dbfs= spark.read.csv("/FileStore/tables/Data_f*.csv",header = "true")

dbfs.show()


# COMMAND ----------

dbfs.write.format("delta").mode("overwrite").csv("/FileStore/tables/dbfs_sha.csv",header="true")
dbfs.write.format("delta").mode("overwrite").csv("/mnt/containershareddna02/dbfs_001.csv",header="true")


# COMMAND ----------

dbfs_fetched_from_DBFS= spark.read.csv("/FileStore/tables/dbfs_sha.csv/part*.csv",header = "true")
dbfs_fetched_from_DBFS.show()

# COMMAND ----------

