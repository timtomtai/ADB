# Databricks notebook source
from pyspark.sql.types import LongType, IntegerType, StructField, StructType
from pyspark.sql.functions import concat, lit, col, when
from delta import DeltaTable
import delta

# COMMAND ----------

deltalake_path1 = '/mnt/containershareddna03/Int/edw_claimant'
src_delta_table1 = DeltaTable.forPath(spark, deltalake_path1)
source_file1 = src_delta_table1.toDF().where("ACTIVE_FLAG = 'Y' ")

# COMMAND ----------

type(source_file1)

# COMMAND ----------

col_list = ["DIM_CLAIMANT_NK","CLAIMANT_FIRST_NAME","CLAIMANT_MIDDLE_NAME","CLAIMANT_LAST_NAME","CLAIMANT_FULL_NAME",
        "CLAIMANT_TYPE_CODE","CLAIMANT_GENDER_CODE","CLAIMANT_AGE_INT","CLAIMANT_OCCUPATION_DESC","SOURCE_SYSTEM_CODE"]
         

# COMMAND ----------

source_file=source_file1.select(source_file1["*"],concat(source_file1["Claimant_NK"],lit("#EDW"))..select(col_list)

# COMMAND ----------

source_file1=source_file1.select(['Claimant_NK','CLAIMANT_FIRST_NAME','CLAIMANT_MIDDLE_NAME']).select(["*"]).alias("source_file").select(["*"])
                                                                                                     
#source_file = source_file.select(source_file["*"],concat(source_file["Claimant_NK"],lit("#EDW")).alias("DIM_CLAIMANT_NK"))

# COMMAND ----------

source_file=source_file1.select(source_file1["*"],concat(source_file1["Claimant_NK"],lit("#EDW")).alias("DIM_CLAIMANT_NK"))

# COMMAND ----------

source_file=source_file1.select(source_file1["*"],concat(source_file1["Claimant_NK"],lit("#EDW")).alias("DIM_CLAIMANT_NK")).withColumn("CLAIMANT_AGE_INT",floor(datediff(current_date(), to_date(col('CLAIMANT_DATE_OF_BIRTH_DATE'), 'yyyy-mm-dd'))/365.25))

# COMMAND ----------

display(source_file)

# COMMAND ----------


from pyspark.sql.functions import *


source_file1.select(
      col("CLAIMANT_DATE_OF_BIRTH_DATE"),
      current_date().alias("current_date"),
      datediff(current_date(),col("CLAIMANT_DATE_OF_BIRTH_DATE")).alias("datediff")
    ).show()

# COMMAND ----------

