# Databricks notebook source
dbutils.fs.rm("/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt")

# COMMAND ----------



dbutils.fs.rm("/FileStore/tables/DataEng/RawtoStg/ClaimantNameLinkRawtostg.py")



# COMMAND ----------

Filestore/Tables/DataEng/RawtoStg/ClaimantAddressLinkRawtoStg.py

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE rectangles1(a INT, b INT,
# MAGIC                           area INT  GENERATED ALWAYS   AS  (IDENTITY [ a ][INCREMENT BY b] ));

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE rectangles(a INT, b INT,
# MAGIC                           area INT GENERATED ALWAYS AS (a * b));

# COMMAND ----------

column_specification
  ( { column_identifier column_type [ NOT NULL ]
      [ GENERATED ALWAYS AS ( expr ) |
        GENERATED { ALWAYS | BY DEFAULT } AS IDENTITY [ ( [ START WITH start ] [ INCREMENT BY step ] ) ] ]
      [ COMMENT column_comment ] } [, ...] )


# COMMAND ----------

# MAGIC %sql
# MAGIC INSERT INTO rectangles (a,b)
# MAGIC VALUES (1,2);
# MAGIC 
# MAGIC INSERT INTO rectangles (a,b)
# MAGIC VALUES (2,4);

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from rectangles

# COMMAND ----------

