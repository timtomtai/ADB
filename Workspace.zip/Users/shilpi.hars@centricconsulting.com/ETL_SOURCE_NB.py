# Databricks notebook source
# MAGIC %md
# MAGIC # Description : function[get_df_csv_parquet_files] is responsible to fetch data from files format CSV,JSON,PARQUET. It can read multiple files (merge the files) from the mentioned path and store it in a dataframe which is output to this function.
# MAGIC # InPut Parameters :
# MAGIC #       var_config_path: Path for reading the configuration/ini file to read variables. 
# MAGIC # Sample ini/config file(CSV):        
# MAGIC # [FILE_OSS]
# MAGIC # pass_hours=72         ## lookback period from which files needs to be read
# MAGIC # path= /dbfs/FileStore/tables/oss/   ##Source file path

# COMMAND ----------

config_path = '/dbfs/FileStore/tables/oss/pyspark_config_teamc.ini' 
regex_csv = '.*yellow_trip_taxi_\d{8}\.csv$'
regex_parquet = '.*userdata\d+\.parquet$'
regex_json='.*sample\d+\.json$'
#date_format= 'current_date'
#date_format= 'period'
date_format= 'current_week'

def get_df_csv_parquet_files(var_config_path,regex_csv,regex_parquet,regex_json,date_format):
  
    """"
    Get DF as output for CSV, PARQUET file types.  [json to be merged in this]
    Input parameters required = 1. Config path location which contains PATH
                                2. Regex of CSV, JSON, PARQUET
    
    Output Df= 1. CSV qualified for Regex and lookback period
               2. PARQUET qualified for Regex and lookback period
               3. JSON qualified for Regex and lookback period
               
               ~~~~~~~~
               
                Limited to CSV functionality
               4. get Current date files
               5. get Current Week files
    """
    
    import pyspark ;
    from pyspark.sql import SparkSession;
    import os;
    from datetime import date,datetime, timedelta;
    from configparser import ConfigParser;
    from glob import glob, iglob;
    import re;
    #spark = SparkSession.builder.appName('TeamC').master('master').getOrCreate()
    
    ini_parser = ConfigParser()
    ini_parser.read(var_config_path)
    pass_hours =int(ini_parser.get('FILE_OSS','pass_hours'))
    path = ini_parser.get('FILE_OSS','path')
    lookback_period = datetime.now() - timedelta(hours =pass_hours)
    today = date.today()
    now = datetime.now()- timedelta(hours =72)
    now_day_1 = now - timedelta(days=now.weekday())
    #print(now_day_1)
    #print(path, '\n',lookback_period)
    
    
    files_at_path= [path+"/"+fd for fd in os.listdir(path)]
    #print(type(files_at_path), '\n',files_at_path)

    csv_qualified_files = [];
    parquet_qualified_files = [];
    json_qualified_files = [];
    csv_qualified_files.clear();
    parquet_qualified_files.clear();
    json_qualified_files.clear();

    for file in files_at_path:
        get_stats = os.stat(file)
        get_file_last_modified_date = datetime.fromtimestamp(get_stats.st_mtime)
        get_file_last_modified_date_short = date.fromtimestamp(get_stats.st_mtime)
        if date_format=='period':
            if get_file_last_modified_date >= lookback_period:
                if file.endswith('.csv'):
                    csv_qualified_files.append(file)
                elif file.endswith('.parquet'):
                    parquet_qualified_files.append(file)
                elif file.endswith('.json'):
                    json_qualified_files.append(file) 
        elif date_format=='current_date':
            if get_file_last_modified_date_short == today:
                if file.endswith('.csv'):
                    csv_qualified_files.append(file)
                elif file.endswith('.parquet'):
                    parquet_qualified_files.append(file)
                elif file.endswith('.json'):
                    json_qualified_files.append(file)
        elif date_format=='current_week':
            if get_file_last_modified_date >= now_day_1:
                if file.endswith('.csv'):
                    csv_qualified_files.append(file)
                elif file.endswith('.parquet'):
                    parquet_qualified_files.append(file)
                elif file.endswith('.json'):
                    json_qualified_files.append(file) 
                

    mod_parquet_qualified_files =[];
    mod_csv_qualified_files =[];
    mod_json_qualified_files =[];
    

    for char in parquet_qualified_files:
        text = char.replace('/dbfs','')
        mod_parquet_qualified_files.append(text)

    for char in csv_qualified_files:
        text = char.replace('/dbfs','')
        mod_csv_qualified_files.append(text)
        
    for char in json_qualified_files:
        text = char.replace('/dbfs','')
        mod_json_qualified_files.append(text)      
        
    pattern_csv = re.compile(r''+regex_csv+'')
    print(pattern_csv)
    files_at_path_regex_pattern_csv = [s for s in mod_csv_qualified_files if pattern_csv.match(s)]
    print('###CSV REGEX OUT FILES#### \n',files_at_path_regex_pattern_csv) 
    
    
    pattern_parquet = re.compile(r''+regex_parquet+'')
    print(pattern_parquet)
    files_at_path_regex_pattern_parquet = [s for s in mod_parquet_qualified_files if pattern_parquet.match(s)]
    print('###parq REGEX OUT FILES#### \n',files_at_path_regex_pattern_parquet)
    
    pattern_json = re.compile(r''+regex_json+'')
    print(pattern_json)
    files_at_path_regex_pattern_json = [s for s in mod_json_qualified_files if pattern_json.match(s)]
    print('###json REGEX OUT FILES#### \n',files_at_path_regex_pattern_json)
        
    if files_at_path_regex_pattern_csv!=[]:
        out_df_csv_qualified_files= spark.read.format('csv').option("header","true").load(files_at_path_regex_pattern_csv,sep=',');
    else:
        out_df_csv_qualified_files= spark.sparkContext.emptyRDD();
        print('No csv files present');
    if files_at_path_regex_pattern_parquet!=[] :
        out_df_parquet_qualified_files= spark.read.format('parquet').option("header","true").load(files_at_path_regex_pattern_parquet,sep=',');
    else:
        out_df_parquet_qualified_files= spark.sparkContext.emptyRDD();
        print('No parquet files present') ;
    if files_at_path_regex_pattern_json!=[] :
        out_df_json_qualified_files= spark.read.option("multiline", "true").option("inferSchema", "true").json(files_at_path_regex_pattern_json);
    else:
        out_df_json_qualified_files= spark.sparkContext.emptyRDD();
        print('No json files present') ;
    
    return out_df_csv_qualified_files, out_df_parquet_qualified_files, out_df_json_qualified_files;
    
 
    
df_csv, df_parquet, df_json = get_df_csv_parquet_files(config_path,regex_csv,regex_parquet,regex_json,date_format)

df_csv.show(10)
df_parquet.show(10)
df_json.show()

# COMMAND ----------

from datetime import date,datetime, timedelta;
current_week = datetime.now().isocalendar()[1]
print(current_week)

# COMMAND ----------

from datetime import datetime , timedelta

now = datetime.now()- timedelta(hours =72)
days=now.weekday()
print (days)
print(now)
now_day_1 = now - timedelta(days=now.weekday())
print(now_day_1)

dates = {}

for n_week in range(3):
    dates[n_week] = [(now_day_1 + datetime.timedelta(days=d+n_week*7)).strftime("%m/%d/%Y") for d in range(7)]

print dates

# COMMAND ----------

import os
from datetime import datetime , timedelta
try:
path = '/dbfs/FileStore/tables/oss'
#os.listdir(path)
fdpaths = [path+"/"+fd for fd in os.listdir(path)]
#fdpaths
#  make it dynamic. 
qualified_files = []

print(type(qualified_files), type(fdpaths))
lookback_hour_ago = datetime.now()- timedelta(hours = 500)
print(lookback_hour_ago)

csv_qualified_files = [];
parquet_qualified_files = [];
json_qualified_files = [];
csv_qualified_files.clear();
parquet_qualified_files.clear();
json_qualified_files.clear();
    
for file in fdpaths:
    get_stats = os.stat(file)
    get_file_last_modified_date = datetime.fromtimestamp(get_stats.st_mtime)
    if get_file_last_modified_date >= lookback_hour_ago:
        if file.endswith('.csv'):
                csv_qualified_files.append(file)
        elif file.endswith('.parquet'):
                parquet_qualified_files.append(file)
        elif file.endswith('.json'):
                json_qualified_files.append(file)   

print (json_qualified_files)
print (parquet_qualified_files)
print (csv_qualified_files)

mod_parquet_qualified_files =[];
mod_csv_qualified_files =[];
mod_json_qualified_files =[];

for char in csv_qualified_files:
    text = char.replace('/dbfs','')
    mod_csv_qualified_files.append(text)
for char in json_qualified_files:
    text = char.replace('/dbfs','')
    mod_json_qualified_files.append(text)   
    #print(mod_json_qualified_files)


out_df_csv_qualified_files= spark.read.format('csv').option("header","true").load(mod_csv_qualified_files,sep=',');
out_df_json_qualified_files= spark.read.option("multiline", "true").option("inferSchema", "true").json(mod_json_qualified_files);

for char in parquet_qualified_files:
    text = char.replace('/dbfs','')
    mod_parquet_qualified_files.append(text)
print(mod_parquet_qualified_files)
out_df_parquet_qualified_files= spark.read.format('parquet').option("header","true").load(mod_parquet_qualified_files,sep=',');

#out_df_parquet_qualified_files= spark.read.option("header", "true").option("inferSchema", "true").parquet(mod_parquet_qualified_files);

    
out_df_csv_qualified_files.show()
out_df_json_qualified_files.show()
out_df_parquet_qualified_files.show()
except exception:
print(file)

# COMMAND ----------

##Final code
##input Parameter
config_path = '/dbfs/FileStore/tables/oss/pyspark_config_teamc.ini'
regex = '.*yellow_trip_taxi_\d{8}\.csv$'
#regex='.*sample\d+\.json$'
#regex = '.*userdata\d+\.parquet$'
#date_format= 'current_date'
date_format= 'period'
#date_format= 'current_week'

#### Function Body
def get_df_qualified_files(var_config_path,regex,date_format):
    import pyspark ;
    from pyspark.sql import SparkSession;
    import os;
    from datetime import date,datetime, timedelta;
    from configparser import ConfigParser;
    import re;
    ## Assign values
    spark = SparkSession.builder.appName('TeamC').master('master').getOrCreate()
    ini_parser = ConfigParser()
    ini_parser.read(var_config_path)
    pass_hours =int(ini_parser.get('FILE_OSS','pass_hours'))
    path = ini_parser.get('FILE_OSS','path')
    lookback_period = datetime.now() - timedelta(hours =pass_hours)
    today = date.today()
    now = datetime.now()
    now_day_1 = now - timedelta(days=now.weekday()) ##first date of current week
    
    ## extract date modified and pick the latest files based on hour/ current week/ current date
    files_at_path= [path+"/"+fd for fd in os.listdir(path)]
    qualified_files =[];
    pattern = re.compile(r''+regex+'')
    
    for file in files_at_path:
        get_stats = os.stat(file)
        file_last_modified_date = datetime.fromtimestamp(get_stats.st_mtime)
        get_file_last_modified_date_short = date.fromtimestamp(get_stats.st_mtime)
        
        if date_format=='period':
            if (file_last_modified_date >= lookback_period ):
                file = file.replace('/dbfs','')
                qualified_files.append(file)
                qualified_files = [s for s in qualified_files if pattern.match(s)]
        elif date_format=='current_date':
            if (get_file_last_modified_date_short == today):
                file = file.replace('/dbfs','')
                qualified_files.append(file)
                qualified_files = [s for s in qualified_files if pattern.match(s)]
        elif date_format=='current_week':
            if (file_last_modified_date >= now_day_1):
                file = file.replace('/dbfs','')
                qualified_files.append(file)
                qualified_files = [s for s in qualified_files if pattern.match(s)]
    ##check for file extension and read the files   
    if qualified_files!=[]:
        print(qualified_files)
        extension = os.path.splitext(qualified_files[1])[1][1:]
        print(extension)
        out_df_files= spark.read.format(r''+extension+'').option("header","true").load(qualified_files);
    else:
        out_df_files= spark.sparkContext.emptyRDD();
        print('No files present');
        
    return out_df_files;

## call function
df = get_df_qualified_files(config_path,regex,date_format)

df.show()

# COMMAND ----------

##date present in file name
##function return dataframe for a given file pattern if date is euqal to current date
##input Parameter
path = '/mnt/containershareddna01/teamC_storage'
regex = '.*yellow_trip_taxi_\d{8}\.csv$'
#regex='.*sample\d{8}\.json$'
#regex = '.*userdata\d{8}\.parquet$'

#### Function Body
def get_df_qualified_files(path,regex):
    import pyspark ;
    from pyspark.sql import SparkSession;
    import os;
    from datetime import date,datetime, timedelta;
    from configparser import ConfigParser;
    import re;
    ## Assign values
    
    files_at_path= ["/dbfs"+path+"/"+fd for fd in os.listdir("/dbfs"+path)]
    filename=os.listdir("/dbfs"+path)
    pattern = re.compile(r''+regex+'')
    qualified_files =[]
    #date format
    format = '%d%m%Y'
    # current date
    today = date.today()
    
    ## check filenanme pattern
    for fname in (filename):
        if pattern.match(fname):
            ##check date from file is equal to current date
            file_split = re.split('(\d{8})', fname, 1)
            if(file_split!=[fname]): ##execute only if date is present
                fdate=file_split[1]
                # convert from string format to datetime format
                fdate=datetime.strptime(fdate, format)
                if (fdate.date()==today): ## current date
                    files=(path+"/"+fname)
                    qualified_files.append(files)

    if qualified_files!=[]:
        print(qualified_files)
        extension = os.path.splitext(qualified_files[0])[1][1:]
        out_df_files= spark.read.format(r''+extension+'').option("header","true").load(qualified_files);
    else:
        out_df_files= spark.sparkContext.emptyRDD();
        print('No files present');

    return out_df_files;

## call function
df = get_df_qualified_files(path,regex)

df.show()

# COMMAND ----------

import re
###1st way
# m = re.search('\d{2,4}-\d{2}-\d{2,4}', '1dere10-12-2001.zip')
# print(m.group())
###2nd way
# match= re.search("([0-9]{2}\-[0-9]{2}\-[0-9]{4})", 'derer-10-12-2001.zip')
# m=match.group()
#print(m)

m = re.search('\d{2,4}-\d{2}-\d{2,4}', '1dere2001-12-20.zip')
print(m.group())