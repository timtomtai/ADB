# Databricks notebook source
# MAGIC %md
# MAGIC call notebook to initialize function readDatabaseSourceIni to connect to DB

# COMMAND ----------

# MAGIC %run /DATABRICKS_DEMO/SourceToRaw/NB_ConnectToDB

# COMMAND ----------

# MAGIC %md
# MAGIC call notebook to read and write data from DB to raw layer

# COMMAND ----------

# MAGIC %run /DATABRICKS_DEMO/SourceToRaw/NB_writeDBTOFile

# COMMAND ----------

tablename= "Address"
config_path="/dbfs/FileStore/tables/DataEng/Config_DB_Param.txt"
section= "Diamond" 
target="/mnt/containershareddna01/DemoSourceData/"
newtarget="/mnt/containershareddna02/DataEngineeringLayer/Raw/address/"
FORMAT="csv"

write_source_file(config_path,tablename,section,target,newtarget,FORMAT)

# COMMAND ----------

from datetime import datetime
now = datetime.now()
now
datetime_str = now.strftime("%Y%m%d%s")
datetime_str
