# Databricks notebook source
#old
def split_file() :
    splitlen = 2
    outputbase = '/dbfs/FileStore/tables/oss/data'
    input= open('/dbfs/FileStore/tables/oss/test_txt.txt','r').read().split('\n')
    i=1
    for lines in range(0,len(input),splitlen):
        outputdata=input[lines:lines+splitlen]
        output=open(outputbase+str(i)+'.txt','w')
        output.write('\n'.join(outputdata))
        output.write('\n')
        output.close()
        i+=1
    print("file split operation has been successfull")
    
    return outputbase;


outputbase=split_file();

# COMMAND ----------

# Function split_file() splits the file of any format into n no of files based on no of lines
# Input Parameters for function split_file() are as below:
#outputbase = '/dbfs/FileStore/tables/oss/data'
outputbase = '/dbfs/FileStore/tables/oss/merge_file_'
#inputfile='/dbfs/FileStore/tables/oss/test_txt.txt'
inputfile='/dbfs/FileStore/tables/oss/merge_file.csv'
fileformat='.csv'
splitlen = 2


def split_file(outputbase,inputfile,fileformat,splitlen) :
    input= open(inputfile,'r').read().split('\n')
    i=1
    for lines in range(0,len(input),splitlen):
        outputdata=input[lines:lines+splitlen]
        output=open(outputbase+str(i)+fileformat,'w')
        output.write('\n'.join(outputdata))
        output.write('\n')
        output.close()
        i+=1
    print("file split operation has been successfull")

# Call the function
split_file(outputbase,inputfile,fileformat,splitlen);

# COMMAND ----------

#file=open('/dbfs/FileStore/tables/oss/data.txt','r')
file=open('/dbfs/FileStore/tables/oss/merge_file_3.csv','r')
original=file.read()
original

# COMMAND ----------

#old
def merge_file() :
    import os
    import shutil
    import re;

    with open('/dbfs/FileStore/tables/oss/data.txt','wb') as fdst:
        sourcepath='/dbfs/FileStore/tables/oss/'
        for subdir,dirs,files in os.walk(sourcepath):
            for file in files:
                filename=sourcepath+file
                regex_txt = '.*data\d+\.txt$'
                pattern_txt = re.compile(r''+regex_txt+'')
                if pattern_txt.match(filename):
                    print('###txt REGEX OUT FILES#### \n',filename)
                    with open(filename,'rb') as fsrc:
                        shutil.copyfileobj(fsrc,fdst,1024*1024*10)
    print("file merge operation has been successfull")
    
    return fdst;


fdst=merge_file();


# COMMAND ----------

# Function merge_file() merge the file of any format at a location into one files based on file pattern
# Input Parameters for function merge_file() are as below:
#outputfile= '/dbfs/FileStore/tables/oss/data.txt'
outputfile= '/dbfs/FileStore/tables/oss/merge_file_final.csv'
sourcepath='/dbfs/FileStore/tables/oss/'
regex_txt = '.*merge_file_\d+\.csv$'

def merge_file(outputfile,sourcepath,regex_txt) :
    import os
    import shutil
    import re;

    with open(outputfile,'wb') as fdst:
        for subdir,dirs,files in os.walk(sourcepath):
            for file in files:
                filename=sourcepath+file
                pattern_txt = re.compile(r''+regex_txt+'')
                if pattern_txt.match(filename):
                    print('###txt REGEX OUT FILES#### \n',filename)
                    with open(filename,'rb') as fsrc:
                        shutil.copyfileobj(fsrc,fdst,1024*1024*10)
    print("file merge operation has been successfull")

# Call the function
fdst=merge_file(outputfile,sourcepath,regex_txt);

# COMMAND ----------

#filePath='/dbfs/FileStore/tables/oss/data.txt'
filePath='/dbfs/FileStore/tables/oss/merge_file_final.csv'
#filename='/dbfs/FileStore/tables/oss/test_txt1.txt'
#filename2='/dbfs/FileStore/tables/oss/test_txt2.txt'
file=open(filePath,'r')
lines = file.readlines() 
lines

# COMMAND ----------

df_taxi_out=spark.read.format('csv').option("sep",",").option("header","true").option("inferSchema","true").load("/FileStore/tables/oss/merge_file.csv");
df_taxi_out.show()
df_taxi_out.write.partitionBy("cola").csv("/tmp/merge_file.csv")

# COMMAND ----------

#old for excel
import pandas as pd
import os

df = pd.read_excel('/dbfs/FileStore/tables/OSS/Financial_Sample.xlsx')
column_name = 'Country'
replace_symbols = ['>', '<', ':', '"', '/', '\\\\', '\|', '\?', '\*']
df[column_name] = (
    df[column_name].replace(replace_symbols, '', regex=True).str.strip().str.title()
)
unique_values = df[column_name].unique()

for unique_value in unique_values:
    df_output = df[df[column_name].str.contains(unique_value)]
    output_path = os.path.join('output', str(unique_value) + '.xlsx')
    df_output.to_excel(output_path, sheet_name=unique_value[:31], index=False)

# COMMAND ----------

##old
#Create multiple CSV files from existing CSV file based on column
import pandas as pd

# DataFrame to read our input CS file
dataFrame = pd.read_csv("/dbfs/FileStore/tables/oss/SalesRecords.csv")
print("\nInput CSV file = \n", dataFrame)

# groupby to generate CSVs on the basis of Car names in Car column
for (car), group in dataFrame.groupby(['Car']):
   group.to_csv(f'/dbfs/FileStore/tables/oss/{car}.csv', index=False)

#Displaying values of the generated CSVs
print("\nCSV 1 = \n", pd.read_csv("BMW.csv"))
print("\nCSV 2 = \n", pd.read_csv("Lexus.csv"))
print("\nCSV 3 = \n", pd.read_csv("Jaguar.csv"))

# COMMAND ----------

#Create multiple CSV files from existing CSV file based on column
inputfile="/dbfs/FileStore/tables/oss/SalesRecords.csv"
column_name='Car'
outputpath='/dbfs/FileStore/tables/oss/'
replace_symbols = ['>', '<', ':', '"', '/', '\\\\', '\|', '\?', '\*']

def Split_file_on_Column(inputfile,column_name,outputpath,replace_symbols) :
    import pandas as pd

    # DataFrame to read our input CSV file
    dataFrame = pd.read_csv(inputfile)
    #print("\nInput CSV file = \n", dataFrame)
    dataFrame[column_name] = (
        dataFrame[column_name].replace(replace_symbols, '', regex=True).str.strip()
    )
    # groupby to generate CSVs on the basis of Car names in Car column
    for (car), group in dataFrame.groupby([column_name]):
       group.to_csv(f'{outputpath}/{car}.csv', index=False)
    
    print("file split operation has been successfull")

#call function
Split_file_on_Column(inputfile,column_name,outputpath,replace_symbols)
#Displaying values of the generated CSVs
print("\nCSV 1 = \n", pd.read_csv("/dbfs/FileStore/tables/oss/BMW.csv"))
print("\nCSV 2 = \n", pd.read_csv("/dbfs/FileStore/tables/oss/Lexus.csv"))
print("\nCSV 3 = \n", pd.read_csv("/dbfs/FileStore/tables/oss/Jaguar.csv"))

# COMMAND ----------

##old
import pandas as pd
import os

df = pd.read_csv('/dbfs/FileStore/tables/oss/SalesRecords.csv')
column_name = 'Car'
replace_symbols = ['>', '<', ':', '"', '/', '\\\\', '\|', '\?', '\*']
df[column_name] = (
    df[column_name].replace(replace_symbols, '', regex=True).str.strip().str.title()
)

# for (car), group in df.groupby([column_name]):
#      group.to_csv(f'/dbfs/FileStore/tables/oss/{car}.csv', index=False)
    
# print("file split operation has been successfull")

unique_values = df[column_name].unique()
print(df[column_name])
print(unique_values)

# COMMAND ----------

def split_file() :
    splitlen = 2
    outputbase = '/dbfs/FileStore/tables/oss/data'
    input= open('/dbfs/FileStore/tables/oss/test_txt.txt','r').read().split('\n')
    i=1
    for lines in range(0,len(input),splitlen):
        outputdata=input[lines:lines+splitlen]
        output=open(outputbase+str(i)+'.txt','w')
        output.write('\n'.join(outputdata))
        output.write('\n')
        output.close()
        i+=1
    print("file split operation has been successfull")
    
    return outputbase;


outputbase=split_file();

# COMMAND ----------

splitsize=29
filename='/dbfs/FileStore/tables/oss/merge_file.csv'
outputbase='/dbfs/FileStore/tables/oss/data'
format='.csv'
def split_file_size(splitsize,filename,outputbase,format) :
    import os
    try:
        file_size = os.stat(filename).st_size
        print (file_size)

        file_obj= open(filename,'r')
        for i in range( int(file_size/int(splitsize))):
            print(i)
            #print (file_obj.read(int(splitsize)).split('\n'))
            outputdata= file_obj.read(int(splitsize)).split('\n')
            print(outputdata)
            output=open(outputbase+str(i+1)+format,'w')
            print(output)
            output.write('\n'.join(outputdata))
            output.close()

        print("file split operation has been successfull")
       
    except exception:
            print("incorrect input parameter")
        
        
split_file_size(splitsize,filename,outputbase,format)

# COMMAND ----------

file=open('/dbfs/FileStore/tables/oss/data2.csv')
original=file.read()
original

# COMMAND ----------

import os
import sys
import pandas as pd

mylist=[]
ChunkSize=2
for chunk in pd.read_csv('/dbfs/FileStore/tables/oss/merge_file.csv',chunksize=ChunkSize):
    #print(chunk.shape)
    mylist.append(chunk)
    #print("=="*66)
    #print(chunk)
    #print("=="*66)
mylist[1]    
#print(mylist)


# COMMAND ----------

df1=pd.concat(mylist,axis=0)
df1

# COMMAND ----------

# Split a csv file based on chunksize
# input parameter
bigfilepath =r'/dbfs/FileStore/tables/oss/merge_file.csv'
PartNum =2
OutputPath =r'/dbfs/FileStore/tables/oss/output'

## function body
def split_file_chunk(bigfilepath,PartNum,OutputPath):
    from webbrowser import get
    import pandas as pd;
    import os;

    with open(bigfilepath) as fp:
        for (count, _) in enumerate(fp, 1):
           pass

    #print(count)
    ChunkSizePart = (count)//PartNum
    #print(ChunkSizePart)
    for i,chunk in enumerate(pd.read_csv(bigfilepath, chunksize=ChunkSizePart)):
        chunk.to_csv(OutputPath+'chunk{}.csv'.format(i), index=False)
        
#call function
split_file_chunk(bigfilepath,PartNum,OutputPath)

# COMMAND ----------

#dbutils.fs.ls("/FileStore/tables/oss/")
file=open('/dbfs/FileStore/tables/oss/outputchunk0.csv','r')
original=file.read()
original