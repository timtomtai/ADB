# Databricks notebook source
# MAGIC %md
# MAGIC call function to read and write data from DB to raw layer
# MAGIC sample input:
# MAGIC 
# MAGIC tablename= "Address"
# MAGIC config_path="/dbfs/FileStore/tables/DataEng/Config_DB_Param.txt"
# MAGIC section= "Diamond" 
# MAGIC target="/mnt/containershareddna01/DemoSourceData/"
# MAGIC newtarget="/mnt/containershareddna02/DataEngineeringLayer/Raw/address/"
# MAGIC FORMAT="csv"

# COMMAND ----------

def write_source_file(config_path,tablename,section,target,newtarget,FORMAT):
    from datetime import datetime
    # Setting logging mechanism
    now = datetime.now()
    datetime_str = now.strftime("%Y%m%d%s")
    #read table
    databasetable = readDatabaseSourceIni (config_path, tablename=tablename, section=section )
    #set filename
    filename=tablename+datetime_str+"."+FORMAT
    target=target+filename
    backupfile=target+"_processed"
    newtarget=newtarget+filename
    #write to file
    databasetable.write.format(FORMAT).mode("overwrite").save(target,header="true")
    #copy file to raw layer
    dbutils.fs.cp(target,newtarget,recurse=True)
    # backup source file
    dbutils.fs.mv(target,backupfile,recurse=True)