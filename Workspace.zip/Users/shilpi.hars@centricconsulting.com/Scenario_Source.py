# Databricks notebook source
 #dbutils.help()
#dbutils.fs.help()
#display(dbutils.fs)
#dbutils.fs.ls('/FileStore/tables/oss')
#path = '/FileStore/tables/oss'
#dbutils.fs.ls(path)

import os
from datetime import datetime , timedelta
path = '/dbfs/FileStore/tables/oss'
#os.listdir(path)
fdpaths = [path+"/"+fd for fd in os.listdir(path)]
#fdpaths
#  make it dynamic. 
qualified_files = []

print(type(qualified_files), type(fdpaths))
lookback_hour_ago = datetime.now()- timedelta(hours = 72)
print(lookback_hour_ago)
#print(datetime.now())

for fdpath in fdpaths:
    statinfo = os.stat(fdpath)
    #print(statinfo)
    modified_date = datetime.fromtimestamp(statinfo.st_mtime)
    print("Modified date of file of path %s is %s " % (fdpath, modified_date))
    if modified_date>=lookback_hour_ago:
        qualified_files.append(fdpath)

        
print(qualified_files)
    

# COMMAND ----------

#out_df_csv= spark.read.format('csv').option("sep",",").option("header","true").option("inferSchema","true").load("/FileStore/tables/oss/yellow_trip_taxi.csv");
#out_df_csv.show()
#out_df_csv.count()
out_df_csv1= spark.read.format('csv').option("sep",",").option("header","true").option("inferSchema","true").load("/FileStore/tables/oss/yellow_trip_taxi_26012022.csv").limit(100);
out_df_csv1.printSchema()
out_df_csv1.count()


# COMMAND ----------

#out_df_csv1.write.csv("/tmp/test_yellow_taxi.csv")
#dbutils.fs.ls('/tmp/test_yellow_taxi.csv')

########## Extract last N rows of the dataframe in pyspark
from pyspark.sql.functions import monotonically_increasing_id
from pyspark.sql.functions import desc
df_taxi = out_df_csv1.withColumn("index", monotonically_increasing_id())
df_taxi_out=df_taxi.orderBy(desc("index")).drop("index")
#df_taxi_out.show(5)
df_taxi_final= df_taxi_out.limit(5)
df_taxi_final.count()
#df_taxi_final.coalesce(1).write.option("inferSchema","true").csv("/FileStore/tables/oss/test_yellow_taxi3.csv")
#df_taxi_final.repartition(1).write.csv(path="/FileStore/tables/oss/test_yellow_taxi4.csv", mode="append", header="true")
#df_taxi_final.toPandas().to_csv("/FileStore/tables/oss/test_yellow_taxi1.csv", header=True)
#df_taxi_final.write.csv("/tmp/test_yellow_taxi1.csv")
#out_df_csv= spark.read.format('csv').option("sep",",").option("header","true").option("inferSchema","true").load("/FileStore/tables/oss/yellow_trip_taxi.csv");
#out_df_csv.count()

#df_merge1=spark.read.format('csv').option("sep",",").option("header","false").option("inferSchema","true").load("/tmp/test_yellow_taxi1.csv");
#df_merge2=spark.read.format('csv').option("sep",",").option("header","false").option("inferSchema","true").load("/tmp/test_yellow_taxi.csv");




# COMMAND ----------

#df_merge=spark.read.format('csv').option("sep",",").option("header","false").option("inferSchema","true").load("/tmp/test_yellow_*.csv");
#df_merge.count()
dbutils.fs.ls('/tmp')
#with open("/dbfs/tmp/test_yellow_taxi1.csv",'r') as file:
 #   lines = file.readlines()
    
#df_taxi_out.write.partitionBy("VendorID").csv("/tmp/test_taxi.csv")

# COMMAND ----------

import pyspark ;
from pyspark.sql import *;
from pyspark.sql.functions import *;
from pyspark.sql.types import *;
import os;
from datetime import datetime, timedelta;
from configparser import ConfigParser;

ini_parser = ConfigParser()
ini_parser.read('C:\projects\pyspark\pyspark_config_teamc.ini')

pass_hours =int(ini_parser.get('FILE_OSS','pass_hours'))
path =ini_parser.get('FILE_OSS','path')

print(pass_hours)
print(path)

               

df_csv_qualified_files, df_parquet_qualified_files = get_df_qualified_files(path, pass_hours)


print((df_csv_qualified_files.count(), len(df_csv_qualified_files.columns)))
print((df_parquet_qualified_files.count(), len(df_parquet_qualified_files.columns)))
    
#     This code for init has to be get through a config file. !!
def get_df_qualified_files(path,pass_hours):
    spark = SparkSession.builder.appName('TeamC').master('master').getOrCreate()
#     Static / init variables #

    lookback_period = datetime.now() - timedelta(hours =pass_hours);
    files_at_path= [path+"\\"+fd for fd in os.listdir(path)];
    csv_qualified_files = [];
    parquet_qualified_files = [];

#     Body
    csv_qualified_files.clear();
    parquet_qualified_files.clear();
    for file in files_at_path:
        get_stats = os.stat(file)
        get_file_last_modified_date = datetime.fromtimestamp(get_stats.st_mtime)
        if get_file_last_modified_date >= lookback_period:
            if file.endswith('.csv'):
                csv_qualified_files.append(file)
            elif file.endswith('.parquet'):
                parquet_qualified_files.append(file)

#     Returning a Df
        
    out_df_csv_qualified_files= spark.read.format('csv').option("header","true").load(csv_qualified_files,sep=',');
    out_df_parquet_qualified_files= spark.read.format('parquet').option("header","true").load(parquet_qualified_files,sep=',');
    
    return(out_df_csv_qualified_files, out_df_parquet_qualified_files)
    

# COMMAND ----------

# MAGIC %fs ls '/FileStore/tables/oss'

# COMMAND ----------

dbutils.fs.put("/tmp/test.json", """
{"string":"string1","int":1,"array":[1,2,3],"dict": {"key": "value1"}}
{"string":"string2","int":2,"array":[2,4,6],"dict": {"key": "value2"}}
{"string":"string3","int":3,"array":[3,6,9],"dict": {"key": "value3", "extra_key": "extra_value3"}}
""")

# COMMAND ----------

#testJsonData = spark.read.json("/tmp/test.json")
testJsonData1 = spark.read.option("multiline", "true").json("/tmp/test.json")
testJsonData1.show()



# COMMAND ----------

#testJsonData.show()

display(testJsonData)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TEMPORARY VIEW jsonTable
# MAGIC USING json
# MAGIC OPTIONS (path="/tmp/test.json");
# MAGIC SELECT * FROM jsonTable;

# COMMAND ----------

dbutils.fs.put("/tmp/multi-line.json", """[
    {"string":"string1","int":1,"array":[1,2,3],"dict": {"key": "value1"}},
    {"string":"string2","int":2,"array":[2,4,6],"dict": {"key": "value2"}},
    {
        "string": "string3",
        "int": 3,
        "array": [
            3,
            6,
            9
        ],
        "dict": {
            "key": "value3",
            "extra_key": "extra_value3"
        }
    }
]""")

# COMMAND ----------

mldf = spark.read.option("multiline", "true").json("/tmp/multi-line.json")
mldf.show()

# COMMAND ----------

display(mldf)

# COMMAND ----------

#dbutils.fs.cp('/tmp/multi-line.json','/FileStore/tables/oss/')
#dbutils.fs.cp('/tmp/test.json','/FileStore/tables/oss/')
#mldf.printSchema()
testJsonData.printSchema()

#dbutils.fs.rm('/FileStore/tables/oss/test.json')



# COMMAND ----------

filePath='/dbfs/FileStore/tables/oss/test_txt.txt'
filename='/dbfs/FileStore/tables/oss/test_txt1.txt'
filename2='/dbfs/FileStore/tables/oss/test_txt2.txt'
file=open(filePath,'r')
lines = file.readlines() 
file=open(filename,'w') 
for line in lines[:int(len(lines)/2)]:
    file.write(line)
file=open(filename2,'w') 
for line in lines[int(len(lines)/2):]:
    file.write(line)

# COMMAND ----------

#dbutils.fs.ls('/FileStore/tables/oss/')
file=open('/dbfs/FileStore/tables/oss/test_txt1.txt')
original=file.read()
original


# COMMAND ----------

#dbutils.fs.ls('/FileStore/tables/oss/')
#file=open('/dbfs/FileStore/tables/oss/yellow_trip_taxi.csv','r')
file=open('/dbfs/FileStore/tables/oss/my_file_8')
original=file.read()
original

# COMMAND ----------

#dbutils.fs.cp('/tmp/test_yellow_taxi1.csv','/FileStore/tables/oss/',recurse=True)
#dbutils.fs.help()
#dbutils.fs.ls('/FileStore/tables/oss/')
#out_df_csv2= spark.read.format('csv').option("sep",",").option("header","false").option("inferSchema","true").load("/FileStore/tables/oss/test_yellow_taxi1.csv")
#out_df_csv2.show()
#dbutils.fs.rm('/FileStore/tables/oss/_started_2644627968695238609')
#dbutils.fs.rm('/FileStore/tables/oss/part-00000-tid-2644627968695238609-04821d28-78b4-4183-b7b6-7d4dfa3e452b-255-1-c000.csv')
#dbutils.fs.rm('_committed_2644627968695238609')
#dbutils.fs.rm('_SUCCESS')
dbutils.fs.rm('/FileStore/tables/oss/test_yellow_taxi3.csv',recurse=True)

# COMMAND ----------

import pyspark ;
from pyspark.sql import *;
from pyspark.sql.functions import *;
from pyspark.sql.types import *;
import os;
from datetime import datetime, timedelta;
from configparser import ConfigParser;
spark = SparkSession.builder.appName('TeamC').master('master').getOrCreate()
spark.conf.set("mapreduce.fileoutputcommitter.marksuccessfuljobs", "false")
#df_taxi_final.coalesce(1).write.option("inferSchema","true").csv("/FileStore/tables/oss/test_yellow_taxi3.csv")
df_taxi_final.to_csv("/FileStore/tables/oss/test_yellow_taxi3.csv", header=True)

# COMMAND ----------

df_taxi_final.write.options(header='True', delimiter=',') \
 .csv("/tmp/zipcodes")

# COMMAND ----------

df=spark.read.csv("/tmp/zipcodes")
df.show()

# COMMAND ----------

##split binary files using size of chunk
CHUNK_SIZE = 10
file_number = 1
with open('/dbfs/FileStore/tables/oss/data.txt') as f:
    chunk = f.read(CHUNK_SIZE)
    while chunk:
        with open('/dbfs/FileStore/tables/oss/my_file_' + str(file_number),'w') as chunk_file:
            chunk_file.write(chunk)
        file_number += 1
        chunk = f.read(CHUNK_SIZE)

# COMMAND ----------

#Create multiple CSV files from existing CSV file based on column
import pandas as pd

# DataFrame to read our input CS file
dataFrame = pd.read_csv("/dbfs/FileStore/tables/oss/SalesRecords.csv")
print("\nInput CSV file = \n", dataFrame)

# groupby to generate CSVs on the basis of Car names in Car column
for (car), group in dataFrame.groupby(['Car']):
   group.to_csv(f'/dbfs/FileStore/tables/oss/{car}.csv', index=False)

#Displaying values of the generated CSVs
print("\nCSV 1 = \n", pd.read_csv("BMW.csv"))
print("\nCSV 2 = \n", pd.read_csv("Lexus.csv"))
print("\nCSV 3 = \n", pd.read_csv("Jaguar.csv"))



# COMMAND ----------

##split binary files using size of chunk
import pandas as pd
import os
import sys

CHUNK_SIZE = 2
file_number = 1
with open('/dbfs/FileStore/tables/oss/merge_file.csv') as f:
    chunk = f.read(CHUNK_SIZE)
    while chunk:
        with open('/dbfs/FileStore/tables/oss/my_file_' + str(file_number),'w') as chunk_file:
            chunk_file.write(chunk)
        file_number += 1
        print("=="*66)
        print(chunk)
        chunk = f.read(CHUNK_SIZE)

# COMMAND ----------

#dbutils.fs.ls('/FileStore/tables/oss/my_file_27')
#dbutils.fs.rm('/FileStore/tables/oss/my_file_27')
# i=1
# for i in range(1,27,1):
#     filename=('/FileStore/tables/oss/my_file_'+str(i))
#     print (filename)
#     dbutils.fs.rm(filename)
#input= open('/dbfs/FileStore/tables/oss/merge_file.csv','r').read().split('\n')
splitlen=3
input= open('/dbfs/FileStore/tables/oss/merge_file.csv','r').read().split('\n')
print(input)
print(len(input))
type(input)

# COMMAND ----------

import os
file_size = os.stat('/dbfs/FileStore/tables/oss/merge_file.csv').st_size
print (file_size)

file_obj= open('/dbfs/FileStore/tables/oss/merge_file.csv','r')
output=[]
for i in range( int(file_size/29)):
    print(i)
    #print (file_obj.read(29).split('\n'))
    output= file_obj.read(29).split('\n')
    print(output)
    

# COMMAND ----------

##function return dataframe for a given file pattern
##input Parameter
path = '/mnt/containershareddna01/DemoSourceData/'
regex = '.*Address\.csv$'

#### Function Body
def get_df_qualified_files(path,regex):
    import pyspark ;
    from pyspark.sql import SparkSession;
    import os;
    from datetime import date 
    from configparser import ConfigParser;
    import re;
    ## Assign values
    
    #files_at_path= ["/dbfs"+path+"/"+fd for fd in os.listdir("/dbfs"+path)]
    filename=os.listdir("/dbfs"+path)
    pattern = re.compile(r''+regex+'')
    qualified_files =[]
    # current date
    today = date.today()
    
    ## check filenanme pattern
    for fname in (filename):
        if pattern.match(fname):
            files=(path+"/"+fname)
            qualified_files.append(files)

    if qualified_files!=[]:
        print(qualified_files)
        extension = os.path.splitext(qualified_files[0])[1][1:]
        out_df_files= spark.read.format(r''+extension+'').option("header","true").load(qualified_files);
    else:
        out_df_files= spark.sparkContext.emptyRDD();
        print('No files present');

    return out_df_files;

## call function
df = get_df_qualified_files(path,regex)

df.show()