# Databricks notebook source
# MAGIC %md # Hello This is a Title

# COMMAND ----------

# MAGIC %fs ls

# COMMAND ----------

# MAGIC %md
# MAGIC <a href="$./Quickstart Notebook">Link to notebook in same folder as current notebook</a>

# COMMAND ----------

# MAGIC %md
# MAGIC \\(c = \\pm\\sqrt{a^2 + b^2} \\)
# MAGIC 
# MAGIC \\(A{_i}{_j}=B{_i}{_j}\\)

# COMMAND ----------

# MAGIC %md
# MAGIC $$c = \\pm\\sqrt{a^2 + b^2}$$
# MAGIC 
# MAGIC \\[A{_i}{_j}=B{_i}{_j}\\]

# COMMAND ----------

# MAGIC %sql
# MAGIC select
# MAGIC   *
# MAGIC from
# MAGIC   demo_delta

# COMMAND ----------

spark

# COMMAND ----------

1+1 # => 2

# COMMAND ----------

import pandas as pd
iris=pd.read_csv('https://raw.githubusercontent.com/mwaskom/seaborn-data/master/iris.csv')
ax = iris.plot()
print ("Here's the plot")
display(ax)
print ("Here's the table")
display(ax)

# COMMAND ----------

# MAGIC %run /Users/shilpi.hars@centricconsulting.com/run_notebook

# COMMAND ----------

print(x) # => 5