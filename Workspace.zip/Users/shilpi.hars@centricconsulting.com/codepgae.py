# Databricks notebook source
#spark.conf.set("parquet.enable.summary-metadata", "false")
import codecs
sourceFileName='/dbfs/FileStore/tables/oss/codecheck'
targetFileName='/dbfs/FileStore/tables/oss/codecheck1'
BLOCKSIZE = 10 # or some other, desired size in bytes
with codecs.open(sourceFileName, "r", "ascii") as sourceFile:
    with codecs.open(targetFileName, "w", encoding='utf-8') as targetFile:
        while True:
            contents = sourceFile.read(BLOCKSIZE)
            if not contents:
                break
            targetFile.write(contents)

# COMMAND ----------

import pyspark.sql.functions as f
spark.conf.set("parquet.enable.summary-metadata", "false")
spark.conf.set("mapreduce.fileoutputcommitter.marksuccessfuljobs","false")
#spark.sql.sources.commitProtocolClass = "org.apache.spark.sql.execution.datasources.SQLHadoopMapReduceCommitProtocol"
df=spark.read.option("charset", "utf-8").csv('/FileStore/tables/oss/merge2_file2')
df.show()
df1=df.withColumn("affectedColumnName", f.encode("_c0", 'utf-8'))
df1.show()
df2=df1.withColumn("affectedColumnName", f.decode("_c0", 'utf-8'))
df2.show()
df2.write.csv('/FileStore/tables/oss/merge_file_check.csv')

# COMMAND ----------

import os    
from chardet import detect
#srcfile='/dbfs/FileStore/tables/oss/merge_file.csv'
#srcfile='/dbfs/FileStore/tables/oss/merge1_file1.csv'
srcfile="/dbfs/FileStore/tables/oss/Codecheck.txt"
# get file encoding type
def get_encoding_type(file):
    with open(file, 'rb') as f:
        rawdata = f.read()
    return detect(rawdata)['encoding']

from_codec = get_encoding_type(srcfile)
print(from_codec)


# COMMAND ----------

#sourceEncoding = "iso-8859-1"
sourceEncoding = "ascii"
targetEncoding = "utf-8"
source = open("/dbfs/FileStore/tables/oss/merge_file.csv","r")
target = open("/dbfs/FileStore/tables/oss/merge2_file2", "wb")
#target.write(source.read().encode('UTF-8'))
target.write(source.read().encode("iso-8859-1"))


#target.write(unicode(source.read(), sourceEncoding).encode(targetEncoding))

# COMMAND ----------

import codecs
source = codecs.open("/dbfs/FileStore/tables/oss/Codecheck.txt","r","iso-8859-1")
source.read().encode("utf-8").decode("utf-8")
target=codecs.open("/dbfs/FileStore/tables/oss/Codecheck1.txt","r","utf-8")
target.read().encode("utf-8").decode("utf-8")
# import pandas as pd
# pd.read_table('/dbfs/FileStore/tables/oss/Codecheck.txt',encoding='iso-8859-1')


# df=spark.read.option("encoding", "iso-8859-2").text('/FileStore/tables/oss/Codecheck.txt')
# df.show()

# #.option("charset", "iso-8859-1")








# COMMAND ----------

import os
import sys
import codecs
from chardet.universaldetector import UniversalDetector

#srcfile='/dbfs/FileStore/tables/oss/merge_file.csv'
srcfile='/dbfs/FileStore/tables/oss/Codecheck.txt'
targetFormat = 'utf-8'
outputDir = 'converted'
detector = UniversalDetector()

def get_encoding_type(file):
    detector.reset()
    with open(file, 'rb') as f:
        rawdata = f.read()
        detector.feed(rawdata)
    detector.close()
    return detector.result['encoding']

from_codec = get_encoding_type(srcfile)
print(from_codec)

# COMMAND ----------

#srcfile='/dbfs/FileStore/tables/oss/merge_file.csv'
srcfile="/dbfs/FileStore/tables/oss/Codecheck.txt"
#newFilename='/dbfs/FileStore/tables/oss/merge3_file3.csv'
newFilename= "/dbfs/FileStore/tables/oss/Codecheck1.txt"
encoding_from='iso-8859-1'
def correctSubtitleEncoding(filename, newFilename, encoding_from, encoding_to='UTF-8'):
    with open(filename, 'r', encoding=encoding_from) as fr:
        with open(newFilename, 'w', encoding=encoding_to) as fw:
            for line in fr:
                fw.write(line[:-1]+'\r\n')

correctSubtitleEncoding(srcfile,newFilename,encoding_from)
from_codec = get_encoding_type(newFilename)
print(from_codec)