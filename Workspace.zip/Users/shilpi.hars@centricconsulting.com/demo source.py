# Databricks notebook source
# MAGIC %md
# MAGIC call notebook to initialize function readDatabaseSourceIni to connect to DB

# COMMAND ----------

# MAGIC %run /DATABRICKS_DEMO/SourceToRaw/NB_ConnectToDB

# COMMAND ----------

# MAGIC %md
# MAGIC call notebook to read and write data from DB to raw layer

# COMMAND ----------

# MAGIC %run /DATABRICKS_DEMO/SourceToRaw/NB_writeDBTOFile

# COMMAND ----------

tablename= "Address"
config_path="/dbfs/FileStore/tables/DataEng/Config_DB_Param.txt"
section= "Diamond" 
target="/mnt/containershareddna01/DemoSourceData/Address.csv"
newtarget="/mnt/containershareddna02/DataEngineeringLayer/Raw/address/Address.csv"
FORMAT="csv"

write_source_file(config_path,tablename,section,target,newtarget,FORMAT)

# COMMAND ----------

# reading data with a tablename

databasetable = readDatabaseSourceIni ("/dbfs/FileStore/tables/DataEng/Config_DB_Param.txt", tablename= "Address", section= "Diamond" )
#databasetable.write.format("csv").mode("overwrite").csv("/mnt/containershareddna01/DemoSourceData/Address.csv",header="true")


# COMMAND ----------

tablename= "Address"
config_path="/dbfs/FileStore/tables/DataEng/Config_DB_Param.txt"
section= "Diamond" 
target="/mnt/containershareddna01/DemoSourceData/Address.csv"
newtarget="/mnt/containershareddna02/DataEngineeringLayer/Raw/address/Address.csv"
FORMAT="csv"

def write_Source_file(config_path,tablename,section,target,newtarget,FORMAT):
    databasetable = readDatabaseSourceIni (config_path, tablename=tablename, section=section )
    databasetable.write.format(FORMAT).mode("overwrite").csv(target,header="true")
    backupfile=target+"_processed"
    dbutils.fs.cp(target,newtarget,recurse=True)
    dbutils.fs.mv(target,backupfile,recurse=True)
    
write_source_file(config_path,tablename,section,target,newtarget,FORMAT)

# COMMAND ----------


target="/mnt/containershareddna01/DemoSourceData/Address.csv"
newtarget="/mnt/containershareddna02/DataEngineeringLayer/Raw/address/Address.csv"
backupfile=target+"_processed"
dbutils.fs.cp(backupfile,newtarget,recurse=True)
#dbutils.fs.mv(target,backupfile,recurse=True)

# COMMAND ----------

target="/mnt/containershareddna01/DemoSourceData/Address.csv"
backupfile=target+"_processed"
backupfile

# COMMAND ----------

#df=spark.read.csv('/dbfs/mnt/containershareddna01/DemoSourceData/Address/part*')
df=spark.read.format("csv").load('/mnt/containershareddna02/DataEngineeringLayer/Raw/address/Address.csv')
df.count()

# COMMAND ----------

#dbutils.fs.ls ('/FileStore/tables/DataEng/Config_DB_Param.txt')
dbutils.fs.ls('/mnt/containershareddna02/DataEngineeringLayer/Raw/address')


# COMMAND ----------

# import pypyodbc pip install pypyodbc
# import pandas as pd # pip install pandas

# SERVER_NAME = 'dnaiapsqlserver01.database.windows.net'
# DATABASE_NAME = 'diamond'

# conn = pypyodbc.connect("""
#     Driver={{SQL Server Native Client 11.0}};
#     Server={0};
#     Database={1};
#     Trusted_Connection=yes;""".format(SERVER_NAME, DATABASE_NAME)
# )

# sql_query = """
# SELECT TOP 5000 *
# FROM [SEX] WITH (NoLock)
# """

# # With Headers
# df1 = pd.read_sql(sql_query, conn)

# # Without Headers
# c = conn.cursor()
# df2 = pd.DataFrame(c.execute(sql_query))