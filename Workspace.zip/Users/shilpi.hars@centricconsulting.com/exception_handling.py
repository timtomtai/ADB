# Databricks notebook source
import sys

list = ['x', 1e-15, 5]

for result in list:

    try:

        print("The result is", result)

        y = 1/int(result)

        #break

    except:

        print("Whew!", sys.exc_info()[0], "occurred.") ### sys.exc_info() returns the name of the exception

        print("Next input please.")

        print()

print("The answer of", result, "is", y)

# COMMAND ----------

import sys

list = ['x', 1e-15, 5]

for result in list:

    try:

        print("The result is", result)

        y = 1/int(result)

        #break

    except Exception as e:

        print(e)

# COMMAND ----------

try:

     #x = int(input("Enter a positive integer:"))
     x=-6

     if x <= 0:

         raise ValueError("It is not a positive number!")

except ValueError as val_e:

    print(val_e)

# COMMAND ----------

try:

    #number = int(input("Enter a number: "))
    number=3

    assert number % 2 == 0

except:

    print("This is an odd number!")

else:

    print("This is an even number!")

    rem = number % 2

    print("The remainder is ", rem)

# COMMAND ----------


try:

   file = open('/dbfs/FileStore/tables/oss/test_txt.txt',encoding = 'utf-8')
   print(file.read())
   # this performs file operations

finally:

   file.close()
   print('file closed')

# COMMAND ----------

class MyError(Exception):
    def __init__(self, value):
        self.value = value
    def __str__(self):
        return repr(self.value)

try:
    raise MyError(2*2)
except MyError as e:
    print('My exception occurred, value:', e.value)

# COMMAND ----------

# MAGIC %md
# MAGIC try { start transaction; execute statements; commit transaction;} catch (Exception e) { perform rollback; } finally { close DB resources like statement; }

# COMMAND ----------

# MAGIC %sql
# MAGIC --create table new_table_eh_delta (Surrogate_key BIGINT,Cust_id int, Policy_number int, chain_id int, status varchar(20))
# MAGIC 
# MAGIC select * from new_table_eh_delta
# MAGIC --select * from diamonds
# MAGIC 
# MAGIC --drop  table new_table_eh_delta

# COMMAND ----------

try:    
    from delta.tables import *
    #from org.apache.spark.sql.delta.schema import Invariant, InvariantViolationException
    #deltaTable = DeltaTable.forPath(spark, "/delta/diamonds/")
    deltaTable = DeltaTable.forName(spark, "new_table_eh_delta")
    #fullHistoryDF = deltaTable.history()    # get the full history of the table
    #fullHistoryDF.show()
    lastOperationDF = deltaTable.history(1) # get the last operation
    version=lastOperationDF.select('version').collect()[0][0]
    print(version)
    TimeStamp=lastOperationDF.select('timestamp').collect()[0][0]
    print(TimeStamp)
    spark.sql("insert into new_table_eh_delta values (3,3,3,3,'Active')")
    spark.sql("insert into new_table_eh_delta values (3,0,3,3,'Active')")

except Exception as e:
    print("return to previous version due to error:", sys.exc_info()[0])
    deltaTable.restoreToVersion(version) # restore table to oldest version
    print(e.args)
    x, y = e.args     # unpack args
    print('x =', x)   #<class 'Exception'>
    print('y =', y)
    #deltaTable.restoreToTimestamp(TimeStamp) # restore to a specific timestamp
    
    

# COMMAND ----------

#spark.sql("insert into new_table_eh_delta values (2,2,2,2,'Active')")
#deltaTable.restoreToVersion(28) # restore table to oldest version
# TimeStamp='2022-02-17 13:33:10'
# deltaTable.restoreToTimestamp(TimeStamp) # restore to a specific timestamp
#deltaTable.vacuum(500)   # vacuum files not required by versions more than 500 hours old
#vacuum deletes only data files, not log files. Log files are deleted automatically and asynchronously after checkpoint operations. The default retention period of log files is 30 days, configurable through the delta.logRetentionDuration property which you set with the ALTER TABLE SET TBLPROPERTIES SQL method.
#spark.sql('VACUUM new_table_eh_delta  RETAIN 24 HOURS')

spark.sql("ALTER TABLE new_table_eh_delta CHANGE COLUMN Surrogate_key SET NOT NULL");
spark.sql("ALTER TABLE new_table_eh_delta ADD CONSTRAINT validIds CHECK (Cust_id >= 1 and Cust_id < 99999999)")


# COMMAND ----------

#To get the version number of the last commit written by the current SparkSession across all threads and all tables, query the SQL configuration
s=spark.conf.get("spark.databricks.delta.lastCommitVersionInSession")
print(s)

# COMMAND ----------

#spark.sql(" insert into new_table_eh_delta select * from new_table_with_surrKey_delta ")
spark.sql("insert into new_table_eh_delta values (2,2,2,2,'Active')")

    

# COMMAND ----------

#dbutils.fs.mkdirs("/databricks/PYODBC/")
# dbutils.fs.put("/databricks/PYODBC/PYODBC.sh","""
# #!/bin/bash
# pip list | egrep 'thrift-sasl|sasl'
# pip install --upgrade thrift
# dpkg -l | egrep 'thrift_sasl|libsasl2-dev|gcc|python-dev'
# sudo apt-get -y install unixodbc-dev libsasl2-dev gcc python-dev
# """,True)
display(dbutils.fs.ls("databricks/PYODBC/PYODBC.sh"))

# COMMAND ----------

pip list | egrep 'thrift-sasl|sasl'

# COMMAND ----------

pip install --upgrade thrift

# COMMAND ----------

# MAGIC %sh dpkg -l | egrep 'thrift_sasl|libsasl2-dev|gcc|python-dev'

# COMMAND ----------

# MAGIC %sh sudo apt-get -y install unixodbc-dev libsasl2-dev gcc python-dev

# COMMAND ----------

pip install pyodbc

# COMMAND ----------

import pyodbc


class SqlConnection:
    def __init__(self, cnn_string):
        self.cnn_string = cnn_string
        self.connection = pyodbc.connect(self.cnn_string, autocommit=False)
        self.cursor = self.connection.cursor()
        self.results = None

    def close_cnn(self):
        self.connection.close()

    def commit(self):
        self.connection.commit()

    def command_execute(self, sql_command, commit=False):
        self.cursor.execute(sql_command)
        if commit:
            self.connection.commit()
        return self.cursor

    def getresults(self):
        return self.results

    def query_execute(self, sql_command):
        try:
            self.cursor.execute(sql_command)
            self.results = self.cursor.fetchall()
            return self.results
        except Exception as e:
            self.results = e
            return self.results

# COMMAND ----------

try:
    
    # create a connection (formatted for SQLEXPRESS, your connection string may look different)
    conn = SqlConnection(cnn_string='Driver="com.microsoft.sqlserver.odbc.SQLServerDriver";Server="dbserverdna01.database.windows.net";Database="dbdna02";')
    # attempt to perform two updates. this is a made-up situation, but assume that both updates must be successfully
    # executed for the db to remain in a consistent state.
    # 1st update:
    sql = "update Demo_Connectivity set name = 'WJT' where name = 'c'"
    cursor = conn.command_execute(sql, commit=False)
    print(str(cursor.rowcount) + ' row(s) modified (NOT committed yet!)')
    # some more logic might go here...
    # for demo purposes, explicitly raise an error before the 2nd update (db not consistent)
    raise ValueError('Error occurred before 2nd update. Nothing will be committed!')
    # 2nd update required to make db consistent:
    sql = "update Demo_Connectivity set name = 'WJT1' where name = 'b'"
    cursor = conn.command_execute(sql, commit=False)
    print(str(cursor.rowcount) + ' row(s) modified (NOT committed yet!)')
    # after all logic executed, db should be in a consistent state, and connection committed
    conn.commit()
    print('Connection, and all commands against it, comitted.')
except pyodbc.OperationalError as e:
    print('Could not establish connection: ' + str(e))
except ValueError as e:
    print(str(e))
finally:
    
    # attempt to close the connection
    try:
        
        conn.close_cnn()
    except:
        pass
#         try:
#             # for demo purposes, query one of the tables - if done after closing the connection,
#             #   and the connection not committed, you should see the original values.
#             # move this try block before closing the connection, and you should see the values updated -
#             #   closing the connection does the "rollback"
#             conn = SqlConnection(cnn_string='Driver={SQL Server};Server=<your server>;Database=<your db>;')
#             sql = 'select Central_PM from PM'
#             results = conn.query_execute(sql)
#             for PM in results:
#                 print(PM[0].strip())
#             conn.close_cnn()
#         except:
#             pass

# COMMAND ----------

#pip3 install databricks-sql-connector
#from databricks import sql
from pyspark.sql import *
#from databricks import sql
#from databricks import sql
connection = sql.connect(server_hostname="...", http_path="...", access_token="...")
# cursor = connection.cursor()

# cursor.execute("SELECT * from range(10)")
# print(cursor.fetchall())

# cursor.close()
# connection.close()

# COMMAND ----------

def readDatabaseSourceIni(configfilePath, **kwargs) :
    
    from configparser import ConfigParser; 
    import sys
    import logging
    try:
        src = kwargs.get ('section', None)
        tablename = kwargs.get ('tablename', None)
        query = kwargs.get ('query', None)
        
        ini_parser = ConfigParser()
        ini_parser.read(configfilePath)
    
        databaseName =ini_parser.get(src,'databasename',fallback='')
        userName =ini_parser.get(src,'user',fallback='')
        password =ini_parser.get(src,'password',fallback='')
        databaseServer =ini_parser.get(src,'databaseserver',fallback='')
        databaseDriver =ini_parser.get(src,'driver',fallback='')
        pass_scope =ini_parser.get(src,'pass_scope',fallback='')
        pass_key =ini_parser.get(src,'pass_key',fallback='')
            
        
        if ((len(pass_key) > 0) and ( len(pass_scope) > 0)):
            
            password = dbutils.secrets.get(scope = pass_scope, key = pass_key)
        
        
        jdbcurl = f"jdbc:sqlserver://{databaseServer}:1433;databaseName={databaseName}"
    
        if tablename is not None:
            jdbcDF = spark.read.format("jdbc") \
                       .option("url", jdbcurl) \
                   .option("dbtable", tablename) \
                   .option("user", userName) \
                   .option("password", password) \
                   .option("driver", databaseDriver) \
                   .load()
            return jdbcDF
        else :
            jdbcDF = spark.read.format("jdbc") \
                   .option("url", jdbcurl) \
                   .option("query", query) \
                   .option("user", userName) \
                   .option("password", password) \
                   .option("driver", databaseDriver) \
                   .load()
            return jdbcDF
#     except Exception as e:
#         print("Error in Reading Source data")
#         self.log.writeToLogs(self,processId,logging.LogType.Error, logging.EventType.FailReadFromDb, logging.LogMessage.FailReadFromDb, errorType = logging.ErrorType.FailReadFromDb)
#         raise Exception(f"{logging.LogMessage.FailReadFromDb.value} ERROR: {e}")
    except:
        print("Error: in Reading Source data")
        print("Whew!", sys.exc_info()[0], "occurred.")
#         logging.writeToLogs(processId,logging.LogType.Error, logging.EventType.FailReadFromDb, logging.LogMessage.FailReadFromDb, errorType = logging.ErrorType.FailReadFromDb)
        raise Exception(f"{logging.LogMessage.FailReadFromDb.value}")
        

        

# COMMAND ----------

databaseable = readDatabaseSourceIni ("/dbfs/FileStore/tables/Config_DB_Param.txt", tablename= "Demo_Connectivity", section= "Src1" )
databaseable.show()

# COMMAND ----------

databaseable = readDatabaseSourceIni ("/dbfs/FileStore/tables/Config_DB_Param.txt", tablename= "Demo_Connetivity", section= "Src1" )
#databaseable.show()

# COMMAND ----------

def getAncestorPath(connectionInst: conn.connect, log: logs.Logging,  processId, entityStageId = "-1"):
  log.writeToLogs(processId,logs.LogType.Info, logs.EventType.GetAncestorPath, logs.LogMessage.GetAncestorPath)
  pathQuery = f"SELECT * FROM Config.GetAncestorSlicePath WHERE (ProcessID = {processId}) OR (ProcessID IS NULL AND EntityStageID = {entityStageId})"
  
  AncestorPath = ""
  dfConfig = ""
  
  entityPath = connectionInst.readFromDb(processId,pathQuery)
  
  ancestorPathToList = entityPath.limit(1).rdd.collect()
  
  if len(ancestorPathToList) is 0:
    log.writeToLogs(processId,logs.LogType.Error, logs.EventType.NoAncestorPath, logs.LogMessage.NoAncestorPath, errorType = logs.ErrorType.NoAncestorPath)
    log.writeToLogs(processId,logs.LogType.Error, logs.EventType.FailGetAncestorPath, logs.LogMessage.FailGetAncestorPath, errorType = logs.ErrorType.FailGetAncestorPath)
    raise ValueError(logs.LogMessage.NoAncestorPath.value)
  
  for row in ancestorPathToList:
    AncestorPath = f"/mnt/lake/{row.LakePath}"
    dfConfig = row.Config
  
  log.writeToLogs(processId,logs.LogType.Info, logs.EventType.SuccessGetAncestorPath, logs.LogMessage.SuccessGetAncestorPath)
  return {"ancestorPath":AncestorPath,"dfConfig":dfConfig}

# COMMAND ----------

import logging
logger = logging.getLogger('db result')
# logger.warning('oo')
logger.info('ooo')
