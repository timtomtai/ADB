# Databricks notebook source
x = 5
print(x) # => 5

# COMMAND ----------

import pandas as pd
pdf = pd.DataFrame({'A': range(1000)})

# COMMAND ----------

pdf.apply

# COMMAND ----------

blob_account_name = "azureopendatastorage"
blob_container_name = "citydatacontainer"
blob_relative_path = "Safety/Release/city=Seattle"
blob_sas_token = r"?st=2019-02-26T02%3A34%3A32Z&se=2119-02-27T02%3A34%3A00Z&sp=rl&sv=2018-03-28&sr=c&sig=XlJVWA7fMXCSxCKqJm8psMOh0W4h7cSYO28coRqF2fs%3D"

# COMMAND ----------

wasbs_path = 'wasbs://%s@%s.blob.core.windows.net/%s' % (blob_container_name, blob_account_name, blob_relative_path)
spark.conf.set('fs.azure.sas.%s.%s.blob.core.windows.net' % (blob_container_name, blob_account_name), blob_sas_token)
print('Remote blob path: ' + wasbs_path)

# COMMAND ----------

df = spark.read.parquet(wasbs_path)
print('Register the DataFrame as a SQL temporary view: source')
df.createOrReplaceTempView('source')

# COMMAND ----------

print('Displaying top 10 rows: ')
display(spark.sql('SELECT * FROM source LIMIT 10'))

# COMMAND ----------

# This is a package in preview.
# You need to pip install azureml-opendatasets in Databricks cluster. https://docs.microsoft.com/en-us/azure/data-explorer/connect-from-databricks#install-the-python-library-on-your-azure-databricks-cluster
from azureml.opendatasets import NycTlcYellow

from datetime import datetime
from dateutil import parser


end_date = parser.parse('2018-06-06')
start_date = parser.parse('2018-05-01')
nyc_tlc = NycTlcYellow(start_date=start_date, end_date=end_date)
nyc_tlc_df = nyc_tlc.to_spark_dataframe()

display(nyc_tlc_df.limit(5))

# COMMAND ----------

dbutils.fs.ls ("/mnt/containershareddna01/DemoSourceData")

# COMMAND ----------

import pandas as pd
def write_parquet_file():
    df = pd.read_csv('/dbfs/mnt/containershareddna01/DemoSourceData/claim_activity_code.txt')
    df.to_parquet('/dbfs/mnt/containershareddna01/DemoSourceData/claim_activity_code.parquet')
write_parquet_file()

# COMMAND ----------

# df= spark.read.format('json').option("header","true").load('/mnt/containershareddna01/DemoSourceData/Sex1.json')
# df.show()

multiline_df = spark.read.option("multiline","true") \
      .json('/mnt/containershareddna01/DemoSourceData/Sex.json')
multiline_df.show()


# COMMAND ----------

df= spark.read.csv("/mnt/containershareddna01/DemoSourceData/claim_activity_code3.csv",header = "true", inferSchema ="true")
df.show()

# COMMAND ----------

import pandas as pd
df = pd.read_csv('/dbfs/mnt/containershareddna01/DemoSourceData/claim_activity_code3.csv')
df

# COMMAND ----------

import pandas as pd
multiline_df = pd.read_json('/dbfs/mnt/containershareddna01/DemoSourceData/Sex.json')
multiline_df.to_csv('/dbfs/mnt/containershareddna01/DemoSourceData/sex2.csv')
df = pd.read_csv('/dbfs/mnt/containershareddna01/DemoSourceData/sex2.csv')
df
multiline_df



# COMMAND ----------


#source_file = spark.read.csv("/mnt/containershareddna03/DataEngineeringLayer/Raw/claim/claim.csv",header=True)
source_file = spark.read.csv("/mnt/containershareddna03/Raw/claim/claim.csv",header=True)
    #"version_begin_timestamp","pobox","latitude","longitude","verified","added_date")
#source_file.show()
# from datetime import datetime
# from pyspark.sql.functions import to_datetime, col
# from pyspark.sql.functions import unix_timestamp
# from pyspark.sql.types import StringType, IntegerType, FloatType, TimestampType

# source_file=source_file.withColumn("po",col("pobox").cast(StringType()))
# source_file=source_file.withColumn("latitude",col("latitude").cast(FloatType()))
# #source_file=source_file.withColumn("lat",col("latitude").cast(IntegerType()))	
# source_file=source_file.withColumn("longitude",col("longitude").cast(FloatType()))	
# source_file=source_file.withColumn("verif",col("verified").cast(IntegerType()))
# source_file=source_file.withColumn("added_datenew",to_datetime(col("version_begin_timestamp"),"yyyy-MM-dd HH:mm:ss.SSS"))
# source_file=source_file.withColumn("version_begin",col("version_begin_timestamp").cast(TimestampType()))
# source_file = source_file.withColumn("version_begin_time",unix_timestamp(col('version_begin_timestamp'), 'yyyy-MM-dd HH:mm:ss.SSS'))
display(source_file)

# COMMAND ----------

from datetime import datetime

date_time_str = '18-09-19 18:55:19'

date_time_obj = datetime.strptime(date_time_str, '%y-%m-%d %H:%M:%S')


print ("The type of the date is now",  type(date_time_obj))
print ("The date is", date_time_obj)

# COMMAND ----------

source_file = spark.read.csv("/mnt/containershareddna02/DataEngineeringLayer/Raw/address/Address.csv",header=True)
from pyspark.sql.types import StringType, IntegerType, FloatType, TimestampType
from pyspark.sql.functions import col,to_date
source_file

source_file=source_file.withColumn("address_id",col("address_id").cast(IntegerType()))	
source_file=source_file.withColumn("address_num",col("address_num").cast(IntegerType()))	
source_file=source_file.withColumn("policy_id",col("policy_id").cast(IntegerType()))	
source_file=source_file.withColumn("policyimage_num",col("policyimage_num").cast(IntegerType()))	
source_file=source_file.withColumn("nameaddresssource_id",col("nameaddresssource_id").cast(IntegerType()))	
source_file=source_file.withColumn("house_num",col("house_num").cast(StringType()))	
source_file=source_file.withColumn("street_name",col("street_name").cast(StringType()))	
source_file=source_file.withColumn("apt_num",col("apt_num").cast(StringType()))	
source_file=source_file.withColumn("other",col("other").cast(StringType()))	
source_file=source_file.withColumn("city",col("city").cast(StringType()))	
source_file=source_file.withColumn("state_id",col("state_id").cast(IntegerType()))	
source_file=source_file.withColumn("zip",col("zip").cast(StringType()))	
source_file=source_file.withColumn("detailstatuscode_id",col("detailstatuscode_id").cast(IntegerType()))	
source_file=source_file.withColumn("added_date",to_date(col("added_date"),"yyyy-MM-dd"))	
source_file=source_file.withColumn("pcadded_date",col("pcadded_date").cast(TimestampType()))	
source_file=source_file.withColumn("display_address",col("display_address").cast(StringType()))	
source_file=source_file.withColumn("county",col("county").cast(StringType()))	
source_file=source_file.withColumn("township",col("township").cast(StringType()))	
source_file=source_file.withColumn("pobox",col("pobox").cast(StringType()))	
source_file=source_file.withColumn("latitude",col("latitude").cast(FloatType()))	
source_file=source_file.withColumn("longitude",col("longitude").cast(FloatType()))	
source_file=source_file.withColumn("verified",col("verified").cast(IntegerType()))	
source_file=source_file.withColumn("attempted_verify",col("attempted_verify").cast(IntegerType()))	
source_file=source_file.withColumn("changed",col("changed").cast(IntegerType()))	
source_file=source_file.withColumn("delivery_point_bar_code",col("delivery_point_bar_code").cast(StringType()))	
source_file=source_file.withColumn("carrier_route",col("carrier_route").cast(StringType()))	
source_file=source_file.withColumn("lot_code",col("lot_code").cast(StringType()))	
source_file=source_file.withColumn("lot_number",col("lot_number").cast(StringType()))	
source_file=source_file.withColumn("zip_verified",col("zip_verified").cast(IntegerType()))	
source_file=source_file.withColumn("thirdparty_entity_id",col("thirdparty_entity_id").cast(IntegerType()))	
source_file=source_file.withColumn("thirdparty_group_id",col("thirdparty_group_id").cast(IntegerType()))	
source_file=source_file.withColumn("territorycode",col("territorycode").cast(IntegerType()))	
source_file=source_file.withColumn("territorycode_userentry",col("territorycode_userentry").cast(IntegerType()))	
source_file=source_file.withColumn("territory_confidence_factor",col("territory_confidence_factor").cast(IntegerType()))	
source_file=source_file.withColumn("windpool_id",col("windpool_id").cast(IntegerType()))	
source_file=source_file.withColumn("windpool_userentry_id",col("windpool_userentry_id").cast(IntegerType()))	
source_file=source_file.withColumn("windpool_confidence_factor",col("windpool_confidence_factor").cast(IntegerType()))	
source_file=source_file.withColumn("mainland_proximitytype_id",col("mainland_proximitytype_id").cast(IntegerType()))	
source_file=source_file.withColumn("ocean_name",col("ocean_name").cast(StringType()))	
source_file=source_file.withColumn("ocean_distance",col("ocean_distance").cast(IntegerType()))	
source_file=source_file.withColumn("bay_name",col("bay_name").cast(StringType()))	
source_file=source_file.withColumn("bay_distance",col("bay_distance").cast(IntegerType()))	
source_file=source_file.withColumn("waterway_name",col("waterway_name").cast(StringType()))	
source_file=source_file.withColumn("waterway_distance",col("waterway_distance").cast(IntegerType()))	
source_file=source_file.withColumn("river_name",col("river_name").cast(StringType()))	
source_file=source_file.withColumn("river_distance",col("river_distance").cast(IntegerType()))	
source_file=source_file.withColumn("state_code",col("state_code").cast(IntegerType()))	
source_file=source_file.withColumn("county_code",col("county_code").cast(IntegerType()))	
source_file=source_file.withColumn("county_code_user_entry",col("county_code_user_entry").cast(IntegerType()))	
source_file=source_file.withColumn("municipal_code",col("municipal_code").cast(IntegerType()))	
source_file=source_file.withColumn("municipal_code_user_entry",col("municipal_code_user_entry").cast(IntegerType()))	
source_file=source_file.withColumn("city_tax_code",col("city_tax_code").cast(StringType()))	
source_file=source_file.withColumn("city_tax_code_user_entry",col("city_tax_code_user_entry").cast(StringType()))	
source_file=source_file.withColumn("county_tax_code",col("county_tax_code").cast(StringType()))	
source_file=source_file.withColumn("county_tax_code_user_entry",col("county_tax_code_user_entry").cast(StringType()))	
source_file=source_file.withColumn("city_min_tax_ind",col("city_min_tax_indicator").cast(IntegerType()))	
source_file=source_file.withColumn("county_min_tax_ind",col("county_min_tax_indicator").cast(IntegerType()))	
source_file=source_file.withColumn("police_code",col("police_code").cast(IntegerType()))	
source_file=source_file.withColumn("police_code_user_entry",col("police_code_user_entry").cast(IntegerType()))	
source_file=source_file.withColumn("fire_code",col("fire_code").cast(IntegerType()))	
source_file=source_file.withColumn("fire_code_user_entry",col("fire_code_user_entry").cast(IntegerType()))	
source_file=source_file.withColumn("tax_confidence_factor",col("tax_confidence_factor").cast(StringType()))	
source_file=source_file.withColumn("mine_code",col("mine_code").cast(StringType()))	
source_file=source_file.withColumn("sinkhole_proximitytype_id",col("sinkhole_proximitytype_id").cast(IntegerType()))	
source_file=source_file.withColumn("mine_proximitytype_id",col("mine_proximitytype_id").cast(IntegerType()))	
source_file=source_file.withColumn("stat_territory",col("stat_territory").cast(IntegerType()))	
source_file=source_file.withColumn("match_code",col("match_code").cast(StringType()))	
source_file=source_file.withColumn("location_quality_code",col("location_quality_code").cast(StringType()))	
source_file=source_file.withColumn("ocean_local_name",col("ocean_local_name").cast(StringType()))	
source_file=source_file.withColumn("ocean_lacfcc",col("ocean_lacfcc").cast(StringType()))	
source_file=source_file.withColumn("bay_local_name",col("bay_local_name").cast(StringType()))	
source_file=source_file.withColumn("bay_lacfcc",col("bay_lacfcc").cast(StringType()))	
source_file=source_file.withColumn("waterway_local_name",col("waterway_local_name").cast(StringType()))	
source_file=source_file.withColumn("waterway_lacfcc",col("waterway_lacfcc").cast(StringType()))	
source_file=source_file.withColumn("river_local_name",col("river_local_name").cast(StringType()))	
source_file=source_file.withColumn("river_lacfcc",col("river_lacfcc").cast(StringType()))	
source_file=source_file.withColumn("waterbody_name",col("waterbody_name").cast(StringType()))	
source_file=source_file.withColumn("waterbody_local_name",col("waterbody_local_name").cast(StringType()))	
source_file=source_file.withColumn("waterbody_distance",col("waterbody_distance").cast(IntegerType()))	
source_file=source_file.withColumn("waterbody_lacfcc",col("waterbody_lacfcc").cast(StringType()))	
source_file=source_file.withColumn("last_modified_date",col("last_modified_date").cast(TimestampType()))	
source_file=source_file.withColumn("packagepart_num",col("packagepart_num").cast(IntegerType()))	
source_file=source_file.withColumn("taxcodeaddressmatchtype_id",col("taxcodeaddressmatchtype_id").cast(IntegerType()))	
source_file=source_file.withColumn("specific_coverage_stat_territory",col("specific_coverage_stat_territory").cast(IntegerType()))	
source_file=source_file.withColumn("geo_override",col("geo_override").cast(IntegerType()))	
source_file=source_file.withColumn("in_care_of",col("in_care_of").cast(StringType()))	
source_file=source_file.withColumn("personal_mailbox",col("personal_mailbox").cast(StringType()))	
source_file=source_file.withColumn("rural_address",col("rural_address").cast(StringType()))	
source_file=source_file.withColumn("is_retain_address_ppc_lookup",col("is_retain_address_ppc_lookup").cast(IntegerType()))	
source_file=source_file.withColumn("fips_code",col("fips_code").cast(StringType()))	
source_file=source_file.withColumn("verify_result_code",col("verify_result_code").cast(StringType()))	
source_file=source_file.withColumn("version_begin_timestamp",col("version_begin_timestamp").cast(TimestampType()))	
source_file=source_file.withColumn("version_end_timestamp",col("version_end_timestamp").cast(TimestampType()))	
source_file=source_file.drop("city_min_tax_indicator","county_min_tax_indicator")

display(source_file)

# COMMAND ----------

# dbutils.fs.cp("/mnt/containershareddna02/DataEngineeringLayer/Raw/claim_activity_code/claim_activity_code.parquet","/mnt/containershareddna03/Raw/claim_activity_code/claim_activity_code.parquet")
# dbutils.fs.cp("/mnt/containershareddna02/DataEngineeringLayer/Raw/claim_control/claim_control.csv","/mnt/containershareddna03/Raw/claim_control/claim_control.csv")
# dbutils.fs.cp("/mnt/containershareddna02/DataEngineeringLayer/Raw/claim_feature/claim_feature.csv","/mnt/containershareddna03/Raw/claim_feature/claim_feature.csv")
# dbutils.fs.cp("/mnt/containershareddna02/DataEngineeringLayer/Raw/claim_policy/claim_policy.csv","/mnt/containershareddna03/Raw/claim_policy/claim_policy.csv")

#######################
#dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/config/data_quality_config-1.txt", "/FileStore/tables/DataEng/RawtoStg/config/data_quality_config.txt", recurse=True)

#dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/controllerRawToStg-1.py", "/FileStore/tables/DataEng/RawtoStg/controllerRawToStg.py")

#dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/addressRawtoStg-1.py", "/FileStore/tables/DataEng/RawtoStg/addressRawtoStg.py")

#dbutils.fs.mv("/FileStore/tables/DataEng/RawtoStg/claimfeatureRawToStg.py", "/FileStore/tables/DataEng/RawtoStg/claimfeatureRawtoStg.py")



# COMMAND ----------

source_file = spark.read.csv("/mnt/containershareddna03/Raw/claim_feature/claim_feature.csv",header=True)
display(source_file)

# COMMAND ----------

from pyspark.sql import SparkSession 
import glob
from pyspark.sql.functions import to_timestamp,col
from pyspark.sql.types import TimestampType,IntegerType,BinaryType, DoubleType, DecimalType
spark.sql("set spark.sql.legacy.timeParserPolicy=CORRECTED")
source_file=source_file.withColumn("FEATURE_SETUP_DATETIME",to_timestamp(col('FEATURE_SETUP_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))												
source_file=source_file.withColumn("FEATURE_OPEN_DATETIME",to_timestamp(col('FEATURE_OPEN_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))								
source_file=source_file.withColumn("FEATURE_CLOSE_DATETIME",to_timestamp(col('FEATURE_CLOSE_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))												
source_file=source_file.withColumn("FEATURE_REOPEN_DATETIME",to_timestamp(col('FEATURE_REOPEN_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))												
source_file=source_file.withColumn("FEATURE_FIRST_CLOSE_DATETIME",to_timestamp(col('FEATURE_FIRST_CLOSE_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))											
source_file=source_file.withColumn("FEATURE_LATEST_REOPEN_DATETIME",to_timestamp(col('FEATURE_LATEST_REOPEN_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))										
source_file=source_file.withColumn("CAUSE_OF_LOSS_CODE",col("CAUSE_OF_LOSS_CODE").cast(IntegerType()))												
source_file=source_file.withColumn("SEGMENT_CODE",col("SEGMENT_CODE").cast(IntegerType()))												
source_file=source_file.withColumn("FEATURE_FRAUD_CODE",col("FEATURE_FRAUD_CODE").cast(IntegerType()))												
source_file=source_file.withColumn("ASL_CODE",col("ASL_CODE").cast(IntegerType()))												
source_file=source_file.withColumn("COVERAGE_SUB_TYPE_CODE",col("COVERAGE_SUB_TYPE_CODE").cast(IntegerType()))																								
source_file=source_file.withColumn("LEGACY_COVERAGE_CODE",col("LEGACY_COVERAGE_CODE").cast(IntegerType()))												
source_file=source_file.withColumn("UNIT_CODE",col("UNIT_CODE").cast(IntegerType()))												
source_file=source_file.withColumn("SUFFIX_CODE",col("SUFFIX_CODE").cast(IntegerType()))												
source_file=source_file.withColumn("DEDUCTIBLE_AMOUNT",col("DEDUCTIBLE_AMOUNT").cast(DoubleType()))												
source_file=source_file.withColumn("FIRST_NOTICE_LIMIT_AMOUNT",col("FIRST_NOTICE_LIMIT_AMOUNT").cast(DoubleType()))												
source_file=source_file.withColumn("ESTIMATED_DAMAGE_DECIMAL",col("ESTIMATED_DAMAGE_DECIMAL").cast(DecimalType()))										
source_file=source_file.withColumn("BUSINESS_EFFECTIVE_BEGIN_DATETIME",to_timestamp(col('BUSINESS_EFFECTIVE_BEGIN_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))												
source_file=source_file.withColumn("BUSINESS_EFFECTIVE_END_DATETIME",to_timestamp(col('BUSINESS_EFFECTIVE_END_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))											
source_file=source_file.withColumn("RECORD_VALID_BEGIN_DATETIME",to_timestamp(col('RECORD_VALID_BEGIN_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))											
source_file=source_file.withColumn("RECORD_VALID_END_DATETIME",to_timestamp(col('RECORD_VALID_END_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))											
source_file=source_file.withColumn("ENTERED_DATETIME",to_timestamp(col('ENTERED_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))													
source_file=source_file.withColumn("UPDATED_DATETIME",to_timestamp(col('UPDATED_DATETIME'), 'yyyy-MM-dd HH:mm:ss.SSS').cast(TimestampType()))												
source_file=source_file.withColumn("PROCESS_BATCH_ID",col("PROCESS_BATCH_ID").cast(IntegerType()))												
source_file=source_file.withColumn("INVALIDATED_BATCH_LOOP_SEQUENCE",col("INVALIDATED_BATCH_LOOP_SEQUENCE").cast(IntegerType()))												
source_file=source_file.withColumn("INTRA_BATCH_LOOP_SEQUENCE",col("INTRA_BATCH_LOOP_SEQUENCE").cast(IntegerType()))																							
source_file=source_file.withColumn("CHANGE_HASH",col("CHANGE_HASH").cast(BinaryType()))		

# COMMAND ----------

display(source_file)

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE rectangle(c BIGINT GENERATED ALWAYS AS (max(a)+1) ,a INT, b INT) using delta

# COMMAND ----------

[claim]
Null_Check = ["CLAIM_NK", "CLAIM_POLICY_FNK"]
Length_Check = {"LOSS_DESC": 1000, "CAUSE_OF_LOSS_DESC": 1000}
DateFormat_Check = {"CLAIM_SETUP_DATETIME": "yyyy-MM-dd", "CLAIM_OPEN_DATETIME": "yyyy-MM-dd"}
InList_Check =  {"ACTIVE_FLAG": ["Y", "N"]}
InRange_Check = {}
Regex_Check = {"SOURCE_SYSTEM_CODE": "^[0-9]*$"}

# COMMAND ----------

from delta import DeltaTable
from pyspark.sql.functions import concat,lit
deltalake_path1 = '/mnt/containershareddna03/Int/edw_claim_policy'
deltalake_path2 = '/mnt/containershareddna03/Int/edw_claim'
deltalake_path3 = '/mnt/containershareddna03/Int/edw_claim_feature'
src_delta_table1 = DeltaTable.forPath(spark, deltalake_path1)
src_delta_table2 = DeltaTable.forPath(spark, deltalake_path2)
src_delta_table3 = DeltaTable.forPath(spark, deltalake_path3)
source_file1 = src_delta_table1.toDF().where("ACTIVE_FLAG = 'Y' ")
source_file2 = src_delta_table2.toDF().where("ACTIVE_FLAG = 'Y' ").select(["CLAIM_NK","CLAIM_POLICY_FNK"])
source_file3 = src_delta_table3.toDF().where("ACTIVE_FLAG = 'Y' ").select(["CLAIM_FNK","COVERAGE_CODE","UNIT_CODE"])
col_list = ["DIM_CLAIM_POLICY_NK","POLICY_NUMBER_NAME","POLICY_SUFFIX_CODE","SYMBOL_CODE","POLICY_COVERAGE_CODE","UNIT_CODE","SOURCE_SYSTEM_CODE"]
source_file = source_file1.join(source_file2, source_file1["POLICY_NK"] == source_file2["CLAIM_POLICY_FNK"]).select(source_file1["*"],source_file2["CLAIM_NK"])
source_file = source_file.join(source_file3, source_file["CLAIM_NK"] == source_file3["CLAIM_FNK"]).select(source_file1["*"],concat(source_file1["POLICY_NK"],lit("#EDW")).alias("DIM_CLAIM_POLICY_NK"),source_file3["COVERAGE_CODE"].alias("POLICY_COVERAGE_CODE"),source_file1["SUFFIX_CODE"].alias("POLICY_SUFFIX_CODE"),source_file3["UNIT_CODE"]).select(col_list)
display(source_file)



# COMMAND ----------

from delta import DeltaTable
from pyspark.sql.functions import concat,lit
deltalake_path4 = '/mnt/containershareddna03/Int/edw_claimant'
src_delta_table4 = DeltaTable.forPath(spark, deltalake_path4)
source_file4 = src_delta_table4.toDF().where("ACTIVE_FLAG = 'Y' ")
display(source_file4)

# COMMAND ----------

#dbutils.fs.mv('/FileStore/tables/DataEng/InttoPri/controllerIntToPri-1.py','/FileStore/tables/DataEng/InttoPri/controllerIntToPri.py')