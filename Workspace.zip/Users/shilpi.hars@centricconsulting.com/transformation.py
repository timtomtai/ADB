# Databricks notebook source
# MAGIC %md
# MAGIC #sequence generation

# COMMAND ----------

df_len = 100
freq =1
ref = spark.range(
    5, df_len, freq
).toDF("id")
ref.show(10)
type(ref)

# COMMAND ----------

# df = spark.createDataFrame([(1., 4.), (2., 5.), (3., 6.)], ["A", "B"])
# df.show()

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
import pyspark.sql.functions as f

s=ref.agg({"id": "max"}).collect()[0][0]
s
ref=ref.withColumn('ind', s+ row_number().over(Window.orderBy('id')))


# COMMAND ----------

from pyspark.sql.functions import when
ref=ref.withColumn('ind', when(ref.ind > 100, None)\
                      .otherwise(ref.ind))
ref.show()

# COMMAND ----------

ref.filter(ref.ind.isNull()).show()

# COMMAND ----------

###final##
#geneate sequence in a dataframe incrementally
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
from pyspark.sql.functions import when

s=ref.agg({"ind": "max"}).collect()[0][0]
s
#ref=ref.withColumn('ind', when(ref.ind == None,s+ row_number().over(Window.orderBy('id')))\
 #                         .otherwise(ref.ind))
#ref=ref.withColumn('ind', when(ref.ind.isNull(),row_number().over(Window.orderBy('id')))\
                         #.otherwise(ref.ind))
ref=ref.filter(ref.ind.isNull()).withColumn('ind',s+ row_number().over(Window.orderBy('id')))
ref.show()

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import dense_rank
#seed = 23
seed=ref.agg({"ind": "max"}).collect()[0][0]
df1=ref.withColumn('label', seed+dense_rank().over(Window.orderBy('id')))
df1.show(10)

# COMMAND ----------

from pyspark.sql.window import Window

from pyspark.sql.functions import monotonically_increasing_id,row_number

df =ref.withColumn("row_idx",row_number().over(Window.orderBy(monotonically_increasing_id())))
df.show(10)

# COMMAND ----------

from pyspark.sql.functions import *
df_len = ref.count()
freq =1
start=ref.agg({"id": "max"}).collect()[0][0]
ref2 = spark.range(
    start, df_len+start, freq
).toDF("seq")
ref2.show(10)
type(ref)


# COMMAND ----------

ref.show()

# COMMAND ----------

ref.createOrReplaceTempView("Sur_using_sql")
df_SurrKey = spark.sql("select row_number() over(order by id) as Surrogate_key, id, ind from Sur_using_sql")
df_SurrKey.show()

# COMMAND ----------

# Need to create this function for creation of Surrogate Key in existing dataframe

from pyspark.sql.types import LongType, StructField, StructType
def dfZipWithIndex (df, offset , colName ):
    # df - source dataframe
    # offset - Adjust to ZipWithIndex's Index
    # colName - name of the index column
    
    new_schema = StructType(
        [StructField(colName, LongType(),True)]  #new added field
        + df.schema.fields)                      #table fields
    
    zipped_rdd = df.rdd.zipWithIndex()
    
    new_rdd = zipped_rdd.map(lambda row: ([row[1]+offset] + list(row[0])))
    
    return spark.createDataFrame(new_rdd, new_schema)

# COMMAND ----------

df_fetching_from_blob= spark.read.csv("/mnt/containershareddna02/dbfs_001.csv/part*.csv",header = "true")
df_fetching_from_blob.show()

# COMMAND ----------

# MAGIC %sql
# MAGIC %sql
# MAGIC --delete from new_table_with_surrKey_delta;
# MAGIC select * from new_table_with_surrKey_delta;
# MAGIC 
# MAGIC --create table new_table_with_surrKey_delta (Surrogate_key BIGINT, Cust_id int, Policy_number int, chain_id int, status varchar(20))
# MAGIC --using delta
# MAGIC --Location '/FileStore/tables/delta_tab/';

# COMMAND ----------

df_with_surrKey.show()

# COMMAND ----------

df_with_surrKey = dfZipWithIndex(df_fetching_from_blob, offset = 1, colName = "Surrogate_key" )
df_with_surrKey.createOrReplaceTempView("DataFrame_View")
df_final=spark.sql("select * from DataFrame_View")
df_final.show()

# COMMAND ----------

# Second run
N = spark.sql("select max(Surrogate_key) from DataFrame_View").collect()[0][0]

df_with_surrKey = dfZipWithIndex(df_fetching_from_blob, offset = N+1, colName = "Surrogate_key" )
df_with_surrKey.createOrReplaceTempView("DataFrame_View1")

# creating dataframe from view
df_final_surrKey = spark.sql("select * from DataFrame_View1")
df_final_surrKey.show()

# COMMAND ----------

 new_schema = StructType(
        [StructField("seq", LongType(),True)]  #new added field
        + df_fetching_from_blob.schema.fields)                      #table fields
    
zipped_rdd = df_fetching_from_blob.rdd.zipWithIndex()
#zipped_rdd.collect()
    
new_rdd = zipped_rdd.map(lambda row: ([row[1]+1] + list(row[0])))
new_rdd.collect()

# COMMAND ----------

###final##
#geneate sequence in a dataframe incrementally
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
from pyspark.sql.functions import when

s=ref.agg({"ind": "max"}).collect()[0][0]
s
#ref=ref.withColumn('ind', when(ref.ind == None,s+ row_number().over(Window.orderBy('id')))\
 #                         .otherwise(ref.ind))
#ref=ref.withColumn('ind', when(ref.ind.isNull(),row_number().over(Window.orderBy('id')))\
                         #.otherwise(ref.ind))
ref=ref.filter(ref.ind.isNull()).withColumn('ind',s+ row_number().over(Window.orderBy('id')))
ref.show()

# COMMAND ----------

DF=df_fetching_from_blob
DF=DF.withColumn('id',lit(None))
DF.show()
# s=DF.agg({"id": "max"}).collect()[0][0]
# print(s)

# COMMAND ----------

###final##
#geneate sequence in a dataframe incrementally
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
from pyspark.sql.functions import when

DF=DF.withColumn('id',lit(None))
s=DF.agg({"id": "max"}).collect()[0][0]
if s==None:
    s=0
#ref=ref.withColumn('ind', when(ref.ind == None,s+ row_number().over(Window.orderBy('id')))\
 #                         .otherwise(ref.ind))
#ref=ref.withColumn('ind', when(ref.ind.isNull(),row_number().over(Window.orderBy('id')))\
                         #.otherwise(ref.ind))
DF1=DF.filter(DF.id.isNull()).withColumn('id',s+row_number().over(Window.orderBy('claim_id')))
DF1.show()

# COMMAND ----------

from pyspark.sql.functions import when
DF2=DF1.withColumn('id', when(DF1.id > 10, None)\
                      .otherwise(DF1.id))
DF2.show()

# COMMAND ----------

#2nd run
###final##
#geneate sequence in a dataframe incrementally
from pyspark.sql.window import Window
from pyspark.sql.functions import row_number
from pyspark.sql.functions import when

s=DF2.agg({"id": "max"}).collect()[0][0]
if s==None:
    s=0
DF3=DF2.withColumn('id', when(DF2.id.isNull(),s+row_number().over(Window.orderBy('id')))\
                         .otherwise(DF2.id))
#DF3=DF2.filter(DF2.id.isNull()).withColumn('id',s+row_number().over(Window.orderBy('claim_id')))
DF3.show()